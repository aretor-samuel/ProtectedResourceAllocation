package DataCollection;


//import org.jgrapht.Graph;
import Graph.Graph;
import Network.CoreSC;
import Network.FrequencySlots;
import Network.Link;
import Network.Link2;
import Network.LinkCores;
import Network.LinkImplementation;
import Network.Node2;
import Network.TopologyParameters;
import TrafficGeneration.Service;
import TrafficGeneration.ServiceAssignment;
import org.jgrapht.alg.util.Pair;


import org.jgrapht.graph.SimpleWeightedGraph;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * calculate utilization Rate
 * @author yby
 */
//public final class SpectrumUtilizationRate<Link2> {
	public final class SpectrumUtilizationRate {


    public static final double EMPTY_EDGE = -1;
    public static final double EMPTY_SERVICE = 0;

    private static SpectrumUtilizationRate ourInstance = new SpectrumUtilizationRate();

    public static SpectrumUtilizationRate getInstance() {
        return ourInstance;
    }

    private SpectrumUtilizationRate() {
    }

    /**
     * calculate utilization Rate for one graph.
     * Notification: the size of slots contained by a E can be variable.
     * @param graph
     * @return utilization Rate or EMPTY_EDGE
     */
    public double calculateUR(SimpleWeightedGraph<Node2, Link2> graph, List<CoreSC> CoreSclist) {
    	
        return calculateUR(graph.edgeSet(), CoreSclist);
    }

    /**
     * calculate utilization Rate for one edgeSet.
     * Notification: the size of slots contained by a E can be variable.
     * @param edgeSet
     * @return utilization Rate or EMPTY_EDGE
     */
     public double calculateUR(Set<Link2> edgeSet,  List<CoreSC> CoreSclist) {
         double totalSlotNum = 0.0d;
         double occupiedSlotNum = 0.0d;
         if (!edgeSet.isEmpty()) {
             for (Link2 edge : edgeSet) {
  	           List<LinkCores> sdmCorelist = edge.getCoreList();
  	         //   for (LinkCores sdmCore : sdmCorelist) {
  	   	 		for (int i=0;i<CoreSclist.size(); i++) {
  	   	 		LinkCores sdmCore=sdmCorelist.get(CoreSclist.get(i).getCoreIndex());
  	            	
 	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();

             	// LinkImplementation sdmEdge = (LinkImplementation) edge;
                 totalSlotNum = totalSlotNum + wavelengths.size();
                 occupiedSlotNum = occupiedSlotNum + sdmCore.occupiedSlotsNum();
               //  occupiedSlotNum = occupiedSlotNum +  wavelengths.get(0).getOccupiedNum();

  	            }
             }
             return occupiedSlotNum / totalSlotNum;
         } else {
             return EMPTY_EDGE;
         }
     }
 
     public double calculateUR1(List<Link2> path) {
        // for (Link2 edge : path) {

         return calculateUR12(path);
     }

     /**
      * calculate utilization Rate for one edgeSet.
      * Notification: the size of slots contained by a E can be variable.
      * @param edgeSet
      * @return utilization Rate or EMPTY_EDGE
      */
      public double calculateUR12(List<Link2> edgeSet) {
          double totalSlotNum = 0.0d;
          double occupiedSlotNum = 0.0d;
          if (!edgeSet.isEmpty()) {
              for (Link2 edge : edgeSet) {
   	           List<LinkCores> sdmCorelist = edge.getCoreList();
   	            for (LinkCores sdmCore : sdmCorelist) {
   	            	
  	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();

              	// LinkImplementation sdmEdge = (LinkImplementation) edge;
                  totalSlotNum = totalSlotNum + wavelengths.size();
                  occupiedSlotNum = occupiedSlotNum + sdmCore.occupiedSlotsNum();
                //  occupiedSlotNum = occupiedSlotNum +  wavelengths.get(0).getOccupiedNum();

   	            }
              }
              return occupiedSlotNum / totalSlotNum;
          } else {
              return EMPTY_EDGE;
          }
      }

     
     
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     

     /**
      * calculate utilization Rate for one edge.
      * @param edge
      * @return utilization Rate or EMPTY_EDGE.
      */
    // public double calculateUR(Link2 edge) {
         public double calculateUR(int OccupiedTotalNum) {

    //	 LinkImplementation sdmEdge = (LinkImplementation) edge;
     	double size = 0 ;
         double occupied = 0;
     
      /**   if (edge == null) {
             return EMPTY_EDGE;
         }
         List<LinkCores> sdmCorelist = edge.getCoreList();
          for (LinkCores sdmCore : sdmCorelist) {
          	
             List<FrequencySlots> wavelengths = sdmCore.getWavelength();

          size = wavelengths.size();
         // occupied = sdmCore.occupiedSlotsNum();
          occupied = wavelengths.get(0).getOccupiedNum();*/

         size = TopologyParameters.getInstance().slotNum*52;
	        
	     
         occupied=OccupiedTotalNum;
          
          
         //return occupied / size;
   //  }
 		return occupied / size;
     }
 }