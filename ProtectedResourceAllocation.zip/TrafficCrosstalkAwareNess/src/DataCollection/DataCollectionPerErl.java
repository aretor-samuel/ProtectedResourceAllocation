package DataCollection;


import javafx.util.Pair;
import DataCollection.SimResultPerErl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Network.CoreSC;

/**
 * @author yby
 * 一次指定频谱规整度阈值，指定业务量的仿真所能采集到的数据。
 */
public class DataCollectionPerErl {

    private double mu = -1;
    private double rou = -1;
    // 表示被阻塞的事件个数，用于最后计算阻塞率
    private int blockedEventNum = 0;
    // 频谱利用率的存储，key表示是第n个事件，value表示当时的频谱利用率
    private Map<Integer, Double> spectrumUtils = new HashMap<Integer, Double>();
    // 频谱搬移次数
    private int spectrumShiftNum = 0;
    // 频谱搬移成功次数
    private int spectrumSuccessShiftNum = 0;
    // 重构时间, key表示第n个事件，value的left表示的是重构开始时间，right表示的是重构结束时间
    private Map<Integer, Pair<Long, Long>> reconstructTimes = new HashMap<Integer, Pair<Long, Long>>();


    /**
     * 增加重构时间的值。
     * <br/>一定要是重构成功，这个时间才会计入。
     * @param eventIndex 当前已经处理完的事件的id，注意，这里的事件id不是eventId，仅仅是事件的个数。
     * @param start 重构的开始时间
     * @param end 重构的结束时间
     */
    public void addReconstructTime(int eventIndex, long start, long end) {
        reconstructTimes.put(eventIndex, new Pair<Long, Long>(start, end));
    }

    /**
     * 增加频谱利用率的值
     * @param eventIndex 当前已经处理完的事件的id，注意，这里的事件id不是eventId，仅仅是事件的个数。
     * @param eventInfo 当前的占用资源的业务信息
     * @param allWavelengthNum 整个网络中所有的频谱个数
     */
    public void addSpectrumUtil(int eventIndex, Map<Integer, Pair<List<CoreSC>, List<Integer>>> eventInfo,
                                int allWavelengthNum) {
        double occupiedNum = 0;
        for (Pair<List<CoreSC>, List<Integer>> pair : eventInfo.values()) {
            double coreNum = pair.getKey().size();
            double waveNum = pair.getValue().size();
            occupiedNum = occupiedNum + coreNum*waveNum;
        }

        spectrumUtils.put(eventIndex, occupiedNum/allWavelengthNum);
    }

    /**
     * 增加频谱搬移成功次数
     */
    public void addSpectrumSuccesshiftNum() {
        spectrumSuccessShiftNum++;
    }

    /**
     * 增加频谱搬移次数
     */
    public void addSpectrumShiftNum() {
        spectrumShiftNum++;
    }

    /**
     * 增加阻塞的事件个数
     */
    public void addBlockedEventNum() {
        blockedEventNum++;
    }

    public SimResultPerErl build(double totalEventNum) {

        double blockedRatio = blockedEventNum/totalEventNum;
        double reconstructTime = calReconTime();
        double specUtil = calSpecUtil();
        return new SimResultPerErl(mu, rou, blockedRatio, specUtil, spectrumShiftNum, spectrumSuccessShiftNum,reconstructTime);
    }

    public DataCollectionPerErl(double mu, double rou) {
        this.mu = mu;
        this.rou = rou;
    }

    /**
     * 计算频谱利用率
     * @return 频谱利用率
     */
    private double calSpecUtil() {
        double num = spectrumUtils.size();
        double totalUtils = 0;
        for (double util : spectrumUtils.values()) {
            totalUtils = totalUtils+util;
        }
        return totalUtils/num;
    }

    /**
     * 计算重构时间的平均值
     * @return 重构时间，单位ms
     */
    private double calReconTime() {
        double num = reconstructTimes.size();
        double totalTime = 0;
        for (Pair<Long, Long> pair : reconstructTimes.values()) {
            double diff = pair.getValue() - pair.getKey();
            if (diff < 0) {
                throw new RuntimeException("重构时间为负数");
            }
            totalTime = totalTime + diff;
        }
        return totalTime/num;
    }
}
