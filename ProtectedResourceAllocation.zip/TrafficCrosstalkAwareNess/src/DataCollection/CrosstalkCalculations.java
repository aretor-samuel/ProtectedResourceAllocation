package DataCollection;



//import org.jgrapht.Graph;
import Graph.Graph;
import Network.CoreSC;
import Network.FrequencySlots;
import Network.Link;
import Network.Link2;
import Network.LinkCores;
import Network.LinkImplementation;
import Network.Node2;
import Network.TopologyParameters;
import TrafficGeneration.Service;
import TrafficGeneration.ServiceAssignment;
import org.jgrapht.alg.util.Pair;


import org.jgrapht.graph.SimpleWeightedGraph;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * calculate utilization Rate
 * @author yby
 */
//public final class SpectrumUtilizationRate<Link2> {
	public final class CrosstalkCalculations {


    public static final int EMPTY_EDGE = 0;
    public static final double EMPTY_SERVICE = 0;
    double BR = 0.05;
    double PCB = 4*Math.pow(10, 6);
    double CCk = 4*Math.pow(10, -4);
    double CPA = 4*Math.pow(10, -5);
    
    double L = 1000*Math.pow(10, 3);
 //   ραΦŋβ
    double R = 0.05;
    double CCŋ = 2*Math.pow(10,-5);
    double BRΦ= 50*Math.pow(10, -3);
    double PCρ= 4*Math.pow(10, 6);
    
    double CPw= 45*Math.pow(10, -6);
    double XT;
    double XTlog10;
    double AverageXT;
    int n =3;
    double h;
    double s;


    private static CrosstalkCalculations ourInstance = new CrosstalkCalculations();


    public static CrosstalkCalculations getInstance() {
        return ourInstance;
    }

    private CrosstalkCalculations() {
    }

    /**
     * calculate calculate for one graph.
     * Notification: the size of slots contained by a E can be variable.
     * @param graph
     * @return utilization Rate or EMPTY_EDGE
     */
    public double calculateCrosstalk(SimpleWeightedGraph<Node2, Link2> graph, List<CoreSC> CoreSclist) {
    	
        return calculateXT(graph.edgeSet(), CoreSclist);
    }

    /**
     * calculate Crosstalk for one edgeSet.
     * Notification: the size of slots contained by a E can be variable.
     * @param edgeSet
     * @return crosstalk Rate or EMPTY_EDGE
     */
     public double calculateXT(Set<Link2> edgeSet,  List<CoreSC> CoreSclist) {
         double totalSlotNum = 0.0d;
         int occupiedSlotNumWithXT = 0;
         int AdjacentoccupiedSlotNumWithXT = 0;
         int count=0;

         if (!edgeSet.isEmpty()) {
             for (Link2 edge : edgeSet) {
  	           List<LinkCores> sdmCorelist = edge.getCoreList();
  	         //   for (LinkCores sdmCore : sdmCorelist) {
  	   	 		for (int i=0;i<CoreSclist.size(); i++) {
  	   	 		LinkCores comparedCore=sdmCorelist.get(CoreSclist.get(i).getCoreIndex());
  	            	
 	                List<FrequencySlots> wavelengths = comparedCore.getWavelength();
 	     			 for (int index=0; index<wavelengths.size(); index++) {
 	     			/**	 if (comparedCore.getWavelength().get(index).getIsOccupied()) {
 	                    //	occupiedSlotNumWithXT=comparedCore.occupiedSlotsNum();

 	                     occupiedSlotNumWithXT++;

                         }
*/
                 
                 for (LinkCores adjCore : comparedCore.getAdjacentCores()) {
                     if (comparedCore.getWavelength().get(index).getIsOccupied() && adjCore.getWavelength().get(index).getIsOccupied()) {
                    	// occupiedSlotNumWithXT++;
                    	// occupiedSlotNumWithXT=comparedCore.getWavelength().get(index).getOccupiedServiceIndex();
                    	// occupiedSlotNumWithXT=comparedCore.occupiedSlotsNum();

                     occupiedSlotNumWithXT++;
                    	 
                    //	 AdjacentoccupiedSlotNumWithXT=adjCore.getWavelength().get(index).getOccupiedServiceIndex();
                    //	 AdjacentoccupiedSlotNumWithXT=adjCore.occupiedSlotsNum();

                    //	 AdjacentoccupiedSlotNumWithXT++;
                     /*    if (adjCore.getIsOccupied()) {
                             count++;
                         }*/

  	            }
             }
 	     			}
 	     			
  	   	 		//}
  	   	 		}
  	   	// 	System.out.println(occupiedSlotNumWithXT);

	        /**	System.out.println(AdjacentoccupiedSlotNumWithXT);
	         	totalSlotNum=AdjacentoccupiedSlotNumWithXT/occupiedSlotNumWithXT;
	           //  return AdjacentoccupiedSlotNumWithXT/occupiedSlotNumWithXT;
	         //	System.out.println(totalSlotNum);

	         	System.out.println(totalSlotNum);*/


 	     			 
  	   	 		}
	     //  	System.out.println(occupiedSlotNumWithXT);

	      //	System.out.println(AdjacentoccupiedSlotNumWithXT);
	      //   	totalSlotNum=AdjacentoccupiedSlotNumWithXT/occupiedSlotNumWithXT;
	           //  return AdjacentoccupiedSlotNumWithXT/occupiedSlotNumWithXT;
	       //  	System.out.println(totalSlotNum);

	         //	System.out.println(totalSlotNum);*/

	         	return occupiedSlotNumWithXT;

  	   	 		
         } else {
             return EMPTY_EDGE;
         }
     
     }
	}