package TrafficGeneration;


import com.google.common.base.Objects;
import Network.Link;
import Network.LinkCores;
import Network.CoreSC;

import java.io.Serializable;
import java.util.List;

/**
 * store service assignment information.
 * @author sambabel
 * @param <EonEdge>
 */
public class ServiceAssignment< Link2> implements Serializable {

    private Service service;
    private List<LinkCores> linkcores;

    private List<CoreSC> OccupiedcoreSCList;

    List<Integer> occupiedIndexes ;
    private int requiredSlotNum;

    private int startIndex;

    private List<Link2> path;

    public Service getService() {
        return service;
    }

    public void setService(final Service service) {
        this.service = service;
    }

    public int getRequiredWaveNum1() {

        return requiredSlotNum;
    }

    public void setRequiredWaveNum(int retuiredSlotNum) {
        this.requiredSlotNum = retuiredSlotNum;
    }
    
    public int getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }
    public  List<LinkCores> getLinkCores(){
    	return linkcores;
    }
    public void setLinkCore(List<LinkCores> linkcores) {
        this.linkcores = linkcores;
    }
    
    public  List<CoreSC> getCores(){
    	return OccupiedcoreSCList;
    }
    public   List<Integer> getConnections(){
    	return occupiedIndexes;
    }
    public List<Link2> getPath() {
        return path;
    }
    public void setCore(List<CoreSC> OccupiedcoreSCList) {
        this.OccupiedcoreSCList = OccupiedcoreSCList;
    }
    public void setConnection(List<Integer> occupiedIndexes) {
        this.occupiedIndexes = occupiedIndexes;
    }


    public void setPath(List<Link2> path) {
        this.path = path;
    }

   // public ServiceAssignment(Service service, int startIndex, List<Link2> path) {
     public ServiceAssignment(Service service, int startIndex,List<CoreSC>OccupiedcoreSCList, int requiredSlotNum, List<Link2> path) {
       //    public ServiceAssignment(Service service, int startIndex,List<LinkCores> linkcores, List<Integer> occupiedIndexes, List<Link2> path) {
        this.service = service;
        this.startIndex = startIndex;
        this.path = path;
        this.OccupiedcoreSCList=OccupiedcoreSCList;
        this.requiredSlotNum=requiredSlotNum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ServiceAssignment)) return false;
        ServiceAssignment that = (ServiceAssignment) o;
        return Objects.equal(service, that.service);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(service);
    }
}
