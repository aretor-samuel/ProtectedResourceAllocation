package Graph;



import Graph.GraphId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by sambabel on 2019-05-16.
 * require : implementing graph identity
 */
public class GraphIdImplement implements GraphId {
    
    String id;

    private static final Logger log  = LoggerFactory.getLogger(GraphIdImplement.class);


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GraphIdImplement(String id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GraphIdImplement)) return false;

        GraphIdImplement that = (GraphIdImplement) o;

        boolean directedEqual = (id != null ? id.equals(that.id) : that.id == null);

        return directedEqual;

    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

}
