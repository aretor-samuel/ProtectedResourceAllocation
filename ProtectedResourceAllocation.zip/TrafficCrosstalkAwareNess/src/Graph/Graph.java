package Graph;




import Network.Node;
import Network.NodeId;
import Network.Link;
import Network.LinkID;

import java.util.List;
import java.util.Map;

/**
 * Created by sambabel on 2019-05-16.
 * The main interface that can represents a network.
 */
public interface Graph {

    /**
     * get all nodes included in this graph.
     * @return nodes
     */
    Map<NodeId, Node> getNodes();

    /**
     * get all edges included in this graph.
     * @return links
     */
    Map<LinkID, Link> getEdges();

    /**
     * get number of nodes.
     * @return nodes num
     */
    int getNodesNum();

    /**
     * get number of links.
     * @return links num
     */
    int getEdgesNum();

    /**
     * get edge between startNode and endNode.
     * @param startNode start node
     * @param endNode end node
     * @return if no such
     */
    Link getEdge(Node startNode, Node endNode);

    /**
     * return if this graph is directed graph.
     * @return is directed
     */
    boolean isDirected();

    /**
     * check connectivity, if there is a link which
     * contains such node not in nodes list, will return false.
     * @return true or false.
     */
    boolean checkConnectivity();

    /**
     * check direction attributes. If directed/bydirectional in Graph, every link in this Graph must have the same isDirected value.
     * @return true or false
     */
    boolean checkDirection();

    interface GraphBuilder {

        /**
         * build an Graph instance.
         * @return Graph instance
         */
        Graph build();

        /**
         * add a device to network.
         * @param node node
         */
        void addNode(Node node);

        /**
         * add a link to network.
         * @param edge
         */
        void addEdge(Link edge);

        /**
         * add a map of devices to network.
         * @param nodes list of devices
         */
        void addNodes(Map<NodeId, Node> nodes);

        /**
         * add a map of links to network.
         * @param edges list of links
         */
        void addEdges(Map<LinkID, Link> edges);

        /**
         * remove a device from network.
         * @param node device to be removed
         * @return if remove operation successes
         */
        boolean removeNode(Node node);

        /**
         * remove an edge from network.
         * @param edge link to be removed
         * @return if remove operation success
         */
        boolean removeEdge(Link edge);

        /**
         * set isDirected
         * @param isDirected isDirected
         */
        void setIsDirected(boolean isDirected);
    }


}
