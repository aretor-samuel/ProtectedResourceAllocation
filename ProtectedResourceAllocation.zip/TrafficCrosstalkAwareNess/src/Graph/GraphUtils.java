package Graph;




/**
 * Created by sambabel on 2019-05-17.
 * tools for Graph class.
 */
public final class GraphUtils {
}
