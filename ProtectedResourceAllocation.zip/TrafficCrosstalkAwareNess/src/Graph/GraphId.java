package Graph;


/**
 * Created by sambabel on 19-05-16.
 * Actually this interface is unuseful while there is only one graph.
 */
public interface GraphId {


}

