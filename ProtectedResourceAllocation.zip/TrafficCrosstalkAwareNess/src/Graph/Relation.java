package Graph;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.Objects;

import Collections.InsertionSortList;
import Network.Path;
//import net.NetworkLink;
//import net.NetworkNode;
import Utility.GraphException;

//
//public class Relation<N extends NetworkNode , L extends NetworkLink, P extends Path<N>> {
	//public class Relation<N extends NetworkNode , 	L extends Comparable<NetworkLink>, P extends Path<N>> {
	//	public class Relation<N extends NetworkNode, L, P extends Path<N>> {
	//		public class Relation<N , L, P extends Path<N>> {
			//	public class Relation<N, L, P extends Path<N>> {
					public class Relation<N, L> {



//public class Relation<NetworkNode, NetworkLink, NetworkPath extends Path<NetworkNode>> {
//	public class Relation<N , L, P extends   DefaultKShortestPathFinder<N>> {


	public final N nodeA;
	public final N nodeB;
	L link;
	List<Path<N>> paths = new InsertionSortList<Path<N>>();
	//List<Path<N>> paths = new ArrayList<Path<N>>();

    //List<Node<N>> paths = new ArrayList<>();

	public Relation(N nodeA, N nodeB) {
		if (nodeA.equals(nodeB)) throw new GraphException("A node cannot have a relation with itself!");
		//this.nodeA = nodeA.hashCode() < nodeB.hashCode() ? nodeA : nodeB;
		//this.nodeB = nodeB.hashCode() > nodeB.hashCode() ? nodeA : nodeB;
		//this.nodeA = nodeA.getNode() < nodeB.getNode() ? nodeA : nodeB;
	//	this.nodeB =nodeB.getNode() > nodeB.getNode() ? nodeA : nodeB;;
		this.nodeA = nodeA;
			this.nodeB =nodeB;
		
	}
	
	public boolean hasLink() {
		return link != null;
	}
	
	public L getLink() {
		return link;
	}
	
/**	@SuppressWarnings("unchecked")
	public List<P> getPaths() {
		return (List<P>) paths;
	}*/
	
//	@Override
	public int hashCode() {
		return nodeB.hashCode() * (nodeB.hashCode() - 1) / 2 + nodeA.hashCode();
		//return nodeB.getNode() * (nodeB.getNode() - 1) / 2 + nodeA.getNode();

	//	return  nodeB.getNode() * (nodeB - 1) / 2 + nodeA.;

	}
	
	public static int hash(int idA, int idB) {
		long min = Math.min(idA, idB);
		long max = Math.max(idA, idB);
		return (int) (max * (max - 1) / 2 + min);
	}
/**	 @Override
	    public int hashCode() {
	        int result = nodeA.;
	        result = 31 * result + node2;
	        return result;
	    }     
*/
/*
 @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SdmEdgeImpl)) return false;
        SdmEdgeImpl sdmEdge = (SdmEdgeImpl) o;
        boolean other =  Objects.equal(id, sdmEdge.id) &&
                        type == sdmEdge.type &&
                        status == sdmEdge.status &&
                        Objects.equal(weights, sdmEdge.weights) &&
                        Objects.equal(coreList, sdmEdge.coreList);
        boolean srcDstBool;
        if (isDirected()) {
            srcDstBool = Objects.equal(src, sdmEdge.src) &&
                            Objects.equal(dst, sdmEdge.dst);
        } else {
            // 如果是双向的链路
            srcDstBool = ( Objects.equal(src, sdmEdge.src) && Objects.equal(dst, sdmEdge.dst) ) ||
                    ( Objects.equal(dst, sdmEdge.src) && Objects.equal(src, sdmEdge.dst) );
        }
        return other && srcDstBool;
    }

 */
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		return hashCode() == obj.hashCode();
	}
/*	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Relation)) return false;

        Relation pathKey = (Relation) o;

        if (nodeA != pathKey.nodeA) return false;
        return nodeB == pathKey.nodeB; 
 
        
        

    }*/
	
	public void print() { // TODO remove
		System.out.println(nodeA + ":=:" + nodeB + " - " + (hasLink() ? "link " : "nolink ") + "{");
//		for (Path path : paths)
//			System.out.println("    " + path);
		System.out.println("}");
	}
}