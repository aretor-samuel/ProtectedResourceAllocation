package Graph;


import static java.lang.String.format;
import static java.util.Objects.requireNonNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

import org.jgrapht.alg.interfaces.KShortestPathAlgorithm;

import org.jgrapht.alg.shortestpath.KShortestPaths;
import org.jgrapht.alg.util.Pair;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;

import org.jgrapht.graph.SimpleWeightedGraph;
import org.jgrapht.graph.builder.DirectedWeightedGraphBuilderBase;
import org.jgrapht.graph.builder.UndirectedWeightedGraphBuilderBase;

import com.google.common.collect.Lists;

import Collections.IdentifiableSet;
import Network.Link2;
import Network.NetworkLink;
import Network.Node2;
import Network.Path;

//import GraphSimulator.BhandariKDisjointShortestPaths;


//public class Graph<  N extends NetworkNode, L extends Comparable<NetworkLink>,P extends Path<N>, G extends Graph<N,L, P, G>> {
public class Graph1<  N extends Node2,   L extends NetworkLink ,P extends Path<N>, G extends Graph1<N,L, P, G>> {
//public class Graph1<  N extends NetworkNode,   L extends Comparable<L> ,P extends Path<N>, G extends Graph1<N,L, P, G>> {
//	TestEdge edge1 = new TestEdge()

	//T extends FixedLengthLink<T>
	IdentifiableSet< N> nodes;
//	List<N>nodes= new ArrayList<N>();;         extends NetworkLink<L>> implements Comparable<L>

//protected HashArray<Relation< N, L , P>> relations;
//protected HashArray<Relation< N, L >> relations;

//	protected HashArray<Relation<N, L, P>> relations= new HashArray<Relation<N, L, P>>(1);
//protected List<Relation<N, L, P>> relations1= new ArrayList<Relation<N, L, P>>();
//protected List<Relation< N, L,P>> relations1;
protected List<Relation< N, L>> relations1;

//protected	SimpleDirectedWeightedGraph<N, TestEdge> graph =  new SimpleDirectedWeightedGraph<>(TestEdge.class);
//protected Graph<N, TestEdge> graph = new DefaultDirectedGraph<>(TestEdge.class);
//protected DefaultDirectedWeightedGraph<N, TestEdge> graph;
public SimpleWeightedGraph<Node2, Link2>graph;
//private HashMap<N,Node> Mappednodes;
//private KShortestPathAlgorithm< N, TestEdge> kShortestPathAlgorithm;


/**	protected PathBuilder< N,P, G> pathBuilder;
	//private final Map<N,   Map<N, Double>> map = new HashMap<>();
//	private  Map<N,   Map<N, Double>> map = new HashMap<>();
	private final  Map< N, Map<N, Double>> map ;
	 public void addNode1(N label) {
	        if (!Mappednodes.containsKey(label))
	        	Mappednodes.put(label,new Node(label));
	    }*/

	
	@SuppressWarnings("unchecked")
	//public Graph1(PathBuilder< N,P, G> pathBuilder) {
		public Graph1() {

		nodes = new IdentifiableSet< N>();
	//	relations = new HashArray<Relation<N, L, P>>(1);
		//relations1= new ArrayList<Relation<N, L, P>>();;
	//	relations = new HashArray<Relation<N, L>>(1);
		relations1= new ArrayList<Relation<N, L>>();;
	//	this.pathBuilder = pathBuilder;
	//	pathBuilder.graph = (G) this;
		//map = new HashMap<>();
	//	Mappednodes = new HashMap<N,Node>();
		
	}
	
	public boolean contains(N node) {
		return nodes.contains(node);
	}
	
	protected boolean addNode(N nodeA, N nodeB) {
		if (!nodes.contains(nodeA))
				nodes.add(nodeA); //return false;
		if (!nodes.contains(nodeB))
			nodes.add(nodeB); //return false;
		//if (!nodes.add(node)) return false;
	//	relations.resize(getNodesPairsCount());
		//for (N n : nodes)
			//if (node != n) {
	//	Relation<N, L, P> relation = new Relation<N, L, P>(nodeA, nodeB);
		Relation<N, L> relation = new Relation<N, L>(nodeA, nodeB);

			//	relations.add(relation);
				relations1.add(relation);
			///}
		return true;
	}
	
/*protected boolean addNode(N node) {
			if (!nodes.contains(node)) return false;
	relations.resize(getNodesPairsCount());
	for (N n : nodes.path)
		if (node != n) {
			Relation<N, L, P> relation = new Relation<N, L, P>(n, node);
			relations.add(relation);
			relations1.add(relation);
		}
	return true;
}*/
	
/**	protected boolean addNode1(N node) {
		if (!nodes.add(node)) return false;
		relations.resize(getNodesPairsCount());
		for (N n : nodes)
			if (node != n) {
				Relation<N, L, P> relation = new Relation<N, L, P>(n, node);
				relations.add(relation);
				relations1.add(relation);
			}
		return true;
	}*/
	

/* public void put(N A,  N B, double weight) {
// checkWeight(weight);
 map.putIfAbsent(A, new HashMap<>());
 map.get(A).put(B, weight);
}

public double get(N A, N B) {
//Map<N, Double> map1=map.get(A);	
 return map.get(A).get(B);
// return map1.get(B);
	// System.out.println(map1.get(B));

// double l= map1.get(B);
 
  //return l;
}*/

private void checkWeight(double weight) {
 if (Double.isNaN(weight)) {
     throw new IllegalArgumentException("The weight is NaN.");
 }

 if (weight < 0.0) {
     throw new IllegalArgumentException("The weight is negative.");
 }
}
	//////////////////////////////////////////////
	
	public List<N> getNodes() {
		return new ArrayList<N>(nodes.path);
	}
	
	
	
	public int getNodesCount() {
		return nodes.path.size();
	}

	public L putLink(N nodeA, N nodeB, L link) {
		if (!nodes.contains(nodeA)) nodes.add(nodeA);
		if (!nodes.contains(nodeB)) nodes.add(nodeB);
	//	if (!nodes.contains(nodeB)) addNode(nodeB);
		//if (!nodes.contains(nodeB)) addNode(nodeB);
	//	Relation<N, L, P> relation = relations.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
		//Relation<N, L, P> relation = relations1.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
	//	L oldLink = null;
		for (Relation<N, L> relation : relations1)
       if (relation.nodeA==nodeA && relation.nodeB==nodeB )//&& relation.nodeA==link.getSource()&& relation.nodeB==link.getDestination())
	//	L oldLink = relation.link;
       	relation.link = link;
		
		
		return link;

	}				

	
	public boolean containsLink(N nodeA, N nodeB) {
		if (!contains(nodeA) || !contains(nodeB)) return false;
		return getLink(nodeA, nodeB) != null;
	}
	
	public L getLink(N nodeA, N nodeB) {
	/**	if (nodeA == nodeB) return null;
		Relation<N, L, P> relation = relations.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
	//	Relation<N, L, P> relation = relations1.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));

		if (relation == null) return null;
		return relation.link;*/
	//	NetworkLink link
	//	L oldLink=(L) new NetworkLink((int) get(nodeA, nodeB));
		L oldLink = null;
	//L oldLink=(L) new NetworkLink((int) Math.floor(Math.random() *3000));


	//	Relation<N, L, P> relation = relations1.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));

		for (Relation<N, L> relation : relations1)
	      if (relation.nodeA==nodeA && relation.nodeB==nodeB)
		//	L oldLink = relation.link;
	        	oldLink=relation.link;
		//	return oldLink;
			return oldLink;

		
	}
	
		 
/**		@SuppressWarnings("unchecked")
	public List<P> getPaths2(N nodeA, N nodeB) {
	
	List<P> path = new ArrayList<P>();
	Relation<N, L, P> relation = relations.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
	relation.paths.clear();
	currentRelation = relation;
	nodeB = relation.nodeB;
	nodeA=relation.nodeA;
	pathBuilder.init();
	pathBuilder.addNode(nodeA);
	depthFirstSearch(nodeA, nodeB);
//	Collections.sort(relation.paths);
	if (relation.paths.size() > Integer.MAX_VALUE) relation.paths.subList(Integer.MAX_VALUE, relation.paths.size()).clear();
	 
			path.addAll((List<P> )relation.paths);
			return path;


	/**for (Relation<N, L, P> relation1 : relations1) {
		
		if (nodeA !=relation1.nodeA || nodeA !=relation1.nodeB && nodeB !=relation1.nodeA || nodeB !=relation1.nodeB) ;
			
		//path.add(e)
		path.addAll((Collection<? extends P>) relation1.paths);
	//	path.addAll((List<P>) relation1.paths);

		
	}
	return path;*/
//	}
		
		
	/*	public List<P> getcomputedDisjointedPaths1(N nodeA,N nodeB , int k) {
			//	Relation<N, L, P> relation = relations.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
				//if (relation == null) return null;
				
				// List<PathRoute> p=ksp( nodeA, nodeB, k);
				//return 	calculatePaths( nodeA, nodeB);
				//return 	findAllShortestPaths( nodeA, nodeB);
				return	findDisjointedShortestPaths1( nodeA, nodeB, k);
				//return ksp( nodeA, nodeB, k);
				//return	KshortestPath( nodeA, nodeB, k);
			}*/
		
	//	KshortestPath
		
		//public List<List<Edge>> getPaths1DisjointedEdges(N nodeA,N nodeB , int k) {
/*		public List<List<TestEdge>> getPaths1DisjointedEdges(N nodeA,N nodeB , int k) {

			//	Relation<N, L, P> relation = relations.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
				//if (relation == null) return null;
				
				// List<PathRoute> p=ksp( nodeA, nodeB, k);
				//return 	calculatePaths( nodeA, nodeB);
				//return 	findAllShortestPaths( nodeA, nodeB);
			//	return	findShortestPaths1( nodeA, nodeB, k);
			//	return ksp( nodeA, nodeB, k);
				return	KDisJointedshortestPath( nodeA, nodeB, k);
			}
		
		public List<List<TestEdge>> getPaths1Edges(N nodeA,N nodeB , int k) {
		//	public List<List<Edge>> getPaths1Edges(N nodeA,N nodeB , int k) {

			//	Relation<N, L, P> relation = relations.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
				//if (relation == null) return null;
				
				// List<PathRoute> p=ksp( nodeA, nodeB, k);
				//return 	calculatePaths( nodeA, nodeB);
				//return 	findAllShortestPaths( nodeA, nodeB);
			//	return	findShortestPaths1( nodeA, nodeB, k);
		//		return ksp( nodeA, nodeB, k);
			return	KshortestPath( nodeA, nodeB, k);
			}*/
			
/*	public List<P> getPaths1(N nodeA,N nodeB , int k) {
	//	Relation<N, L, P> relation = relations.get(Relation.hash(nodeA.hashCode(), nodeB.hashCode()));
		//if (relation == null) return null;
		
		/// List<PathRoute> p=ksp( nodeA, nodeB, k);
		//return 	calculatePaths( nodeA, nodeB, k);
		//return 	findAllShortestPaths( nodeA, nodeB);
		return	findShortestPaths1( nodeA, nodeB, k);
		//return ksp( nodeA, nodeB, k);
		//return	KshortestPath( nodeA, nodeB, k);
	}*/
	
	public ArrayList<L> getConnectedLinks(N nodeA, N nodeB) {
		ArrayList<L> links = new ArrayList<L>();
		
		//for (N n : nodes)
			//if (n != node) {
		L link = getLink(nodeA, nodeB);
				if (link != null) links.add(link);
			//}
		
		return links;
	}
	
	public ArrayList<N> getAdjacentNodes(N node) {
		ArrayList<N> nodes = new ArrayList<N>();
		
		for (N n : this.nodes.path)
			if (n != node) {
				L link = getLink(n, node);
				if (link != null) nodes.add(n);
			}
		
		return nodes;
	}
	
	public List<L> getLinks() {
		List<L> links = new ArrayList<L>();
		//for (Relation<N, L, P> relation : relations)
			for (Relation<N, L>  relation : relations1)

			if (relation.hasLink())
				links.add(relation.link);
		return links;
	}
	
	public int getNodesPairsCount() { // TODO only for testing
		return nodes.path.size() * (nodes.path.size() - 1) / 2;
	}
	
	// Pathfinding
	
//	private N finishNode;
	private Relation<N, L> currentRelation;
	
	
/*	 private void depthFirstSearch(N currentNode, N finishNode) {
		 
		ArrayList<N> adjacentNodes = getAdjacentNodes(currentNode);
		for (N node : adjacentNodes) {
			if (pathBuilder.contains(node)) continue;
			if (node.equals(finishNode)) {
				pathBuilder.addNode(node);
				currentRelation.paths.add(pathBuilder.getPath());
				pathBuilder.removeTail();
				break;
			}
		}
		for (N node : adjacentNodes) {
			if (pathBuilder.contains(node) || node.equals(finishNode)) continue;
			pathBuilder.addNode(node);
			depthFirstSearch(node,finishNode);
			pathBuilder.removeTail();
		}
	}
	 */
/**	
	private void depthFirstSearch(N currentNode, N finishNode) {
		ArrayList<N> adjacentNodes = getAdjacentNodes(currentNode);
		for (N node : adjacentNodes) {
			if (pathBuilder.contains(node)) continue;
			if (node.equals(finishNode)) {
				pathBuilder.addNode(node);
				currentRelation.paths.add(pathBuilder.getPath());
				pathBuilder.removeTail();
				break;
			}
		}
		for (N node : adjacentNodes) {
			if (pathBuilder.contains(node) || node.equals(finishNode)) continue;
		//	if (node.equals(finishNode)) {

			pathBuilder.addNode(node);
			currentRelation.paths.add(pathBuilder.getPath());
		//	depthFirstSearch(node,finishNode);
			pathBuilder.removeTail();
		//	break;
	//	}
		}
	}*/
	
/**	public int calculatePaths(Runnable progressUpdate) {
		return calculatePaths(progressUpdate, Integer.MAX_VALUE);
	}*/
/**		public List<P> calculatePaths(N currentNode,N finishNode) {
	return calculatePaths(currentNode, finishNode, Integer.MAX_VALUE);
	//return calculatePaths(currentNode, finishNode, 4);
}
	
	@SuppressWarnings("unchecked")
	public  List<P> calculatePaths( N currentNode,N finishNode, int maxPathsPerPair) {
		List<P> path = new ArrayList<P>();
		

	//for (Relation<NetworkNode, NetworkLink, NetworkPath> relation : relations) {
	//	Relation<N, L, P> relation = new Relation<N, L, P>(currentNode, finishNode);

		for (Relation<N, L> relation : relations1) {
	

			relation.paths.clear();
			currentRelation = relation;
			finishNode = relation.nodeB;
			currentNode=relation.nodeA;
			pathBuilder.init();
			//pathBuilder.addNode(currentNode);
			pathBuilder.addNode(relation.nodeA);
			depthFirstSearch(relation.nodeA, relation.nodeB);
		//	depthFirstSearch(currentNode, finishNode);
//			Collections.sort(relation.paths);
			if (relation.paths.size() > maxPathsPerPair) relation.paths.subList(maxPathsPerPair, relation.paths.size()).clear();
			 
					path.addAll((List<P> )relation.paths);
		 			 System.out.println(path.toString());

					return path;
			//return (List<P> )relation.paths;
		}	 
					
				if (Runtime.getRuntime().freeMemory() < 1024 * 1024 * 1000) {
				int max = 0;
			//	if (maxPathsPerPair == Integer.MAX_VALUE) {
					if (maxPathsPerPair == 4) {

				//	for (Relation<N, L, P> rel : relations) 
						for (Relation<N, L> rel : relations1) 

						if (rel.paths.size() > max)// max = rel.paths.size();
				//	maxPathsPerPair = max;
						//	path.addAll( (Collection<? extends P>) rel.paths);
					path.addAll( (List<P> ) rel.paths);

				//	return (List<P> )rel.paths;

				}
		
			//progressUpdate.run();
		}
	//	return (List<P> )relation.paths;
				return path;
	}*/
  //  private Map<N,Map<N,Edge<N>>> vertexEdgeMap = new HashMap<>();
   private Map<N,Map<N,Relation<N, L>>> vertexEdgeMap = new HashMap<>();
   
   private void checkK(int k) {
       if (k < 1) {
           throw new IllegalArgumentException(
                   String.format("The value of k is too small: %d, should `be at least 1.", k));
       }
   }
   
   
   
	private Relation<N, L> currentRelation1;
/**
    public List<P> findShortestPaths(N source, N target, int k) {

       requireNonNull(source, "The source node is null.");
       requireNonNull(target, "The target node is null.");
    //   requireNonNull(graph, "The graph is null.");
       checkK(k);
       List<P> path = new ArrayList<P>();
       List<List<N>>nodepath=new ArrayList<>();
       List<PathRoute<N>> paths = new ArrayList<>(k);
       Map<N, Integer> countMap = new HashMap<>();
       Queue<PathRoute<N>> HEAP = new PriorityQueue<>(
               Comparator.comparingDouble(PathRoute::pathCost));

       HEAP.add(new PathRoute<>(source));

       while (!HEAP.isEmpty() && countMap.getOrDefault(target, 0) < k) {
    	   PathRoute<N> currentPath = HEAP.remove();
           N endNode = currentPath.getEndNode();

           countMap.put(endNode, countMap.getOrDefault(endNode, 0) + 1);
         
           if (endNode.equals(target)) {
               paths.add(currentPath);
			//	currentRelation1.paths.add(pathBuilder.getPath());
			//	currentRelation1.paths.add((Path<N>) paths);


           }

           if (countMap.get(endNode) <= k) {
             //  for (Edge<V> edge : graph.get(endNode)) {
                 	for (Relation<N, L, P> relation : relations) {

                 	//PathRoute<N> path = currentPath.append(relation.nodeA, relation.nodeB,  getLink(relation.nodeA,  relation.nodeB).getLength());
                 	PathRoute<N> path1 = currentPath.append(relation.nodeA, relation.nodeB);

                   HEAP.add(path1);
               }
           }
       }
   
   	for (PathRoute<N> path3 : paths) {

   		//currentRelation1= new Relation<N, L, P>(source, target);
		//currentRelation1.paths.add((Path<N>) paths);
   		pathBuilder.init();
    //	pathBuilder.addNode(endNode);
    	pathBuilder.addPath(path3.getNodeList());;
		currentRelation1.paths.add(pathBuilder.getPath());


   	}
			path.addAll((List<P> )currentRelation1.paths);
 			 System.out.println(path.toString());

  //     return paths;
       return path;

   }
	    

 */
	
	/**   public List<P> findShortestPaths1(N source, N target, int k) {
	     //  List<List<N>>nodepath=new ArrayList<>();
	       List<P> path = new ArrayList<P>();

        	for (Relation<N, L, P> relation : relations1) {

		   		pathBuilder.init();
     		//	 System.out.println(relation.nodeA.getID() +"-----"+ relation.nodeB.getID());
     	//		 System.out.println(relation.nodeA.getNode() +"-----"+ relation.nodeB.getNode());

	  //    pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength()) ;
	     pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB, get(relation.nodeA, relation.nodeB)) ;

        	}
		   List<Pair<Double, List<N>>>nodepath= pathBuilder.findShortestPaths(source, target, k);

		   for (Pair<Double, List<N>> path3 : nodepath) {

		   		//currentRelation1= new Relation<N, L, P>(source, target);
				//currentRelation1.paths.add((Path<N>) paths);
		   		pathBuilder.init();
		    //	pathBuilder.addNode(endNode);
		    	pathBuilder.addPath(path3);;
				currentRelation1.paths.add(pathBuilder.getPath());


		   	}
					path.addAll((List<P> )currentRelation1.paths);
  
      			 System.out.println(path.toString());

  
       return path;

   }*/
	    
	/**   
 //   private void addEdge(Edge<N> edge) {
        private void UpdateNodelist() {
   	   DirectedWeightedGraphBuilderBase builderBase = DefaultDirectedWeightedGraph.builder(TestEdge.class);

         	for(N node : nodes.path) {
 		//	graph.addVertex(node);
         builderBase.addVertex(node);

 		       //assertTrue(GraphTests.isComplete(graph));
 		}
        // 	graph=GraphTestsUtils.createSimpleGraph()



        	for (Relation<N, L> relation : relations1) {


           //       graph.addEdge(relation.nodeA, relation.nodeB);
                //  Graphs.addEdgeWithVertices(graph, relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength());
            //    builderBase.addEdge(relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength());
                builderBase.addEdge(relation.nodeA, relation.nodeB, 1.0);


                  //  assertTrue(GraphTests.isComplete(graph));
                  

  	    // addEdge(relation.nodeA, relation.nodeB, get(relation.nodeA, relation.nodeB)) ;

          	}
        	  //    Graph<N, TestEdge> graph = new DefaultDirectedGraph<>(TestEdge.class);
        	//CompleteGraphGenerator<N, TestEdge> completeGenerator   = new CompleteGraphGenerator<>();
        	
          //    SimpleWeightedGraph<N, TestEdge> graph =(SimpleWeightedGraph<N, TestEdge>) builderBase.build();
            //     graph =(org.jgrapht.graph.SimpleDirectedWeightedGraph<N, TestEdge>) builderBase.build();
                 graph =(DefaultDirectedWeightedGraph<N, TestEdge>) builderBase.build();

             // 	org.jgrapht.Graph<N, TestEdge> graph =(org.jgrapht.DirectedGraph<N, TestEdge>) builderBase.build();


        //	completeGenerator.generateGraph(graph, null);
          //    SimpleWeighte
    }
   //     GraphTestsUtils.createSimpleGraph()

 
	/*
	  public List<P> findShortestPaths1(N source, N target, int k) {
		     //  List<List<N>>nodepath=new ArrayList<>();
		       List<P> path = new ArrayList<P>();
		       for(N node : nodes.path) {
		   		pathBuilder.init();
			   	pathBuilder.addNode(node);
		 		//	graph.addVertex(node);
		 		       //assertTrue(GraphTests.isComplete(graph));
		 		}
		    

	        //	for (Relation<N, L, P> relation : relations1) {
	            	for (Relation<N, L> relation : relations) {


			   		pathBuilder.init();
	     		//	 System.out.println(relation.nodeA.getID() +"-----"+ relation.nodeB.getID());
	     	//		 System.out.println(relation.nodeA.getNode() +"-----"+ relation.nodeB.getNode());

		  //    pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength()) ;
		    // pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB, get(relation.nodeA, relation.nodeB)) ;
		     pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB) ;


	        	}
			   List<Pair<Double, List<N>>>nodepath= pathBuilder.findShortestPaths(source, target, k);
			   Relation<N, L, P>currentRelation1= new Relation<N, L, P>(source, target);


			   for (Pair<Double, List<N>> path3 : nodepath) {

			   		currentRelation1= new Relation<N, L, P>(source, target);
					//currentRelation1.paths.add((Path<N>) paths);
			   		pathBuilder.init();
			    //	pathBuilder.addNode(endNode);
			    	pathBuilder.addPath(path3);;
					currentRelation1.paths.add(pathBuilder.getPath());
					pathBuilder.removeTail();



			   	}
						path.addAll((List<P> )currentRelation1.paths);
	  
	      		//	 System.out.println(path.toString());

	  
	       return path;

	   }*/
	  
/*	  public List<P> findDisjointedShortestPaths1(N source, N target, int k) {
		     //  List<List<N>>nodepath=new ArrayList<>();
		       List<P> path = new ArrayList<P>();
		       for(N node : nodes.path) {
		   		pathBuilder.init();
			   	pathBuilder.addNode(node);
		 		//	graph.addVertex(node);
		 		       //assertTrue(GraphTests.isComplete(graph));
		 		}
		    

	        //	for (Relation<N, L, P> relation : relations1) {
	            	for (Relation<N, L, P> relation : relations) {


			   		pathBuilder.init();
	     		//	 System.out.println(relation.nodeA.getID() +"-----"+ relation.nodeB.getID());
	     	//		 System.out.println(relation.nodeA.getNode() +"-----"+ relation.nodeB.getNode());

		  //    pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength()) ;
		    // pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB, get(relation.nodeA, relation.nodeB)) ;
		     pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB) ;


	        	}
			   List<Pair<Double, List<N>>>nodepath= pathBuilder.findDisjointedShortestPaths(source, target, k);
			   Relation<N, L, P>currentRelation1= new Relation<N, L, P>(source, target);

			   for (Pair<Double, List<N>> path3 : nodepath) {

					//currentRelation1.paths.add((Path<N>) paths);
			   		pathBuilder.init();
			    //	pathBuilder.addNode(endNode);
			    	pathBuilder.addPath(path3);;
					currentRelation1.paths.add(pathBuilder.getPath());
					pathBuilder.removeTail();



			   	}
						path.addAll((List<P> )currentRelation1.paths);
	  
	      			 System.out.println(path.toString());

	  
	       return path;

	   }
		     
        */
	  
	 
/**
        public List<List<TestEdge>>   KshortestPath( N source, N target, int k)   {
       //    Graph<N, TestEdge> graph = new DefaultDirectedGraph<>(TestEdge.class);
        	
        //	SimpleDirectedWeightedGraph<N, TestEdge> graph =  new SimpleDirectedWeightedGraph<>(TestEdge.class);
        	
      //     Graphs.addEdgeWithVertices(graph, 0, 1, 10);
           
           

    		UpdateNodelist();

	       //     DirectedWeightedGraphBuilderBase builderBase = DefaultDirectedWeightedGraph.builder(TestEdge.class);
	            
	            

	     


        //    SimpleWeightedGraph<N, TestEdge>graph= new SimpleWeightedGraph<>(TestEdge.class);
            Map<String, N> resultMap = new HashMap<>(); 
            LinkedList<N> result = new LinkedList<>();
   	       List<Pair<Double, List<N>>>nodepath12=new ArrayList<>(k);
   	       List<Pair<Double, List<TestEdge>>>EdgeList=new ArrayList<>(k);
   	       List< List<TestEdge>>EdgeList2=new ArrayList<>(k);


  	       List<List<N>>Pathlist=new ArrayList<>(k);
 	       List<P> path = new ArrayList<P>();
 	/**  	for(N node : nodes.path) {
 			graph.addVertex(node);
//            builderBase.addVertex(node);

 		       //assertTrue(GraphTests.isComplete(graph));
 			resultMap.put("N", node);
 		}*/
     

      /**  	for (Relation<N, L, P> relation : relations1) {


              //  graph.addEdge(relation.nodeA, relation.nodeB);
                Graphs.addEdgeWithVertices(graph, relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength());
            //    builderBase.addEdge(relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength());

                //  assertTrue(GraphTests.isComplete(graph));
                

	    // addEdge(relation.nodeA, relation.nodeB, get(relation.nodeA, relation.nodeB)) ;

        	}*/
        //    SimpleWeightedGraph<N, TestEdge> graph =(SimpleWeightedGraph<N, TestEdge>) builderBase.build();
        //	org.jgrapht.Graph<N, TestEdge> graph =(org.jgrapht.DirectedGraph<N, TestEdge>) builderBase.build();


//            assertTrue(GraphTests.isComplete(graph));
        	
  		//	 System.out.println(graph.toString());
    //    	CompleteGraphGenerator<N, TestEdge> completeGenerator   = new CompleteGraphGenerator<>();
        	
        	 
      //  	completeGenerator.generateGraph(graph, resultMap);
 //       YenKShortestPath<N, TestEdge> ksp= new YenKShortestPath<>(graph);
   /*        KShortestPathAlgorithm<N, TestEdge> ksp=new KShortestPaths<>(graph, k);

        	
        //	KShortestSimplePaths<N, TestEdge>ksp=new KShortestSimplePaths<>(graph, k);
        //	List<GraphPath<N, TestEdge>> GraphpathList=ksp.getPaths(source, target, k);
        	List<org.jgrapht.GraphPath<N, TestEdge>>GraphpathList=ksp.getPaths(source, target);

 		// System.out.println(GraphpathList.toString());
       	   // EdgeList  result
            // first sorted in ascending order of hop-count)
       /** 	GraphpathList.sort(new Comparator<org.jgrapht.GraphPath<N, TestEdge>>() {
                @Override
                public int compare(org.jgrapht.GraphPath<N, TestEdge> o1, org.jgrapht.GraphPath<N, TestEdge> o2) {
                    if (o1.getLength() > o2.getLength()) {
                        return 1;
                    } else if (o1.getLength() < o2.getLength()) {
                        return -1;
                    } else {
                        return 0;
                    }
                }
            });*/

     /* 	for (org.jgrapht.GraphPath<N, TestEdge> Graphpath: GraphpathList) { //getEdgeWeight
      //      	for (GraphPath<N, TestEdge> Graphpath: GraphpathList) { //getEdgeWeight

      		//	 System.out.println(Graphpath.getEdgeList().toString());
      //   	 System.out.println(Graphpath.getEdgeList().toString());

      			EdgeList2.add(Graphpath.getEdgeList());
        	//	Pathlist.add(Graphpath.getVertexList());
            	// nodepath12.add(new Pair<>(Graphpath.getWeight(), Graphpath.getVertexList()));
        /**		EdgeList.add(new Pair<>(Graphpath.getWeight(), Graphpath.getEdgeList()));
          /**  	for ( TestEdge edge: Graphpath.getEdgeList()) { //getEdgeWeight

            		result.addFirst((N) edge.getSource());
            		result.addLast((N) edge.getDestination());
            	//	result.add((N) edge.getSource());
            		//result.add((N) edge.getDestination());
               		// System.out.println( edge.getSource().getNode()+"-----"+  edge.getDestination().getNode()+"---"+edge.getWeight());

       		// System.out.println(Graphpath.getWeight());
            	}
             //    nodepath12.add(new Pair<>(Graphpath.getWeight(), result));*/


       // 	}
      //		 System.out.println(EdgeList2.toString());

        //	 List<List<N>>nodepath= pathBuilder.findShortestPaths(source, target, k);
           /**  List<Pair<Double, List<N>>>nodepath= pathBuilder.findShortestPaths(source, target, k);

 			Relation<N, L, P> relation = new Relation<N, L, P>(source, target);


            
          //   for ( List<N> path3 : Pathlist) {
                 for (Pair<Double, List<N>> path3 : nodepath12) {


  		   		//currentRelation1= new Relation<N, L, P>(source, target);
  				//currentRelation1.paths.add((Path<N>) paths);
             	
       		//	 System.out.println(path3.getSecond().toString());

             	
  		   		pathBuilder.init();
  		    //	pathBuilder.addNode(endNode);
  		    	pathBuilder.addPath(path3);;
  		    	relation.paths.add(pathBuilder.getPath());


  		   	}
  					path.addAll((List<P> )relation.paths);*/
    
        			// System.out.println(path.toString());

             // Return the set of k shortest paths
           //  return ksp;
         /*   // return path;

             return   EdgeList2;
        }
        
        public List<List<TestEdge>>  KDisJointedshortestPath( N source, N target, int k)   {
     //       Graph<N, TestEdge> graph = GraphTestsUtils.createSimpleGraph();
         //  Graph<N, TestEdge> graph = new DefaultDirectedGraph<>(TestEdge.class);
      // 	SimpleDirectedWeightedGraph<N, TestEdge> graph =  new SimpleDirectedWeightedGraph<>(TestEdge.class);

         //    SimpleWeightedGraph<N, TestEdge>graph= new SimpleWeightedGraph<>(TestEdge.class);
             Map<String, N> resultMap = new HashMap<>(); 
             LinkedList<N> result = new LinkedList<>();
    	       List<Pair<Double, List<N>>>nodepath12=new ArrayList<>(k);
    	       List<Pair<Double, List<TestEdge>>>EdgeList=new ArrayList<>(k);
    	       List< List<TestEdge>>EdgeList2=new ArrayList<>(k);
        	//	System.out.println(graph.toString());


   	       List<List<N>>Pathlist=new ArrayList<>(k);
  	       List<P> path = new ArrayList<P>();
  	 /* 	for(N node : nodes.path) {
  			graph.addVertex(node);
  		       //assertTrue(GraphTests.isComplete(graph));
  			resultMap.put("N", node);
  		}*/
      
/**
         	for (Relation<N, L, P> relation : relations1) {


            //     graph.addEdge(relation.nodeA, relation.nodeB);
                 //  assertTrue(GraphTests.isComplete(graph));
                 Graphs.addEdgeWithVertices(graph, relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength());


 	    // addEdge(relation.nodeA, relation.nodeB, get(relation.nodeA, relation.nodeB)) ;

         	}*/
//             assertTrue(GraphTests.isComplete(graph));
         	
   		//	 System.out.println(graph.toString());
         //	CompleteGraphGenerator<N, TestEdge> completeGenerator   = new CompleteGraphGenerator<>();
         	
         	 
         //	completeGenerator.generateGraph(graph, resultMap);
        // 	YenKShortestPath ksp= new YenKShortestPath<>(graph);
  	  //   org.jgrapht.alg.shortestpath.
       // 	BhandariKDisjointShortestPaths<N, TestEdge> alg = new BhandariKDisjointShortestPaths<>(graph);
  	 /*  DijkstraShortestPath<N, TestEdge> dijkstraShortestPath = new DijkstraShortestPath<>(graph);


        // 	List<GraphPath<N, TestEdge>> GraphpathList=alg.getPaths(source, target, k);
  			// System.out.println(GraphpathList.toString());
        	   // EdgeList  result
         	org.jgrapht.GraphPath<N, TestEdge>Graphpath=dijkstraShortestPath.getPath(source, target);

         //    	for (GraphPath<N, TestEdge>Graphpath: GraphpathList) { //getEdgeWeight

       		//	 System.out.println(Graphpath.getEdgeList().toString());

       			EdgeList2.add(Graphpath.getEdgeList());
         	//	Pathlist.add(Graphpath.getVertexList());
             	// nodepath12.add(new Pair<>(Graphpath.getWeight(), Graphpath.getVertexList()));
      /**   		EdgeList.add(new Pair<>(Graphpath.getWeight(), Graphpath.getEdgeList()));
             	for ( TestEdge edge: Graphpath.getEdgeList()) { //getEdgeWeight

             		result.addFirst((N) edge.getSource());
             		result.addLast((N) edge.getDestination());
             	//	result.add((N) edge.getSource());
             		//result.add((N) edge.getDestination());

        		// System.out.println(Graphpath.getWeight());
             	}
                  nodepath12.add(new Pair<>(Graphpath.getWeight(), result));*/


        // 	}
      //	   DijkstraShortestPath<N, TestEdge> dijkstraShortestPath = new DijkstraShortestPath<>(graph);

//	 List<List<N>>nodepath= pathBuilder.findShortestPaths(source, target, k);
            /**  List<Pair<Double, List<N>>>nodepath= pathBuilder.findShortestPaths(source, target, k);

  			Relation<N, L, P> relation = new Relation<N, L, P>(source, target);


             
           //   for ( List<N> path3 : Pathlist) {
                  for (Pair<Double, List<N>> path3 : nodepath12) {


   		   		//currentRelation1= new Relation<N, L, P>(source, target);
   				//currentRelation1.paths.add((Path<N>) paths);
              	
        		//	 System.out.println(path3.getSecond().toString());

              	
   		   		pathBuilder.init();
   		    //	pathBuilder.addNode(endNode);
   		    	pathBuilder.addPath(path3);;
   		    	relation.paths.add(pathBuilder.getPath());


   		   	}
   					path.addAll((List<P> )relation.paths);*/
     
         	//	System.out.println(EdgeList2.toString());

              // Return the set of k shortest paths
            //  return ksp;
             // return path;

       /*       return   EdgeList2;
         }
   
        /**
         * Computes the K shortest paths in a graph from node s to node t using Yen's algorithm
         *
         * @param graph         the graph on which to compute the K shortest paths from s to t
         * @param sourceLabel   the starting node for all of the paths
         * @param targetLabel   the ending node for all of the paths
         * @param K             the number of shortest paths to compute
         * @return              a list of the K shortest paths from s to t, ordered from shortest to longest*
         */
    /*  //  public List<PathRoute> ksp(  N sourceLabel, N targetLabel, int K) {
            public List<List<Edge>> ksp(  N sourceLabel, N targetLabel, int K) {

 	       List<P> path = new ArrayList<P>();
 	      List< List<Edge> >EdgesList = new ArrayList<>();


            // Initialize containers for candidate paths and k shortest paths
            ArrayList<PathRoute> ksp = new ArrayList<PathRoute>();
 	       List<Pair<Double, List<N>>>nodepath12=new ArrayList<>(K);

            PriorityQueue<PathRoute> candidates = new PriorityQueue<PathRoute>();

            try {
                /* Compute and add the shortest path */
      /*      	PathRoute kthPath = shortestPath( sourceLabel, targetLabel);
                ksp.add(kthPath);

                /* Iteratively compute each of the k shortest paths */
        /*        for (int k = 1; k < K; k++) {
                    // Get the (k-1)st shortest path
                	PathRoute previousPath = ksp.get(k-1);

                    //if (previousPath != null) {
           /* Iterate over all of the nodes in the (k-1)st shortest path except for the target node; for each node,
                       (up to) one new candidate path is generated by temporarily modifying the graph and then running
                       Dijkstra's algorithm to find the shortest path between the node and the target in the modified
                       graph */
         /*           for (int i = 0; i < previousPath.size(); i++) {
                        // Initialize a container to store the modified (removed) edges for this node/iteration
                        LinkedList<Edge> removedEdges = new LinkedList<Edge>();

                        // Spur node = currently visited node in the (k-1)st shortest path
                     //   String spurNode = previousPath.getEdges().get(i).getFromNode();
                        Edge edges = (Edge)previousPath.getEdges().get(i); //.getFromNode();
                        N spurNode =  (N) edges.getFromNode();
                        // Root path = prefix portion of the (k-1)st path up to the spur node
                        PathRoute rootPath = previousPath.cloneTo(i);

                        /* Iterate over all of the (k-1) shortest paths */
           /*             for(PathRoute p:ksp) {
                        	PathRoute stub = p.cloneTo(i);
                            // Check to see if this path has the same prefix/root as the (k-1)st shortest path
                            if (rootPath.equals(stub)) {
                                /* If so, eliminate the next edge in the path from the graph (later on, this forces the spur
                                   node to connect the root path with an un-found suffix path) */
           /*                     Edge re = (Edge) p.getEdges().get(i);
                                removeEdge((N) re.getFromNode(),(N) re.getToNode());
                                removedEdges.add(re);
                            }
                        }

                        /* Temporarily remove all of the nodes in the root path, other than the spur node, from the graph */
            /*            for(Edge rootPathEdge : (LinkedList<Edge>)rootPath.getEdges()) {
                            N rn = (N) rootPathEdge.getFromNode();
                            if (!rn.equals(spurNode)) {
                                removedEdges.addAll(removeNode1(rn));
                            }
                        }

                        // Spur path = shortest path from spur node to target node in the reduced graph
                        PathRoute spurPath = shortestPath( spurNode, targetLabel);

                        // If a new spur path was identified...
                        if (spurPath != null) {
                            // Concatenate the root and spur paths to form the new candidate path
                            PathRoute totalPath = rootPath.clone();
                            totalPath.addPath(spurPath);

                            // If candidate path has not been generated previously, add it
                            if (!candidates.contains(totalPath))
                                candidates.add(totalPath);
                        }

                        // Restore all of the edges that were removed during this iteration
                        addEdges(removedEdges);
                    }

                    /* Identify the candidate path with the shortest cost */
         /*           boolean isNewPath;
                    do {
                        kthPath = candidates.poll();
                        isNewPath = true;
                        if (kthPath != null) {
                            for (PathRoute p : ksp) {
                                // Check to see if this candidate path duplicates a previously found path
                                if (p.equals(kthPath)) {
                                    isNewPath = false;
                                    break;
                                }
                            }
                        }
                    } while(!isNewPath);

                    // If there were not any more candidates, stop
                    if (kthPath == null)
                        break;

                    // Add the best, non-duplicate candidate identified as the k shortest path
                    ksp.add(kthPath);
                }
            } catch (Exception e) {
                System.out.println(e);
                e.printStackTrace();
            }
        //    List<Pair<Double, List<N>>>nodepath= pathBuilder.findShortestPaths(sourceLabel, targetLabel, K);
	//		Relation<N, L, P> relation = new Relation<N, L, P>(sourceLabel, targetLabel);
//

            for(PathRoute path1: ksp) {
         //	 System.out.println(path.getNodes());
        	// System.out.println(path.getTotalCost());
        	// nodepath12.add(new Pair<>(path1.getTotalCost(), path1.getNodes()));
        	 EdgesList.add(path1.getEdges());
            }
/**            for (Pair<Double, List<N>> path3 : nodepath12) {

 		   		//currentRelation1= new Relation<N, L, P>(source, target);
 				//currentRelation1.paths.add((Path<N>) paths);
            	
      			 System.out.println(path3.toString());

            	
 		   		pathBuilder.init();
 		    //	pathBuilder.addNode(endNode);
 		    	pathBuilder.addPath(path3);;
 		    	relation.paths.add(pathBuilder.getPath());


 		   	}
 					path.addAll((List<P> )relation.paths);*/
   
       	//		 System.out.println(EdgesList.toString());

            // Return the set of k shortest paths
     /*      return EdgesList;
          //  return path;

        }

        public  PathRoute shortestPath( N sourceLabel, N targetLabel) throws Exception {
            //if (!nodes.containsKey(sourceLabel))
            //    throw new Exception("Source node not found in graph.");
        	for (Relation<N, L> relation : relations1) {

		   	//	pathBuilder.init();
     		//	 System.out.println(relation.nodeA.getID() +"-----"+ relation.nodeB.getID());
     	//		 System.out.println(relation.nodeA.getNode() +"-----"+ relation.nodeB.getNode());

	  //    pathBuilder.UpdateEdgelist(relation.nodeA, relation.nodeB, getLink(relation.nodeA, relation.nodeB).getLength()) ;
	     addEdge(relation.nodeA, relation.nodeB, (double) getLink(relation.nodeA, relation.nodeB).getLength()) ;

        	}
         //   HashMap<N,Node> nodes = graph.getNodes();
            ShortestPathTree predecessorTree = new ShortestPathTree(sourceLabel);
            PriorityQueue<DijkstraNode> pq = new PriorityQueue<DijkstraNode>();
            for (N nodeLabel:Mappednodes.keySet()) {
                DijkstraNode newNode = new DijkstraNode(nodeLabel);
                newNode.setDist(Double.MAX_VALUE);
                newNode.setDepth(Integer.MAX_VALUE);
                predecessorTree.add(newNode);
            }
            DijkstraNode sourceNode = (DijkstraNode) predecessorTree.getNodes().get(predecessorTree.getRoot());
            sourceNode.setDist(0);
            sourceNode.setDepth(0);
            pq.add(sourceNode);

            int count = 0;
            while (!pq.isEmpty()) {
                DijkstraNode current = pq.poll();
                N currLabel = (N) current.getLabel();
                if (currLabel.equals(targetLabel)) {
                	PathRoute shortestPath = new PathRoute();
                    N currentN = targetLabel;
                    N parentN = (N) predecessorTree.getParentOf(currentN);
                    while (parentN != null) {
                        shortestPath.addFirst(new Edge<N>(parentN,currentN,(double) Mappednodes.get(parentN).getNeighbors().get(currentN)));
                        currentN = parentN;
                        parentN = (N) predecessorTree.getParentOf(currentN);
                    }
                    return shortestPath;
                }
                count++;
                HashMap<N, Double> neighbors = Mappednodes.get(currLabel).getNeighbors();
                for (N currNeighborLabel:neighbors.keySet()) {
                    DijkstraNode neighborNode = (DijkstraNode) predecessorTree.getNodes().get(currNeighborLabel);
                    Double currDistance = neighborNode.getDist();
                    Double newDistance = current.getDist() + (double)Mappednodes.get(currLabel).getNeighbors().get(currNeighborLabel);
                    if (newDistance < currDistance) {
                        DijkstraNode neighbor = (DijkstraNode) predecessorTree.getNodes().get(currNeighborLabel);

                        pq.remove(neighbor);
                        neighbor.setDist(newDistance);
                        neighbor.setDepth(current.getDepth() + 1);
                        neighbor.setParent(currLabel);
                        pq.add(neighbor);
                    }
                }
            }

            return null;
        }


*/

}