package Graph;


import com.google.common.base.MoreObjects;
import Network.Node;
import Network.NodeId;
import Network.Link;
import Network.LinkID;
import Utility.Error;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by sambabel on 2019-05-17.
 * Abstract class of Graph, because implementation of Graph is complex.
 */
public abstract class AbstractGraph implements Graph {

    protected static final Logger log = LoggerFactory.getLogger(AbstractGraph.class);

    protected Map<NodeId, Node> nodes;

    protected Map<LinkID, Link> edges;

    protected boolean isDirected;

    public Map<NodeId, Node> getNodes() {
        checkNotNull(nodes, Error.NODES_NULL);
        return nodes;
    }

    public Map<LinkID, Link> getEdges() {
        checkNotNull(edges, Error.EDGES_NULL);
        return edges;
    }

    public int getNodesNum() {
        checkNotNull(nodes, Error.NODES_NULL);
        return nodes.size();
    }

    public int getEdgesNum() {
        checkNotNull(edges, Error.EDGES_NULL);
        return edges.size();
    }

    public Link getEdge(Node startNode, Node endNode) {
        for (Link edge : edges.values()) {
            if (edge.getSrc().equals(startNode) && edge.getDst().equals(endNode)) {
                return edge;
            }
        }
        return null;
    }

    public boolean isDirected() {
        return isDirected;
    }

    public boolean checkConnectivity() {
        for (Link edge : edges.values()) {
            if (nodes.get(edge.getSrcId()) == null || nodes.get(edge.getDstId()) == null) {
                return false;
            }
        }
        return true;
    }

    public boolean checkDirection() {
        for (Link edge : edges.values()) {
            if (edge.isDirected() != isDirected) {
                log.error("The isDirected value of link {} doesn't equal to {}", edge.getEdgeId(), isDirected);
                return false;
            }
        }
        return true;
    }


    public static abstract class AbstractGraphBuilder implements Graph.GraphBuilder {

        protected Map<NodeId, Node> nodes = new HashMap<NodeId, Node>();

        protected Map<LinkID, Link> edges = new HashMap<LinkID, Link>();

        protected boolean isDirected = false;

        public void addNode(Node node) {
            nodes.put(node.getNodeId(), node);
        }

        public void addEdge(Link edge) {
            edges.put(edge.getEdgeId(), edge);
        }

        public void addNodes(Map<NodeId, Node> nodes) {
            checkNotNull(nodes, Error.NODES_NULL);
            nodes.putAll(nodes);
        }

        public void addEdges(Map<LinkID, Link> edges) {
            checkNotNull(edges, Error.EDGES_NULL);
            edges.putAll(edges);
        }

        public boolean removeNode(Node node) {
            if (nodes.get(node) != null) {
                nodes.remove(node);
                return true;
            } else {
                return false;
            }
        }

        public boolean removeEdge(Link edge) {
            if (edges.get(edge) != null) {
                edges.remove(edge);
                return true;
            } else {
                return false;
            }
        }

        public void setIsDirected(boolean isDirected) {
            this.isDirected = isDirected;
        }

        public Map<NodeId, Node> getNodes() {
            return nodes;
        }

        public Map<LinkID, Link> getEdges() {
            return edges;
        }

        public boolean isDirected() {
            return isDirected;
        }
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("nodes", nodes)
                .add("edges", edges)
                .add("isDirected", isDirected)
                .toString();
    }
}

