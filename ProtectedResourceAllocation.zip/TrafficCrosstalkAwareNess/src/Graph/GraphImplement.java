package Graph;


import Network.Node;
import Network.NodeId;
import Network.Link;
import Network.LinkID;
import Graph.AbstractGraph;
import Graph.Graph;
import java.util.Map;

/**
 * Created by Sambabel on 2019-05-16.
 * Graphical implementation of network topology.
 */
public class GraphImplement extends AbstractGraph{

    // Constructor
    private GraphImplement(Map<NodeId, Node> nodes, Map<LinkID, Link> edges){
        this.nodes = nodes;
        this.edges = edges;
    }

    public static SdmGraphBuilder builder() {
        return new SdmGraphBuilder();
    }

    public static class SdmGraphBuilder extends AbstractGraphBuilder {

        public Graph build() {
            return new GraphImplement(nodes, edges);
        }

        public Graph build(Map<NodeId, Node> nodes, Map<LinkID, Link> edges) {

            return new GraphImplement(nodes, edges);
        }

        public void setIsDirected(boolean isDirected) {

        }
    }
}
