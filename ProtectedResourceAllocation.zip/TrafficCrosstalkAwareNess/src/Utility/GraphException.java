package Utility;

public class GraphException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5045989692101144848L;

	public GraphException(String message) {
		super(message);
	}
}
