package Utility;

public class StorageException extends RuntimeException {

	private static final long serialVersionUID = -1385146508031639810L;

	public StorageException(String message) {
		super(message);
	}
}
