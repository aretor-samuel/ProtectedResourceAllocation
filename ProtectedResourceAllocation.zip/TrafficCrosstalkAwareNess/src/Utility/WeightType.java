package Utility;


/**
 * @author 
 * 
 */
public enum WeightType {

    HOP_WEIGHT,
    COST_WEIGHT,

    OPTICAL_WEIGHT
}
