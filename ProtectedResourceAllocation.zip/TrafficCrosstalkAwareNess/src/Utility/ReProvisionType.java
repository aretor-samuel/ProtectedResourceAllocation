package Utility;

/**
 * Created on 2019/05/20.
 * 三种算法
 * @author asia.
 */
public enum ReProvisionType {
	//Algorithm without retuning
    NULL,
    // Only adjust the time window algorithm (time-dimension)
    RE_T,
    // Adjust the Core-Fs dimension and also adjust the time window algorithm (Core/Fs/Time-dimension)
    RE_CFT
}
