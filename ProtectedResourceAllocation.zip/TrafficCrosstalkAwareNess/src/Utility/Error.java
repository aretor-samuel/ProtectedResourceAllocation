package Utility;

/**
 * Created by Boyuan on 16-11-16.
 */
public final class Error {

    public static final String NODE_NULL = "node is null.";
    public static final String EDGE_NULL = "edge is null.";
    public static final String NODES_NULL = "nodes is null.";
    public static final String EDGES_NULL = "edges is null.";
    public static final String NODES_EMPTY = "nodes contains 0 node.";
    public static final String EDGES_EMPTY = "edges contains 0 links.";
    public static final String SRC_NULL = "source node is null.";
    public static final String DST_NULL = "destination node is null.";
    public static final String NODE_ID_NULL = "node id is null.";
    public static final String EDGE_ID_NULL = "edge id is null.";


    // sdmeon
    public static final String CORE_NULL = "core is null.";
    public static final String WAVE_NULL = "wavelength is null.";

}
