package Utility;


/**
 * @author asia
 */
public class RollbackException extends RuntimeException {
    public RollbackException(String message) {
        super(message);
    }
}
