package Utility;

public class CPUException extends RuntimeException {

	private static final long serialVersionUID = -1385146508031639810L;

	public CPUException(String message) {
		super(message);
	}
}
