package Utility;

public class MemoryException extends RuntimeException {

	private static final long serialVersionUID = -1385146508031639810L;

	public MemoryException(String message) {
		super(message);
	}
}
