package Main;

import java.util.LinkedList;


public class GraphPrintAllPaths {

    public void print(Graph graph, int start, int end, String path, boolean[] visited){
        String newPath = path +  "->" + start;
        visited[start] = true;
        LinkedList<Node> list = graph.adjacencyList[start];
        for (int i = 0; i <list.size() ; i++) {
            Node node = list.get(i);
            if(node.destination!=end && visited[node.destination]==false){
//                visited[node.destination] = true;
                print(graph,node.destination,end,newPath,visited);
            }else if(node.destination==end){
                System.out.println(newPath + "->" + node.destination);
            }
        }
        //remove from path
        visited[start] = false;
    }

    public void printAllPaths(Graph graph, int start, int end){
        boolean[] visited = new boolean[graph.vertices];
        visited[start] = true;
        print(graph, start, end, "", visited);
    }

    public static void main(String[] args) {
        int vertices = 29;
        Graph graph = new Graph(vertices);
       
        
        
       graph.addEdge(1,2);
         graph.addEdge(1,6);
        graph.addEdge(2,3);
        graph.addEdge(2,6);
        graph.addEdge(3,4);
        graph.addEdge(3,5);
        graph.addEdge(3,7);
        graph.addEdge(4,5);
        graph.addEdge(4,7);
        graph.addEdge(5,8);
        graph.addEdge(6,7);
        graph.addEdge(6,9);
        graph.addEdge(6,11);
        graph.addEdge(7,8);
        graph.addEdge(7,9);
        graph.addEdge(8,10);
        graph.addEdge(9,10);
        graph.addEdge(9,11);
        graph.addEdge(9,12);
        graph.addEdge(10,13);
        graph.addEdge(10,14);
        graph.addEdge(11,12);
        graph.addEdge(11,15);
        graph.addEdge(11,19);
        graph.addEdge(12,13);
        graph.addEdge(12,16);
        graph.addEdge(13,14);
        graph.addEdge(13,17);
        graph.addEdge(14,18);
        graph.addEdge(15,16);
        graph.addEdge(15,20);
        graph.addEdge(16,17);
        graph.addEdge(16,21);
        graph.addEdge(16,22);
        graph.addEdge(17,18);
        graph.addEdge(17,22);
        graph.addEdge(17,23);
        graph.addEdge(18,24);
        graph.addEdge(19,20);
        graph.addEdge(20,21);
        graph.addEdge(21,22);
        graph.addEdge(22,23);
        graph.addEdge(23,24);
        graph.addEdge(6,25);
        graph.addEdge(19,25);
        graph.addEdge(20,26);
        graph.addEdge(24,26);
        graph.addEdge(22,26);
        graph.addEdge(18,28);
        graph.addEdge(27,28);
        graph.addEdge(8,27);
        graph.addEdge(14,27);
        ////////////////////////////////
        graph.addEdge(2,1);
        graph.addEdge(6,1);
       graph.addEdge(3,2);
       graph.addEdge(6,2);
       graph.addEdge(4,3);
       graph.addEdge(5,3);
       graph.addEdge(7,3);
       graph.addEdge(5,4);
       graph.addEdge(7,4);
       graph.addEdge(8,5);
       graph.addEdge(7,6);
       graph.addEdge(9,6);
       graph.addEdge(11,6);
       graph.addEdge(8,7);
       graph.addEdge(9,7);
       graph.addEdge(10,8);
       graph.addEdge(10,9);
       graph.addEdge(11,9);
       graph.addEdge(12,9);
       graph.addEdge(13,10);
       graph.addEdge(14, 10);
       graph.addEdge(12, 11);
       graph.addEdge(15, 11);
       graph.addEdge(19,11);
       graph.addEdge(13,12);
       graph.addEdge(16, 12);
       graph.addEdge(14, 13);
       graph.addEdge(17, 13);
       graph.addEdge(18,14);
       graph.addEdge(16,15);
       graph.addEdge(20,15);
       graph.addEdge(17,16);
       graph.addEdge(21,16);
       graph.addEdge(22,16);
       graph.addEdge(18,17);
       graph.addEdge(22,17);
       graph.addEdge(23,17);
       graph.addEdge(24,18);
       graph.addEdge(20,19);
       graph.addEdge(21,20);
       graph.addEdge(22,21);
       graph.addEdge(23,22);
       graph.addEdge(24,23);
       graph.addEdge(25,6);
       graph.addEdge(25,19);
       graph.addEdge(26,20);
       graph.addEdge(26,24);
       graph.addEdge(26,22);
       graph.addEdge(28,18);
       graph.addEdge(28,27);
       graph.addEdge(27,8);
       graph.addEdge(27,14);


     /**   graph.addEdge(1, 2);
        graph.addEdge(1, 3);
        graph.addEdge(1, 8); 
        graph.addEdge(2, 1);
        graph.addEdge(2, 3);
        graph.addEdge(2, 4);
        graph.addEdge(3, 1);
        graph.addEdge(3, 2);
        graph.addEdge(3, 6);
        graph.addEdge(4, 2);
        graph.addEdge(4, 5);
        graph.addEdge(4, 11);
        graph.addEdge(5, 4);
        graph.addEdge(5, 6);
        graph.addEdge(5, 7);
        graph.addEdge(6, 3);
        graph.addEdge(6, 5);
        graph.addEdge(6, 10);
        graph.addEdge(6, 14);
        graph.addEdge(7, 5);
        graph.addEdge(7, 8);
        graph.addEdge(7, 10);
        graph.addEdge(8, 1);
        graph.addEdge(8, 7);
        graph.addEdge(8, 9);
        graph.addEdge(9, 8);
        graph.addEdge(9, 10);
        graph.addEdge(9, 12);
        graph.addEdge(9, 13);
        graph.addEdge(10, 6);
        graph.addEdge(10, 7);
        graph.addEdge(10, 9);
        graph.addEdge(11, 4);
        graph.addEdge(11, 12);
        graph.addEdge(11, 13);
        graph.addEdge(12, 9);
        graph.addEdge(12, 11);
        graph.addEdge(12, 14);
        graph.addEdge(13, 9);
        graph.addEdge(13, 11);
        graph.addEdge(13, 14);
        graph.addEdge(14, 6);
        graph.addEdge(14, 12);
        graph.addEdge(14, 13);*/
        GraphPrintAllPaths p = new GraphPrintAllPaths();
        p.printAllPaths(graph,3,5);
    }
}

class Graph{
    int vertices;
    LinkedList<Node> [] adjacencyList;

    public Graph(int vertices){
        this.vertices = vertices;
        adjacencyList = new LinkedList[vertices];
        for (int i = 0; i <vertices; i++) {
            adjacencyList[i] = new LinkedList<Node>();
        }
  //      System.out.println(adjacencyList.toString());

    }

    public void addEdge(int source, int destination){
        Node node = new Node(source, destination);
        //add edge
        adjacencyList[source].addLast(node);
   //     System.out.println(adjacencyList.toString());

    }

}

class Node{
    int source;
    int destination;

    public Node(int source, int destination) {
        this.source = source;
        this.destination = destination;
    }
}