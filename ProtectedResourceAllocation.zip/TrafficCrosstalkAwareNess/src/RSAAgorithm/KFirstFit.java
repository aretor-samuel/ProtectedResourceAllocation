package RSAAgorithm;




import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

//import javafx.util.Pair;
import org.jgrapht.alg.util.Pair;

import TrafficGeneration.ServiceAssignment;
import TrafficGeneration.Service;
import Network.NodeId;
import Network.Link;
import Network.Link2;
import Network.LinkID;
import Network.LinkCores;
import Network.LinkImplementation;
import Network.Node2;
import DataCollection. DataCollectionPerSC;
import Network.CoreSC;
import Network.FrequencySlots;
import Network.NodeIdImplement;
import Network.Nodeimplement;
import Network.TopologySetup;
import Graph.GraphImplement;
import TrafficGeneration.Timestamp;
import Utility.Debug;


import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.KShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.shortestpath.KShortestPaths;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created on 2019/05/20.
 *Multi-core First Fit allocation algorithm 
 * @author sambabel.
 */
//public class CrosstalkAlgo extends BaseAlgorithm<Node2,Link2> extends FirstFit{
	public class KFirstFit  extends FirstFit{

//	public class FirstFitAllocAlgorithmn  {

    private static final Logger log = LoggerFactory.getLogger(KFirstFit.class);
   // private DijkstraShortestPath<Nodeimplement, LinkImplementation> dijkstraShortestPath;
    private double threshold;
    //protected static GraphImplement graph;
    private SimpleWeightedGraph<Node2, Link2> graph;
    public static double mape;

    public static int predictionIntervalInMins =30;
    static final int minToMs = 60*1000;
    private Map<Link2, Double> futureMap;

    protected DataCollectionPerSC dataCollection;
    private DijkstraShortestPath<Node2, Link2> dijkstraShortestPath;
    private KShortestPathAlgorithm<Node2, Link2> kShortestPathAlgorithm;
    final int k;
    public static ArrayList<Integer>noCrosstalkSpectrumBlock=Lists.newArrayList();
    // ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

     public static List<CoreSC> coreSCList=Lists.newArrayList();
     


    
    
    public KFirstFit(//double threshold,
            int k,

                final ArrayList<Service> service,
                final ArrayList<Timestamp> serviceTimestamp,
                final SimpleWeightedGraph<Node2, Link2> graph
            
    		) {
    	super(  service,serviceTimestamp, graph);
    	this.graph = graph;

dijkstraShortestPath = new DijkstraShortestPath<>(graph);
kShortestPathAlgorithm = new KShortestPaths<>(graph, k);
this.k=k;



}
 

    
    

   
    public void Execute() {
    	
    	
  
    Calendar predictionTimePoint = Calendar.getInstance();
        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
            Timestamp timestamp = getServicesOrderedQueue().get(index);
            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

           
            if (timestamp.isStartTime()) {
            	
            	
              	 
              	  Node2 src = new Node2(serviceToBeAssigned.getSource());
                  Node2 dst = new Node2(serviceToBeAssigned.getDestination());
                  
                  List<GraphPath<Node2, Link2>> weightedPaths = kShortestPathAlgorithm.getPaths(src, dst);
                 // Pair<GraphPath<Node2, Link2>, Integer> TrafficPreferredPath = filter(weightedPaths, serviceToBeAssigned);
                  List<Pair<Integer,  List<CoreSC>>> CandidatePathsResource = Lists.newArrayListWithExpectedSize(weightedPaths.size());
                  for (GraphPath<Node2, Link2> weightedPath : weightedPaths) {
                	  Pair<Integer,  List<CoreSC>>WeghtedResorces = FindPathNoCrosstalkResourcesFirstAvailable4(
                              weightedPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());
                	  CandidatePathsResource.add(WeghtedResorces);
                  }
                  
                  
                 // Restore the edge right)
            		//for (int i=0; i<weightedPaths.size(); i++) {
            			
            		

                 
                     if (CandidatePathsResource.get(0).getFirst() != BaseAlgorithm.UNAVAILABLE) {
                  //  	 assignSameCore(serviceToBeAssigned, TrafficPreferredPath.getSecond(),  TrafficPreferredPath.getFirst().getEdgeList());
                    //	 assignSpetrumResource1(serviceToBeAssigned, TrafficPreferredPath.getSecond(),  TrafficPreferredPath.getFirst().getEdgeList());
                         assignSpetrumResource12(serviceToBeAssigned, CandidatePathsResource.get(0).getFirst(),noCrosstalkSpectrumBlock, CandidatePathsResource.get(0).getSecond(), weightedPaths.get(0).getEdgeList());


                         putLinkUtilizationOutputData( graph, CandidatePathsResource.get(0).getSecond());

                         putLinkCrosstalkaffectedSlots(graph, CandidatePathsResource.get(0).getSecond());
                     log.info("The service {} is successfully assigned and meets the strong consistency conditions of the same Core number occupied by all links on the path.。", serviceToBeAssigned.getEventId());
                     //return true;
                 //    System.out.println("*****************************allocate********************************2");
       	    	//  putCurrentService(new ServiceAssignment<>(serviceToBeAssigned, TrafficPreferredPath.getSecond(), TrafficPreferredPath.getFirst().getEdgeList()));

                 } else  if (CandidatePathsResource.get(1).getFirst() != BaseAlgorithm.UNAVAILABLE) {
                     //  	 assignSameCore(serviceToBeAssigned, TrafficPreferredPath.getSecond(),  TrafficPreferredPath.getFirst().getEdgeList());
                     //	 assignSpetrumResource1(serviceToBeAssigned, TrafficPreferredPath.getSecond(),  TrafficPreferredPath.getFirst().getEdgeList());
                          assignSpetrumResource12(serviceToBeAssigned, CandidatePathsResource.get(1).getFirst(),noCrosstalkSpectrumBlock, CandidatePathsResource.get(1).getSecond(), weightedPaths.get(1).getEdgeList());


                          putLinkUtilizationOutputData( graph, CandidatePathsResource.get(1).getSecond());

                          putLinkCrosstalkaffectedSlots(graph, CandidatePathsResource.get(1).getSecond());
                      log.info("The service {} is successfully assigned and meets the strong consistency conditions of the same Core number occupied by all links on the path.。", serviceToBeAssigned.getEventId());
                      //return true;
                  //    System.out.println("*****************************allocate********************************2");
        	    	//  putCurrentService(new ServiceAssignment<>(serviceToBeAssigned, TrafficPreferredPath.getSecond(), TrafficPreferredPath.getFirst().getEdgeList()));

                  }  else  if (CandidatePathsResource.get(2).getFirst() != BaseAlgorithm.UNAVAILABLE) {
                      //  	 assignSameCore(serviceToBeAssigned, TrafficPreferredPath.getSecond(),  TrafficPreferredPath.getFirst().getEdgeList());
                      //	 assignSpetrumResource1(serviceToBeAssigned, TrafficPreferredPath.getSecond(),  TrafficPreferredPath.getFirst().getEdgeList());
                           assignSpetrumResource12(serviceToBeAssigned, CandidatePathsResource.get(2).getFirst(),noCrosstalkSpectrumBlock, CandidatePathsResource.get(2).getSecond(), weightedPaths.get(2).getEdgeList());


                           putLinkUtilizationOutputData( graph, CandidatePathsResource.get(2).getSecond());

                           putLinkCrosstalkaffectedSlots(graph, CandidatePathsResource.get(2).getSecond());
                       log.info("The service {} is successfully assigned and meets the strong consistency conditions of the same Core number occupied by all links on the path.。", serviceToBeAssigned.getEventId());
                       //return true;
                   //    System.out.println("*****************************allocate********************************2");
         	    	//  putCurrentService(new ServiceAssignment<>(serviceToBeAssigned, TrafficPreferredPath.getSecond(), TrafficPreferredPath.getFirst().getEdgeList()));

                   } 
 
                     
                     else {
                 	
                      	
                         handleAllocationFail(serviceToBeAssigned , index);
                 //       System.out.println("******************************handblocked*******************************111111111112");

                  //   }  	
                     }
                } else {
                	// If it is a business departure event
                   // return releaseService(serviceToBeAssigned);
                    handleServiceLeave(serviceToBeAssigned.getEventId());
            }
        }  
    }
    //////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////
    
    private Pair<GraphPath<Node2, Link2>, Integer> filter(
            List<GraphPath<Node2, Link2>> paths,
            Service serviceToBeAssigned) {
// // first sort by hop hop count in ascending order
     paths.sort(new Comparator<GraphPath<Node2, Link2>>() {
@Override
   public int compare(GraphPath<Node2, Link2> o1, GraphPath<Node2, Link2> o2) {
   if (o1.getLength() > o2.getLength()) {
       return 1;
    } else if (o1.getLength() < o2.getLength()){
        return -1;
      } else {
        return 0;
      }
    }
       });
    for (GraphPath<Node2, Link2> path : paths) {
    int defaultSubscript = FindPathNoCrosstalkResourcesFirstAvailable3(path.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());

     if (defaultSubscript != BaseAlgorithm.UNAVAILABLE) {
        return new Pair<>(path, defaultSubscript);
       }
      }
     return new Pair<>(null, BaseAlgorithm.UNAVAILABLE);
     }
    
    
    

	}