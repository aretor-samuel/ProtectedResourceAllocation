package RSAAgorithm;



import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

//import javafx.util.Pair;
import org.jgrapht.alg.util.Pair;

import TrafficGeneration.ServiceAssignment;
import TrafficGeneration.Service;
import Network.NodeId;
import Network.Link;
import Network.LinkID;
import Network.LinkCores;
import Network.LinkImplementation;
import DataCollection. DataCollectionPerSC;
import Network.CoreSC;
import Network.FrequencySlots;
import Network.NodeIdImplement;
import Network.Nodeimplement;
import Graph.GraphImplement;
import TrafficGeneration.Timestamp;
import Utility.Debug;
import RSAAgorithm.BaseAlgorithm;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created on 2019/05/20.
 *Multi-core First Fit allocation algorithm 
 * @author sambabel.
 */
public class FirstFitAllocAlgorithmn extends BaseAlgorithm {
//	public class FirstFitAllocAlgorithmn  {

    private static final Logger log = LoggerFactory.getLogger(FirstFitAllocAlgorithmn.class);
    private DijkstraShortestPath<Nodeimplement, LinkImplementation> dijkstraShortestPath;
    private double threshold;
    protected static GraphImplement graph;
    public static double mape;

    public static int predictionIntervalInMins =30;
    static final int minToMs = 60*1000;

    protected DataCollectionPerSC dataCollection;

    protected static Map<Double, GraphImplement> timeGraph;                          // time point, corresponding graph information status

    protected Map<Integer, Pair<List<CoreSC>, List<Integer>>> eventInfo; // The service id, and the corresponding occupied edge, core, and spectrum segments, should be written as a class.


    protected static  Map<Service, Pair<List<CoreSC>, List<Integer>>> serviceEventInfo;  // Service class, corresponding to the occupied edge, core, time, SC value, spectrum segment
    protected static Map<Double, Map<Service, Pair<List<CoreSC>, List<Integer>>>> timeServiceEventInfo;  // time point, corresponding eventInfo status

    protected Map<NodeId, Map<NodeId, List<Link>>> pathCollection;
 //private  BaseAlgorithm  BaseAlg= new BaseAlgorithm(threshold,  timeGraph, eventInfo, serviceEventInfo, timeServiceEventInfo, dataCollection );

 //  public FirstFitAllocAlgorithmn() {
  // }
    public static ServiceAssignment<Link> serviceAssignment;
    public FirstFitAllocAlgorithmn(double threshold,
    		                     final ArrayList<Service> service,
                                 final ArrayList<Timestamp> serviceTimestamp, 
                                 final GraphImplement graph,
                                  final Map<Double, GraphImplement> timeGraph,
                                  final Map<Integer, Pair<List<CoreSC>, List<Integer>>> eventInfo,
                                  final Map<Service, Pair<List<CoreSC>, List<Integer>>> serviceEventInfo,
                                  final Map<Double, Map<Service, Pair<List<CoreSC>, List<Integer>>>> timeServiceEventInfo,
                                  final Map<NodeId, Map<NodeId, List<Link>>> pathCollection,
                                  DataCollectionPerSC dataCollection) {
       super( threshold, service,serviceTimestamp, graph, timeGraph, eventInfo, serviceEventInfo, timeServiceEventInfo, dataCollection);
        this.graph = graph;
        this.timeGraph = timeGraph;
        this.eventInfo = eventInfo;
        this.serviceEventInfo = serviceEventInfo;
        this.timeServiceEventInfo = timeServiceEventInfo;
        this.pathCollection = pathCollection;
        this.dataCollection = dataCollection;

    }

    /**
     * 
      * Use FF_RSCA algorithm for Service distribution.
      * @param event service occurrence/departure event
      * @return Whether the processing was successful.
        	serviceTimestamp.get(0)

     
   // for (int index=0; index<BaseAlg.getServicesOrderedQueue().size(); index++) {
    //    Timestamp timestamp =BaseAlg.getServicesOrderedQueue().get(index);
      //  Service serviceToBeAssigned = BaseAlg.getServicesQueue().get(timestamp.getServiceIndex()-1);
	

  //  public boolean ffCascAdjNew(Service event, int serviceIndex) {
        public boolean ffCascAdjNew( Service serviceToBeAssigned,  int  serviceIndex, ArrayList<Timestamp> serviceTimestamp) {

        //	dijkstraShortestPath = new DijkstraShortestPath(graph);
                 
    
    	  // Calculate the spectrum utilization if it can be divisible
    //	 DataCollectionPerSC dataCollection= new DataCollectionPerSC(eventIndex, eventIndex, eventIndex, null, eventIndex);
      //   if (eventIndex % dataCollection.getInterval() == 0) {
        //	ArrayList<Timestamp> serviceTimestamp;
        	
    	 
    	    	 // Determine whether it is a service arrival event or a business departure event
     /**   if (event.getEventType().equals(EventType.SERVICE_ARRIVAL)) {
        	// If it is a service arrival event
            // calculation path
            //TODO is modified to be fixed

//            SdmNodeIdImpl srcId = new SdmNodeIdImpl(event.getSrc());
//            SdmNodeIdImpl dstId = new SdmNodeIdImpl(event.getDst());
        //	NodeIdImplement srcId = new NodeIdImplement(1);
        //	NodeIdImplement dstId = new NodeIdImplement(3);
          //  List<Link> path = pathCollection.get(srcId).get(dstId);*
           /////////////////////////////////////////////////
           
        //for (int index=0; index<getServicesOrderedQueue().size(); index++) {
          //  Timestamp timestamp =getServicesOrderedQueue().get(index);
          //  Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);
            // if this timestamp is start-time.
            serviceIndex =serviceToBeAssigned.getEventId();
        //    if (timestamp.isStartTime()) {
            	 if (serviceTimestamp.get(0).isStartTime()) {
           /*	 if (serviceIndex % dataCollection.getInterval() == 0) {

                 dataCollection.addSpectrumUtil(serviceIndex, eventInfo);
            }////////////////////////////////////////////////////
       
           	 NodeIdImplement srcId = new NodeIdImplement(serviceToBeAssigned.getSource());
           	 NodeIdImplement dstId = new NodeIdImplement(serviceToBeAssigned.getDestination());
               // GraphPath<NodeIdImplement, LinkImplementation> path = dijkstraShortestPath.getPath(srcId, dstId);
              //  GraphPath<NodeIdImplement, LinkImplementation> path = dijkstraShortestPath.getPath(srcId, dstId);
        //   	List<Link> path = dijkstraShortestPath.getPath(srcId, dstId);
              List<Link> path = pathCollection.get(srcId).get(dstId);
              if (path.get(0).getSrc()!= null && path.get(0).getDst()!=null) {

         // All the links on the Path take the same subscript core for service allocation attempts. This is a very strong constraint
           // if (assignSameCore(event, path)) {
                assignSameCore(serviceToBeAssigned, path);
                 /**
                  *       handleAllocationFail(serviceToBeAssigned, index);
                }
            } else {
                // if this timestamp is end-time.
                handleServiceLeave(serviceToBeAssigned.getIndex());
                  //////////////////////////////////////////////////
            	// If the assignment is successful, the business process ends.
                log.info("The service {} is successfully assigned and meets the strong consistency conditions of the same Core number occupied by all links on the path.。", serviceToBeAssigned.getEventId());
                //return true;
            } else {
            	// If the allocation fails, traverse the 7 cores based on the first edge, and find the spectrum combinations of the following edges that satisfy the spectral consistency and have no crosstalk. First fit
                // First find the spectrum segment available in the first segment of the first edge, and then find the other edges through a specific method.

            	LinkImplementation firstSdmEdge = (LinkImplementation) path.get(0);
                List<LinkCores> firstSdmEdgeCoreList = firstSdmEdge.getCoreList();
             // Exclude the 7th core
                for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size()-1; coreNum++){
                	// Find if the current core has available resources
                	LinkCores sdmCore = firstSdmEdgeCoreList.get(coreNum);
                    List<FrequencySlots> sdmCoreWavelength = sdmCore.getWavelength();
                 // Get all available spectrum segments on the core
                    List<List<Integer>> availFirstSpectrumBlock =
                            findAvaiSpectrumBlocksInOrder(sdmCoreWavelength,serviceToBeAssigned.getRequiredWaveNum());
                    // Determine whether the return value is null
                    if (availFirstSpectrumBlock == null || availFirstSpectrumBlock.isEmpty()){
                    	// If there is no spectrum resource of a certain length on the core, continue to find the next core.
                        // do nothing
                    } else {
                    	// If it is not empty, there are multiple contiguous spectrum blocks available, traversing to obtain conditions that satisfy consistency and no crosstalk
                        for (List<Integer> oneAvailFirstSpectrumBlock : availFirstSpectrumBlock) {
                        	// Determine whether there is any resource that satisfies the spectrum consistency on the other side of the current spectrum segment of the first side (on the entire Path)
                            // Yes, return the intersection spectrum segment and the core number corresponding to each edge, and include the first edge

                            Map<Link, Pair<Integer, List<Integer>>> availResourceLocation =
                                    obtainConsistentSpectrum(firstSdmEdge,coreNum, path, oneAvailFirstSpectrumBlock, serviceToBeAssigned.getRequiredWaveNum());
                            if (availResourceLocation == null || availResourceLocation.isEmpty()){
                            	// There is no return value, indicating that there is no consistent spectrum block, continue to traverse the spectrum segment of the next first edge
                                // do nothing
                            }else {
                            	// if There are resources that satisfy the spectrum consistency, and check crosstalk.
                            	//This method judges the crosstalk of the entire path, not one side.

                                if (isCrosstalk(availResourceLocation, serviceToBeAssigned.getRequiredWaveNum())){
                                	// If there is crosstalk and does not satisfy the crosstalk condition, 
                                	//continue to traverse the next segment of the spectrum - currently set to 4 hops

                                    // do nothing
                                }
                                else {
                                	// If there is no crosstalk, start distributing and updating information
                                    assignFinalSpetrum(serviceToBeAssigned, availResourceLocation);
                                    log.info("FF algorithm is successfully allocated!");
                                    return true;
                                }
                            }

                        }
                    }
                 // The core of the first edge does not satisfy the condition and continues to traverse the next core.
                }
            
             // All cores of the first edge are traversed, or there are no spectrum blocks that satisfy the condition, return false
              //  dataCollection.addBlockedEventNum();
               return false;
            }


        } else {
        	// If it is a business departure event
           // return releaseService(serviceToBeAssigned);
            return handleServiceLeave(serviceIndex);
      //  }
        
    }
       return true;

        }*/
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void Execute() {
    	
    	
    	Calendar predictionTimePoint = Calendar.getInstance();
        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
            Timestamp timestamp = getServicesOrderedQueue().get(index);
            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

            while (timestamp.getTime().after(predictionTimePoint)) {
                // Move the time backwards by a predicted time interval)
                predictionTimePoint.setTimeInMillis(predictionTimePoint.getTimeInMillis() + predictionIntervalInMins*minToMs);
                List<Timestamp> future = subList(getServicesOrderedQueue(), index);
             // Get future load conditions
                futureMap = generateOccupiedSlotsNum(future);
            }

            // Introduce the squared mean error)
            futureMap = introduceMAPE(futureMap, mape);
           int FuturerequireWaveNum= CompareRquredSlots(futureMap, serviceToBeAssigned.getRequiredWaveNum());
           // int FuturerequireWaveNum=BaseAlgorithm.UNAVAILABLE;
            // if this timestamp is start-time.
            if (timestamp.isStartTime()) {
            	
            	
              	 NodeIdImplement srcId = new NodeIdImplement(serviceToBeAssigned.getSource());
              	 NodeIdImplement dstId = new NodeIdImplement(serviceToBeAssigned.getDestination());
                 
                 List<Link> path = pathCollection.get(srcId).get(dstId);
                if (path.get(0).getSrc()!= null && path.get(0).getDst()!=null) {
                  // /  if (FuturerequireWaveNum != BaseAlgorithm.UNAVAILABLE) {
    	
    	LinkImplementation firstSdmEdge = (LinkImplementation) path.get(0);
        List<LinkCores> firstSdmEdgeCoreList = firstSdmEdge.getCoreList();
     // Exclude the 7th core
        for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size()-1; coreNum++){
        	// Find if the current core has available resources
        	LinkCores sdmCore = firstSdmEdgeCoreList.get(coreNum);
            List<FrequencySlots> sdmCoreWavelength = sdmCore.getWavelength();
         // Get all available spectrum segments on the core
            List<List<Integer>> availFirstSpectrumBlock =
                    findAvaiSpectrumBlocksInOrder(sdmCoreWavelength,serviceToBeAssigned.getRequiredWaveNum());
            // Determine whether the return value is null
            //if (availFirstSpectrumBlock == null || availFirstSpectrumBlock.isEmpty()){
                if (availFirstSpectrumBlock != null){
            
            	// If there is no spectrum resource of a certain length on the core, continue to find the next core.
                // do nothing
          //  } else {
            	// If it is not empty, there are multiple contiguous spectrum blocks available, traversing to obtain conditions that satisfy consistency and no crosstalk
                for (List<Integer> oneAvailFirstSpectrumBlock : availFirstSpectrumBlock) {
                	// Determine whether there is any resource that satisfies the spectrum consistency on the other side of the current spectrum segment of the first side (on the entire Path)
                    // Yes, return the intersection spectrum segment and the core number corresponding to each edge, and include the first edge

                    Map<Link, Pair<Integer, List<Integer>>> availResourceLocation =
                            obtainConsistentSpectrum(firstSdmEdge,coreNum, path, oneAvailFirstSpectrumBlock, serviceToBeAssigned.getRequiredWaveNum());
                 //   if (availResourceLocation == null || availResourceLocation.isEmpty()){
                    	
                        if (availResourceLocation != null){
                    	// There is no return value, indicating that there is no consistent spectrum block, continue to traverse the spectrum segment of the next first edge
                        // do nothing
                //    }else {
                    	// if There are resources that satisfy the spectrum consistency, and check crosstalk.
                    	//This method judges the crosstalk of the entire path, not one side.

                        if (!isCrosstalk(availResourceLocation, serviceToBeAssigned.getRequiredWaveNum())){
                        	// If there is crosstalk and does not satisfy the crosstalk condition, 
                        	//continue to traverse the next segment of the spectrum - currently set to 4 hops

                            // do nothing
                       
                        
                        	// If there is no crosstalk, start distributing and updating information
                           // assignFinalSpetrum(serviceToBeAssigned, availResourceLocation);
                            assignSameCorenew(serviceToBeAssigned,availResourceLocation,serviceToBeAssigned.getRequiredWaveNum(), path);
                            log.info("FF algorithm is successfully allocated!");
                        }else {
                        	  handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());
                              System.out.println("******************************handblocked*******************************1");

                        }
                        } else {
                        	  handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());
                              System.out.println("******************************handblocked*******************************2");

                        }
                        
                        }
                } else {
                	  handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());
                      System.out.println("******************************handblocked*******************************3");

                }
                    }
                }else {
                	  handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());
                      System.out.println("******************************handblocked*******************************4");

                }
            } else {
            	// If it is a business departure event
               // return releaseService(serviceToBeAssigned);
                handleServiceLeave(serviceToBeAssigned.getEventId());
                System.out.println("**********************************handle pasedservices**************************");
            }
        }
    	/**Calendar predictionTimePoint = Calendar.getInstance();
        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
            Timestamp timestamp = getServicesOrderedQueue().get(index);
            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

            while (timestamp.getTime().after(predictionTimePoint)) {
                // Move the time backwards by a predicted time interval)
                predictionTimePoint.setTimeInMillis(predictionTimePoint.getTimeInMillis() + predictionIntervalInMins*minToMs);
                List<Timestamp> future = subList(getServicesOrderedQueue(), index);
             // Get future load conditions
                futureMap = generateOccupiedSlotsNum(future);
            }

            // Introduce the squared mean error)
            futureMap = introduceMAPE(futureMap, mape);
           int FuturerequireWaveNum= CompareRquredSlots(futureMap, serviceToBeAssigned.getRequiredWaveNum());
           // int FuturerequireWaveNum=BaseAlgorithm.UNAVAILABLE;
            // if this timestamp is start-time.
            if (timestamp.isStartTime()) {
            	
            	
              	 NodeIdImplement srcId = new NodeIdImplement(serviceToBeAssigned.getSource());
              	 NodeIdImplement dstId = new NodeIdImplement(serviceToBeAssigned.getDestination());
                 
                 List<Link> path = pathCollection.get(srcId).get(dstId);
               //  if (path.get(0).getSrc()!= null && path.get(0).getDst()!=null) {
                   /  if (FuturerequireWaveNum != BaseAlgorithm.UNAVAILABLE) {
                	 assignSameCore(serviceToBeAssigned, serviceToBeAssigned.getRequiredWaveNum(),  path);
                		// If the assignment is successful, the business process ends.
                     log.info("The service {} is successfully assigned and meets the strong consistency conditions of the same Core number occupied by all links on the path.。", serviceToBeAssigned.getEventId());
                     //return true;
                     System.out.println("*****************************allocate********************************2");

                 } else {
                 	
                     handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());
                     System.out.println("******************************handblocked*******************************2");

                 	// If the allocation fails, traverse the 7 cores based on the first edge, and find the spectrum combinations of the following edges that satisfy the spectral consistency and have no crosstalk. First fit
                     // First find the spectrum segment available in the first segment of the first edge, and then find the other edges through a specific method.
                 }
            } else {
            	// If it is a business departure event
               // return releaseService(serviceToBeAssigned);
                handleServiceLeave(serviceToBeAssigned.getEventId());
                System.out.println("**********************************handle pasedservices**************************2");

            }
        }*/    
    }
    //////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        public void Execute() {
        	Calendar predictionTimePoint = Calendar.getInstance();
            predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

            for (int index=0; index<getServicesOrderedQueue().size(); index++) {
                Timestamp timestamp = getServicesOrderedQueue().get(index);
                Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

                while (timestamp.getTime().after(predictionTimePoint)) {
                    // Move the time backwards by a predicted time interval)
                    predictionTimePoint.setTimeInMillis(predictionTimePoint.getTimeInMillis() + predictionIntervalInMins*minToMs);
                    List<Timestamp> future = subList(getServicesOrderedQueue(), index);
                 // Get future load conditions
                 //   futureMap = generateOccupiedSlotsNum(future);
                }
                if (timestamp.isStartTime()) {
                	
                	
                 	 NodeIdImplement srcId = new NodeIdImplement(serviceToBeAssigned.getSource());
                 	 NodeIdImplement dstId = new NodeIdImplement(serviceToBeAssigned.getDestination());
                    
                    List<Link> path = pathCollection.get(srcId).get(dstId);
                    if (path.get(0).getSrc()!= null && path.get(0).getDst()!=null) {
                     if   (assignSameCore(serviceToBeAssigned, path)) {
                        log.info("The service {} is successfully assigned and meets the strong consistency conditions of the same Core number occupied by all links on the path.。", serviceToBeAssigned.getEventId());
                    //    return true;
                    } else {
                    	// If the allocation fails, traverse the 7 cores based on the first edge, and find the spectrum combinations of the following edges that satisfy the spectral consistency and have no crosstalk. First fit
                        // First find the spectrum segment available in the first segment of the first edge, and then find the other edges through a specific method.

                    	LinkImplementation firstSdmEdge = (LinkImplementation) path.get(0);
                        List<LinkCores> firstSdmEdgeCoreList = firstSdmEdge.getCoreList();
                     // Exclude the 7th core
                        for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size()-1; coreNum++){
                        	// Find if the current core has available resources
                        	LinkCores sdmCore = firstSdmEdgeCoreList.get(coreNum);
                            List<FrequencySlots> sdmCoreWavelength = sdmCore.getWavelength();
                         // Get all available spectrum segments on the core
                            List<List<Integer>> availFirstSpectrumBlock =
                                    findAvaiSpectrumBlocksInOrder(sdmCoreWavelength,serviceToBeAssigned.getRequiredWaveNum());
                            // Determine whether the return value is null
                            if (availFirstSpectrumBlock == null || availFirstSpectrumBlock.isEmpty()){
                            	// If there is no spectrum resource of a certain length on the core, continue to find the next core.
                                // do nothing
                            } else {
                            	// If it is not empty, there are multiple contiguous spectrum blocks available, traversing to obtain conditions that satisfy consistency and no crosstalk
                                for (List<Integer> oneAvailFirstSpectrumBlock : availFirstSpectrumBlock) {
                                	// Determine whether there is any resource that satisfies the spectrum consistency on the other side of the current spectrum segment of the first side (on the entire Path)
                                    // Yes, return the intersection spectrum segment and the core number corresponding to each edge, and include the first edge

                                    Map<Link, Pair<Integer, List<Integer>>> availResourceLocation =
                                            obtainConsistentSpectrum(firstSdmEdge,coreNum, path, oneAvailFirstSpectrumBlock, serviceToBeAssigned.getRequiredWaveNum());
                                    if (availResourceLocation == null || availResourceLocation.isEmpty()){
                                    	// There is no return value, indicating that there is no consistent spectrum block, continue to traverse the spectrum segment of the next first edge
                                        // do nothing
                                    }else {
                                    	// if There are resources that satisfy the spectrum consistency, and check crosstalk.
                                    	//This method judges the crosstalk of the entire path, not one side.

                                        if (isCrosstalk(availResourceLocation, serviceToBeAssigned.getRequiredWaveNum())){
                                        	// If there is crosstalk and does not satisfy the crosstalk condition, 
                                        	//continue to traverse the next segment of the spectrum - currently set to 4 hops

                                            // do nothing
                                        }
                                        else {
                                        	// If there is no crosstalk, start distributing and updating information
                                            assignFinalSpetrum(serviceToBeAssigned, availResourceLocation);
                                            log.info("FF algorithm is successfully allocated!");
                                      //      putCurrentService(new ServiceAssignment<>(serviceToBeAssigned, serviceToBeAssigned.getEventId(), path));;

                                         //   return true;
                                        }
                                    }

                                }
                            }
                         // The core of the first edge does not satisfy the condition and continues to traverse the next core.
                        } 
                     //   putCurrentService(new ServiceAssignment<>(serviceToBeAssigned, serviceToBeAssigned.getEventId(), path));;

                    }
                  //   putCurrentService(new ServiceAssignment<>(serviceToBeAssigned, serviceToBeAssigned.getEventId(), path));;

                    } else {
                    	// If it is a business departure event
                       // return releaseService(serviceToBeAssigned);
                        handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());


                  //  }
                    
                
                    }
                    
                } else {
                	// If it is a business departure event
                   // return releaseService(serviceToBeAssigned);
                    handleServiceLeave(serviceToBeAssigned.getEventId());
        	
        }
                }
                }
        
        public void handleServiceLeave(int leaveServiceIndex) {
            if (getCurrentServices().containsKey(leaveServiceIndex)) {
                ServiceAssignment<Link> serviceAssignment = getCurrentServices().get(leaveServiceIndex);
                releaseService(serviceAssignment.getService());
                putPassedService(
                        removeCurrentService(leaveServiceIndex));
            } else if (getBlockedServices().containsKey(leaveServiceIndex)){
                // TODO
                // Actually, there is nothing to do here. Just for readability.
            } else {
                throw new RuntimeException("The leave service belongs to neither assigned services, nor blocked services.");
            }
			//return true;
        }



    /**
     * For the processing of the business departure event, the resources occupied by the service are released.
      * @param endEvent Business departure event
      * @return Whether to release the resource successfully
     */
   // private boolean releaseService(Service endEvent) {
      //  private void releaseService(Service endEvent) {
            private void releaseService(Service endEvent) {



//        Pair<List<CoreSC>, List<Integer>> pair = eventInfo.get(endEvent.getEventId());
        Pair<List<CoreSC>, List<Integer>> pairService = serviceEventInfo.get(endEvent);
     // If the service is successfully assigned when the service happens
        if (pairService != null) {
          //  List<CoreSC> coreSCList = pairService.getKey();
          //  List<Integer> occupiedIndexes = pairService.getValue();
        	 List<CoreSC> coreSCList = pairService.getFirst();
             List<Integer> occupiedIndexes = pairService.getSecond();

            for (CoreSC coreSC : coreSCList) {
                LinkCores sdmCore = mapToCore(coreSC);
                if (sdmCore != null){
                    List<FrequencySlots> wavelengths = sdmCore.getWavelength();
                    for (int index : occupiedIndexes) {
                        if (!wavelengths.get(index).getIsOccupied() ||
                                wavelengths.get(index).getWaveServiceId() != endEvent.getEventId()) {
                        	// If the service is successfully assigned when the service happens
                        	// throws an exception if the resource was not previously occupied or occupied, but the occupant is not the service.
                           throw new RuntimeException("Since the service does not occupy the corresponding resources, the service is released.\n" + 
                           		"！");
                        }
                     // free resources
                      //  wavelengths.get(index).setIsOccupied(false);
                        wavelengths.get(index).setOccupiedServiceIndex(1);;

                        wavelengths.get(index).setwaveServiceId(-1);
                    }
                }else {
                    throw new RuntimeException("if The mapToCore method does not find the corresponding occupied core in the graph, the service release fails.\n" + 
                    		"！");
                }
            }
         //   serviceEventInfo.remove(endEvent);
      /**      if (endEvent.getRequestType() == RequestType.IR){
                timeGraph.put(endEvent.getArriveTime()+endEvent.getHoldTime(), graph);
                timeServiceEventInfo.put(endEvent.getArriveTime()+endEvent.getHoldTime(), serviceEventInfo);
            }else if (endEvent.getRequestType() == RequestType.AR){
                timeGraph.put(endEvent.getEndTime(), graph);
                timeServiceEventInfo.put(endEvent.getEndTime(), serviceEventInfo);
            }else {
                log.info("No such service request type");
            }*/

        //    return true;
        } else {
        	// allocation fails if the service happens
          //  dataCollection.addBlockedEventNum();
           // return false;
        }
    }

    /**
     * According to the final set of spectrum numbers provided by finalResult, the resource occupation operation is performed in all Cores corresponding to maxCoreScPerEdge.
      * @param serviceEvent event
      * @param availResourceLocation The selected spectrum segments that satisfy the consistency and no crosstalk conditions, and their specific edges,
     */
    private static void assignFinalSpetrum (Service serviceEvent, Map<Link, Pair<Integer, List<Integer>>> availResourceLocation) {

    	List<CoreSC> coreScPerEdgeList = new ArrayList<CoreSC>();
        List<List<Integer>> finalResultDoubleList = new ArrayList<List<Integer>>();
        int eventId = serviceEvent.getEventId();
    //    int eventId =1;
        // occupy the corresponding spectrum resources
        for (Link edge : availResourceLocation.keySet()) {
        	// information about the edge, coreIndex, etc. of the current traversal edge
            LinkImplementation sdmEdge = (LinkImplementation) edge;
          //  int coreIndex = availResourceLocation.get(edge).getKey();
            //List<Integer> finalResultMark = availResourceLocation.get(edge).getValue();
            int coreIndex = availResourceLocation.get(edge).getFirst();
            List<Integer> finalResultMark = availResourceLocation.get(edge).getSecond();


            // Get the core, wavelength corresponding to the edge
            LinkCores sdmCore = sdmEdge.getCoreList().get(coreIndex);
            ///////////////////////////////////////////////////////////
            CoreSC coreSCValue = calculateCoreSc(sdmEdge.getEdgeId(), sdmEdge.getCoreList().get(coreIndex),
                    serviceEvent.getRequiredWaveNum());                       
            double time = 0;                                                 
      /*      if (serviceEvent.getRequestType() == RequestType.IR){
                time = serviceEvent.getArriveTime();
            }else if(serviceEvent.getRequestType() == RequestType.AR){
                time = serviceEvent.getStartTime();
            }else {
                log.info("No such service request type");
            }*/
            

            CoreSC coreSc = new CoreSC(time, sdmEdge.getEdgeId(), coreIndex, coreSCValue.getSc());
            coreScPerEdgeList.add(coreSc);
         // Add spectrum information, note that there are two lists stored here, because there are multiple traversals, but the spectrum segments are the same, then take the first one, which is the same anyway.           
            List<Integer> tmp = new ArrayList<Integer>();
            for (int spectrumInfo : finalResultMark){
                tmp.add(spectrumInfo);
            }
            finalResultDoubleList.add(tmp);
        
     // is the same, take the first one
        List<Integer> finalResult = finalResultDoubleList.get(0);

     // Put the service allocation information into eventInfo.
        StringBuilder occupiedIndex = new StringBuilder("{");
        for (int i : finalResult) {
            occupiedIndex.append(i+",");
        }
        occupiedIndex.deleteCharAt(occupiedIndex.lastIndexOf(","));
        occupiedIndex.append("}");
        log.info("Assign service success. The service id is {}\\t service occupation resource number is {}\\t\\t\\t, and the service passing node is {}\n" + 
        		"", occupiedIndex, coreScPerEdgeList);

        serviceEventInfo.put(serviceEvent, new Pair<List<CoreSC>, List<Integer>>(coreScPerEdgeList, finalResult));
            ///////////////////////////////////////////////////////////
            List<FrequencySlots> wavelengthList = sdmCore.getWavelength();

         // occupy the corresponding resources
            for (int needOccupied : finalResultMark) {
                if (wavelengthList.get(needOccupied).getIsOccupied()) {
                	//  this kind of exception should not happen. Once it happens, it is definitely a problem with the logic inside the program. 
                	//This program can be terminated.

                    log.error("Insufficient resources to allocate service");
                } else {
                 //   wavelengthList.get(needOccupied).setIsOccupied(true);
                wavelengthList.get(needOccupied).setOccupiedServiceIndex(0);
                    wavelengthList.get(needOccupied).setwaveServiceId(eventId);
               //     System.out.println(wavelengthList);

                }
            }
        }
//updating serviceEventInfo 
    /*    
        List<CoreSC> coreScPerEdgeList = new ArrayList<CoreSC>();
        List<List<Integer>> finalResultDoubleList = new ArrayList<List<Integer>>();
        for (Link changeEdge : availResourceLocation.keySet()){
//        for (Map.Entry<Edge, Pair<Integer, List<Integer>>> edgePairEntry : availResourceLocation.entrySet()){
        	// information about the edge, coreIndex, etc. of the current traversal edge
            LinkImplementation sdmEdge = (LinkImplementation) changeEdge;                  
            int coreIndex = availResourceLocation.get(changeEdge).getKey();   
            List<Integer> finalResultMark = availResourceLocation.get(changeEdge).getValue();
            CoreSC coreSCValue = calculateCoreSc(sdmEdge.getEdgeId(), sdmEdge.getCoreList().get(coreIndex),
                    serviceEvent.getRequiredWaveNum());                       
            double time = 0;                                                 
      /*      if (serviceEvent.getRequestType() == RequestType.IR){
                time = serviceEvent.getArriveTime();
            }else if(serviceEvent.getRequestType() == RequestType.AR){
                time = serviceEvent.getStartTime();
            }else {
                log.info("No such service request type");
            }*/

     /**       CoreSC coreSc = new CoreSC(time, sdmEdge.getEdgeId(), coreIndex, coreSCValue.getSc());
            coreScPerEdgeList.add(coreSc);
         // Add spectrum information, note that there are two lists stored here, because there are multiple traversals, but the spectrum segments are the same, then take the first one, which is the same anyway.           
            List<Integer> tmp = new ArrayList<Integer>();
            for (int spectrumInfo : finalResultMark){
                tmp.add(spectrumInfo);
            }
            finalResultDoubleList.add(tmp);
        }
     // is the same, take the first one
        List<Integer> finalResult = finalResultDoubleList.get(0);

     // Put the service allocation information into eventInfo.
        StringBuilder occupiedIndex = new StringBuilder("{");
        for (int i : finalResult) {
            occupiedIndex.append(i+",");
        }
        occupiedIndex.deleteCharAt(occupiedIndex.lastIndexOf(","));
        occupiedIndex.append("}");
        log.info("Assign service success. The service id is {}\\t service occupation resource number is {}\\t\\t\\t, and the service passing node is {}\n" + 
        		"", occupiedIndex, coreScPerEdgeList);

        serviceEventInfo.put(serviceEvent, new Pair<List<CoreSC>, List<Integer>>(coreScPerEdgeList, finalResult));
    /**    if (serviceEvent.getRequestType() == RequestType.IR){
            timeGraph.put(serviceEvent.getArriveTime(), graph);
            timeServiceEventInfo.put(serviceEvent.getArriveTime(), serviceEventInfo);
        }else if(serviceEvent.getRequestType() == RequestType.AR){
            timeGraph.put(serviceEvent.getStartTime(), graph);
            timeServiceEventInfo.put(serviceEvent.getStartTime(), serviceEventInfo);
        }else {
            log.info("No such service request type");
        }*/
    }

    /**
     * A list of available spectrum blocks in the list of wavelengths is found, and various spectrum combinations with lengths of requiredWaveNum are selected.
      * Note: The Integer value contained in the return value is incremented by subscript. List<Integer> in List<n> must be less than List<n+1>
      * @param wavelengths List of spectra being viewed
      * @return Returns null if no spectrum list is available, and returns all combinations of the available spectrum blocks with the required length of requiredWaveNum.
     */
    private static List<List<Integer>> findAvaiSpectrumBlocksInOrder(List<FrequencySlots> wavelengths, int requiredWaveNum) {
        List<List<Integer>> rtn = new ArrayList<List<Integer>>();
     // This bool value indicates whether a new block value needs to be opened.
        boolean newBlock = true;
        List<Integer> avaiSpecBlock = null;
        for (int i=0; i<wavelengths.size(); i++) {
            if (!wavelengths.get(i).getIsOccupied()) {
                if (newBlock) {
                    avaiSpecBlock = new ArrayList<Integer>();
                    avaiSpecBlock.add(i);
                    newBlock = false;
                } else {
                    avaiSpecBlock.add(i);
                }
            } else {
                newBlock = true;
                if (avaiSpecBlock != null) {
                    rtn.add(avaiSpecBlock);
                    avaiSpecBlock = null;
                }
            }
        }
        if (avaiSpecBlock != null) {
            rtn.add(avaiSpecBlock);
        }

     // Determine the combination of the last available spectrum block. If it is null, it returns null. If it is not empty, the length of the spectrum segment is greater than or equal to the request length.       
        if (rtn.isEmpty()) {
            return null;
        } else {
        	// Filter out List<Integer> that does not satisfy the requested spectrum in List<List<Integer>>        	
            List<List<Integer>> filtered = enoughSpectrumBlockFilter(rtn, requiredWaveNum);
            if (filtered == null) {
                return null;
            }else {
            	// All combinations of spectra for the spectrum block that meets the length, the length is requiredWaveNum, and returns
                List<List<Integer>> filtered1 = genAvaiCombinations(filtered, requiredWaveNum);
                if (filtered1 == null) {
                    return null;
                }else {
                    return filtered1;
                }
            }
        }
    }

    /**
     * 
      * Determine the spectrum combination of the list avaiBlock of available spectrum resource blocks.
      * Note 1: The return value and the incoming avaiBlock point to not the same memory address!
      * Note 2: This method defaults to avaiBlock non-null non-empty and contains enough resources. Therefore, the relevant decision is made when the method is called.
      * @param avaiBlocks List of available spectrum resource blocks
      * @param requiredWaveNum Required spectrum resources
      * @return According to Note 2, there must be a spectrum combination that satisfies the condition, so the return value cannot be null or empty.
     */
    private static List<List<Integer>> genAvaiCombinations(List<List<Integer>> avaiBlocks, int requiredWaveNum) {

        List<List<Integer>> rtn = new ArrayList<List<Integer>>();
        for (List<Integer> block : avaiBlocks) {
        	// window indicates the size of the window whose length is requiredWaveNum can be slid in the block spectrum segment.
            int window = block.size() - requiredWaveNum;
            for (int i=0; i<=window; i++) {
            	// subList contains the left border and does not contain the right border
                rtn.add(
                        copyOf(
                                block.subList(i, requiredWaveNum+i)));
            }
        }

        return rtn;
    }

    /**
     * Filter out the spectrum segment of the spectrum segment that does not provide the requiredWaveNum number in the spectrumBlock.
      * Note 1: The content of the default input spectrumBlock is ascending, and List<Integer> in List<n> must be smaller than List<n+1>. The return value is also ascending.
      * Note 2: The return value is actually the reference spectrumBlock, they point to the same block of memory. Need to change the return value to void?
      * Note 3: This method does not detect the incoming spectrumBlock. The logic that calls this method by default should ensure that the parameter is not null and is not empty.
      * @param spectrumBlock spectrum block to be filtered
      * @param requiredWaveNum Required contiguous spectrum block resources
      * @return Returns null if none of the required spectrum blocks are present.。
     */
    private static List<List<Integer>> enoughSpectrumBlockFilter(List<List<Integer>> spectrumBlock, int requiredWaveNum) {
        for (int i=spectrumBlock.size()-1; i>=0; i--) {
            if (spectrumBlock.get(i).size() < requiredWaveNum) {
                spectrumBlock.remove(i);//remove it and reverse traversal

            }
        }
        if (spectrumBlock.isEmpty()) {
            return null;
        }
        return spectrumBlock;
    }

    /**
     *  Returns whether the specified spectrum segment of the first edge has a resource that satisfies the consistency on the entire path, and also needs a similar method to return the specific core number of the specific edge.
      * @param firstSdmEdge first side
      * @param path Entire path
      * @param oneAvailFirstSpectrumBlock The spectrum segment of the first side
      * @return Whether there is a spectrum resource that satisfies the consistency, there is a return true, no return fa
lse
     */
    public boolean isConsistent(Link firstSdmEdge, List<Link> path, List<Integer> oneAvailFirstSpectrumBlock,
                                int requiredWaveNum){

    	// OneAvailFirstSpectrumBlock changed address storage, all edges share this variable, has been changing
        List<Integer> rtnOneAvailFirstSpectrumBlock = new ArrayList<Integer>();
        for (Integer firstInteger : oneAvailFirstSpectrumBlock){
            rtnOneAvailFirstSpectrumBlock.add(firstInteger);
        }

        // Record the number of consistent edges
        int count = 0;
        for (Link edge : path){
        	// Exclude the first core
            if (!edge.equals(firstSdmEdge)){
                LinkImplementation sdmEdge = (LinkImplementation) edge;
                List<LinkCores> sdmCoreList = sdmEdge.getCoreList();
                for (LinkCores sdmCore : sdmCoreList){
                    List<FrequencySlots> wavelengthList = sdmCore.getWavelength();
                 // Get all the spectrum blocks of the current edge that meet the length
                    List<List<Integer>> availSpectrumBlock = findAvaiSpectrumBlocksInOrder(wavelengthList, requiredWaveNum);
                    // Determine whether all available spectrum blocks on the edge contain the requested spectrum segment, have an intersection count plus 1, and stop the core traversal, continue the traversal of the next edge,
                    // Record the current core linkcore number, all edges are satisfied, return true, if there is no intersection to continue the next core traversal

                    rtnOneAvailFirstSpectrumBlock = findCommonSpectrumBlock(rtnOneAvailFirstSpectrumBlock,
                            availSpectrumBlock,requiredWaveNum);
                    if (rtnOneAvailFirstSpectrumBlock == null){
                    	// Does not include traversal to continue the next core, but to restore the rtnOneAvailFirstSpectrumBlock variable to before, null needs to be renewed
                        //rtnOneAvailFirstSpectrumBlock will return to edge, because the core is not satisfied, continue to the next core, not the next edge, if it is the edge, then there is no need to recover
                        rtnOneAvailFirstSpectrumBlock = new ArrayList<Integer>();
                        for (Integer firstInteger : oneAvailFirstSpectrumBlock){
                            rtnOneAvailFirstSpectrumBlock.add(firstInteger);
                        }
                    }else if (rtnOneAvailFirstSpectrumBlock.isEmpty()){
                    	// does not include traversal to continue the next core, but to restore the rtnOneAvailFirstSpectrumBlock variable to the previous, not null but
                        // is empty and only needs to be reassigned, traversing the new core
                        for (Integer firstInteger : oneAvailFirstSpectrumBlock){
                            rtnOneAvailFirstSpectrumBlock.add(firstInteger);
                        }
                    } else {
                    	// There is an intersection count plus 1, and stop the traversal of the core, continue the traversal of the next edge, and record the current core Sdmcore number, without any processing on rtn
                        int coreIndex = sdmCore.getId();
                        count++;
                        break;
                    }
                }
            }
        }
        // Note that the entire Path meets the consistency
        if (count == path.size()-1){
            return true;
        }else {
            return false;
        }

    }

    /**
     * Returns whether the specified spectrum segment of the first edge has a resource that satisfies the consistency on the entire path, and also needs a similar method to return the specific core number of the specific edge.
      * @param firstSdmEdge first side
      * @param coreNum Current core number of the first side
      * @param path Entire path
      * @param oneAvailFirstSpectrumBlock The spectrum segment of the first side
      * @return Is there a spectrum resource that satisfies consistency? , There are edges that satisfy the spectrum segment, the corresponding core, and the intersection spectrum segment.

     */
    public Map<Link, Pair<Integer, List<Integer>>> obtainConsistentSpectrum(Link firstSdmEdge, int coreNum,
                                                                            List<Link> path,
                                                                            List<Integer> oneAvailFirstSpectrumBlock,
                                                                            int requiredWaveNum){

    	// return value, edge - available core number - available intersection spectrum segment
        Map<Link, Pair<Integer, List<Integer>>> rtn = new HashMap<Link, Pair<Integer, List<Integer>>>();
        Map<Link, Integer> rtnEdgeCoreIndex = new HashMap<Link, Integer>();

        // OneAvailFirstSpectrumBlock changed address storage, all edges share this variable, has been changing
        List<Integer> rtnOneAvailFirstSpectrumBlock = new ArrayList<Integer>();
        for (Integer firstInteger : oneAvailFirstSpectrumBlock){
            rtnOneAvailFirstSpectrumBlock.add(firstInteger);
        }

        // Record the number of consistent edges
        int count = 0;
        for (Link edge : path){
        	// Exclude the first core
        	   // checking the consistency should be done with exclusion of  the 7th core

            if (!edge.equals(firstSdmEdge)){
                LinkImplementation sdmEdge = (LinkImplementation) edge;
                List<LinkCores> sdmCoreList = sdmEdge.getCoreList();
                for (int i = 0; i<sdmCoreList.size()-1; i++){
                	LinkCores sdmCore = sdmCoreList.get(i);
                    List<FrequencySlots> wavelengthList = sdmCore.getWavelength();
                 // Get all the spectrum blocks of the current edge that meet the length
                    List<List<Integer>> availSpectrumBlock = findAvaiSpectrumBlocksInOrder(wavelengthList, requiredWaveNum);
                    if (availSpectrumBlock == null || availSpectrumBlock.isEmpty()){
                    	// is empty, continue to traverse the next core
                    }else {
                    	// Determine whether all available spectrum blocks on the edge contain the requested spectrum segment, have an intersection count plus 1, and stop the core traversal, continue the traversal of the next edge,
                        // Record the current core Sdmcore number, all edges are satisfied, return true, if there is no intersection to continue the next core traversal

                        rtnOneAvailFirstSpectrumBlock = findCommonSpectrumBlock(rtnOneAvailFirstSpectrumBlock,
                                availSpectrumBlock,requiredWaveNum);
                        if (rtnOneAvailFirstSpectrumBlock == null){
                        	// Does not include traversal to continue the next core, but to restore the rtnOneAvailFirstSpectrumBlock variable to the previous state, null needs to be renewed
                        	  // rtnOneAvailFirstSpectrumBlock will return to edge, because the core is not satisfied, continue to the next core, not the next edge, if it is the edge, then there is no need to recover
                            rtnOneAvailFirstSpectrumBlock = new ArrayList<Integer>();
                            for (Integer firstInteger : oneAvailFirstSpectrumBlock){
                                rtnOneAvailFirstSpectrumBlock.add(firstInteger);
                            }
                        }else if (rtnOneAvailFirstSpectrumBlock.isEmpty()){
                        	// does not include traversal to continue the next core, but to restore the rtnOneAvailFirstSpectrumBlock variable to the previous, not null but
                        	  // is empty and only needs to be reassigned, traversing the new core

                            for (Integer firstInteger : oneAvailFirstSpectrumBlock){
                                rtnOneAvailFirstSpectrumBlock.add(firstInteger);
                            }
                        } else {
                        	// There is an intersection count plus 1, and stop the traversal of the core, continue the traversal of the next edge, and record the current core Sdmcore number, without any processing on rtn
                            int coreIndex = sdmCore.getId();
                            count++;
                            rtnEdgeCoreIndex.put(edge, coreIndex);
                            break;
                        }
                    }
                }
            }
        }
        // Note that the entire Path meets the consistency
        if (count == path.size()-1){
        	// Add the core and spectrum information of the first side
            rtn.put(firstSdmEdge, new Pair<Integer, List<Integer>>(coreNum, rtnOneAvailFirstSpectrumBlock));
         // Add the number of the following core and the spectrum and other information
            for (Link tmpEdge : rtnEdgeCoreIndex.keySet()){
                int coreIndex = rtnEdgeCoreIndex.get(tmpEdge);
                rtn.put(tmpEdge, new Pair<Integer, List<Integer>>(coreIndex, rtnOneAvailFirstSpectrumBlock));
            }
            return rtn;
        }else {
            return null;
        }

    }

    /**
      * Find the intersection of spectrum blocks
      * @param oneAvailFirstSpectrumBlock spectrum segment
      * @param availSpectrumBlock spectrum block set
      * @return intersection
     */
    public List<Integer> findCommonSpectrumBlock(List<Integer> oneAvailFirstSpectrumBlock,
                                                 List<List<Integer>> availSpectrumBlock, int requireWaveNum){
    	// A spectrum block is searched for a spectrum block, and the intersection is taken.
        for (List<Integer> oneAvailSpectrumBlock : availSpectrumBlock){

        	// store first and last with another address
            List<Integer> tmpOneAvailFirstSpectrumBlock = new ArrayList<Integer>();
            List<Integer> tmpOneAvailSpectrumBlock = new ArrayList<Integer>();
            for (Integer firstInteger : oneAvailFirstSpectrumBlock){
                tmpOneAvailFirstSpectrumBlock.add(firstInteger);
            }
            for (Integer latterInteger : oneAvailSpectrumBlock){
                tmpOneAvailSpectrumBlock.add(latterInteger);
            }

            // check the size, take the intersection
            if (tmpOneAvailSpectrumBlock.size() >= tmpOneAvailFirstSpectrumBlock.size()){
            	// The error found by the 1st float, the retafindCommonSpectrumBlockinAll method will return false if the set is not modified. If the two spectrum segment numbers are identical, the condition is returned and false is returned.
                tmpOneAvailSpectrumBlock.retainAll(tmpOneAvailFirstSpectrumBlock);
             // Take the intersection successfully and check whether the intersection size meets the request length
                if (tmpOneAvailSpectrumBlock.size() >= requireWaveNum){
                	// Satisfy the size, indicating that the intersection is successful, return this intersection
                    return tmpOneAvailSpectrumBlock;
                }
            }else {
                tmpOneAvailFirstSpectrumBlock.retainAll(tmpOneAvailSpectrumBlock);
             // Take the intersection successfully and check whether the intersection size meets the request length
                if (tmpOneAvailFirstSpectrumBlock.size() >= requireWaveNum){
                	// Satisfy the size, indicating that the intersection is successful, return this intersection
                    return tmpOneAvailFirstSpectrumBlock;
                }
            }
        }
     // traversed all the spectrum blocks, still did not find the intersection, return null
        return null;
    }

    /**
     *Determine whether the first edge and all the edges on the path satisfy the consistency of the spectrum segment for crosstalk
      * @param availResourceLocation other sides and core
      * @return Is there crosstalk, it returns true, no false is returned
     */
    public boolean isCrosstalk( Map<Link, Pair<Integer, List<Integer>>>  availResourceLocation,
                               int requiredWaveNum){

        List<List<Integer>> rtn = new ArrayList<List<Integer>>();

     // Record the number of edges that satisfy the crosstalk condition, and compare it with the total number of edges.
        int countEdge = 0;
     // This contains the first side, that is, all sides of Path have
        for (Link edge : availResourceLocation.keySet()){

        	// information about the edge, coreIndex, etc. of the current traversal edge
            LinkImplementation otherSdmEdge = (LinkImplementation) edge;
           // int coreIndex = availResourceLocation.get(edge).getKey();
            //List<Integer> commonSpectrum = availResourceLocation.get(edge).getValue();
            int coreIndex = availResourceLocation.get(edge).getFirst();
            List<Integer> commonSpectrum = availResourceLocation.get(edge).getSecond();


         // Store the spectrum block with a temporary address, the size must be the requiredWaveNum length, so don't delete it.
            List<Integer> tmpAvailResourceLocation = new ArrayList<Integer>();
            for (Integer tmpInteger : commonSpectrum){
                tmpAvailResourceLocation.add(tmpInteger);
            }

         // The neighboring and information of the selected core of the current traversal edge
            LinkCores otherSdmCore = otherSdmEdge.getCoreList().get(coreIndex);

            // Record the number of slots without crosstalk in the spectrum segment, and the size of tmpAvailResourceLocation, indicating that there is no crosstalk in the entire band, return false
            int countSlot = 0;
            // Determine the crosstalk of adjacent cores, traversing from large to small
            for (int i = 0; i < tmpAvailResourceLocation.size(); i++) {
                int index = tmpAvailResourceLocation.get(i);
                int count = 0;
                // 遍历邻接的Core, 看index这个slot是否有串扰
                for (LinkCores adjCore : otherSdmCore.getAdjacentCores()) {
                    if (adjCore.getWavelength().get(index).getIsOccupied()) {
                        count++;
                    }
                }
             // Remove itself, the neighboring cores are only 3 in total, and the count counts the number of adjacent cores.
                if (count >= otherSdmCore.getAdjacentCores().size()){
                	// greater than or equal to 3 indicates crosstalk
                    // For the same spectrum slot, if there are multiple adjacent cores already occupied, indicating crosstalk, then this segment does not satisfy the crosstalk condition, resulting in this spectrum segment.
                    // The entire Path will not work, directly return true crosstalk, and then traverse the next spectrum segment of the first edge
                    //T has modified the crosstalk condition. There is a problem here. The total number of adjacent cores is 3, which is not enough. Although it is up to 3
                    return true;
                }else {
                	// Explain that the indexSlot has no crosstalk, and countSlot adds one
                	countSlot++;
                }
            }

         // Determine if all tmpAvailResourceLocations have met the crosstalk-free condition
            if (countSlot == tmpAvailResourceLocation.size()){
            	// Satisfy all tmpAvailResourceLocation without crosstalk, indicating that this side is completely OK, countEdge plus one

                countEdge++;
            }
        }

     // Determine if all edges have met the crosstalk-free condition
        if (countEdge == availResourceLocation.size()){
        	// The specified spectrum segment of all edges has no crosstalk and returns false
            return false;
        }else {
            return true;
        }

    }

    protected Map<Link, Double> generateOccupiedSlotsNum(List<Timestamp> orderedList) {
        // initialize occupiedSlotsNum
        Map<Link, Double> occupiedSlotsNum = Maps.newHashMap();
       // for (Link edge : getGraph().edgeSet()) {
      //  LinkImplementation sdmEdge = (LinkImplementation) graph.getEdges().values();

          for (Link edge : graph.getEdges().values()) {

            occupiedSlotsNum.put(edge, 0.0d);
        }


        // collect current services
        for (ServiceAssignment<Link> servAssign : getCurrentServices().values()) {
        	execFutureServiceAssignment(occupiedSlotsNum, servAssign.getPath(), true, servAssign.getService().getRequiredWaveNum());
        }

        // collect future services
        // key represents service index, value represents path of services
        Map<Integer, List<Link>> futureService = Maps.newHashMap();
        for (int i=0; i<orderedList.size(); i++) {
            List<Link> path;
            Timestamp timestamp = orderedList.get(i);
            int serviceIndex = timestamp.getServiceIndex();
            if (timestamp.isStartTime()) {
                Service service = getServicesQueue().get(serviceIndex-1);
           	 NodeIdImplement srcId = new NodeIdImplement(service.getSource());
           	 NodeIdImplement dstId = new NodeIdImplement(service.getDestination());
               // GraphPath<NodeIdImplement, LinkImplementation> path = dijkstraShortestPath.getPath(srcId, dstId);
              //  GraphPath<NodeIdImplement, LinkImplementation> path = dijkstraShortestPath.getPath(srcId, dstId);
        //   	List<Link> path = dijkstraShortestPath.getPath(srcId, dstId);
               path = pathCollection.get(srcId).get(dstId);
              if (path.get(0).getSrc()!= null && path.get(0).getDst()!=null) {

              //  path = dijkstraShortestPath.getPath( new EonVertex(service.getSource()), new EonVertex(service.getDestination())).getEdgeList();
                futureService.put(serviceIndex, path);
                execFutureServiceAssignment(occupiedSlotsNum, path, true, service.getRequiredWaveNum());
            } else {
                int requiredSlotsNum = 0;
                if (getCurrentServices().containsKey(serviceIndex)) {
                    path = getCurrentServices().get(serviceIndex).getPath();
                    requiredSlotsNum = getServicesQueue().get(serviceIndex-1).getRequiredWaveNum();
                } else if (futureService.containsKey(serviceIndex)) {
                    path = futureService.get(serviceIndex);
                    // must be serviceIndex-1
                    requiredSlotsNum = getServicesQueue().get(serviceIndex-1).getRequiredWaveNum();
                    futureService.remove(serviceIndex);
                } else if (getBlockedServices().containsKey(serviceIndex)) {
                    // Do nothing.
                    path = null;
                } else {
                    throw new RuntimeException(
                            "service which neither belongs to current services nor future services leaves.");
                }
                execFutureServiceAssignment(occupiedSlotsNum, path, false, requiredSlotsNum);

            }
        }

        if (Debug.ENABLE_DEBUG) {
            checkNoLessThanZero(occupiedSlotsNum);
        }
       // return occupiedSlotsNum;
    }
		return occupiedSlotsNum;
    }
	  protected void checkNoLessThanZero(Map<Link, Double> occupiedSlotsNum) {
	        for (double d : occupiedSlotsNum.values()) {
	            if (d < 0 ) {
	                throw new RuntimeException("less than zero!");
	            }
	        }
	    }

  protected void execFutureServiceAssignment(Map<Link, Double> occupiedSlotsNum,
              List<Link> path, boolean isPlus, int requiredSlotsNum) {
          if (path != null) {
            if (isPlus) {
               for (Link edge : path) {
              int num = requiredSlotsNum;
             occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge) + num);
         }
       } else {
      for (Link edge : path) {
       int num = requiredSlotsNum;
       occupiedSlotsNum.put(edge, occupiedSlotsNum.get(edge) - num);
     }
    }
} else {
// blocked service leave, do nothing.
}
}

  protected List<Timestamp> subList(ArrayList<Timestamp> total, int index) {

      Calendar tmp = Calendar.getInstance();
      tmp.setTimeInMillis(total.get(index).getTime().getTimeInMillis() + predictionIntervalInMins*minToMs);

      int end = index+1;
      while (total.get(end).getTime().before(tmp)) {
          end++;
          if (end == total.size()) {
              break;
          }
      }
      if (end == index+1) {
          throw new RuntimeException("only one or no service between predictionInterval.");
      }
      /* Returns a view of the portion of this list between the specified
         {@code fromIndex}, inclusive, and {@code toIndex}, exclusive. */
      List<Timestamp> list = total.subList(index, end);
      return list;

  }


/**----------------------------------------------Simultaneous Core number assignment---------------------------------------------------------/
    /**
     * For the service arrival event, all the links on the Path take the same subscript core for service allocation attempt.
      * Note 1: As long as there are cores that meet the conditions, no matter how many combinations are available on the core, for the sake of simplicity, only the first one can be successful.
      * @param arrivalEvent arrival event
      * @return is assigned successfully
ArrayList<Service> servicesQueue
     */
    protected boolean assignSameCore(Service arrivalEvent, List<Link2> path) {
        // TODO
        int requireWaveNum = arrivalEvent.getRequiredWaveNum();
        for (int i = 0; i < 6 ; i++ ) {
            List<CoreSC> coreSCList = new ArrayList<CoreSC>();
            for (Link edge : path) {
                LinkImplementation sdmEdge = (LinkImplementation) edge;
                LinkCores sdmCore = sdmEdge.getCoreList().get(i);
                CoreSC coreSC = calculateCoreSc(sdmEdge.getEdgeId(), sdmCore, arrivalEvent.getRequiredWaveNum());
                coreSCList.add(coreSC);
            
            List<List<Integer>> avaiSpectrumBlock = checkAvaiSpectrumBlockInOrderSameIndex(coreSCList, requireWaveNum);
            if (avaiSpectrumBlock == null || avaiSpectrumBlock.isEmpty()) {
            	// If it is null, it means that there are not enough resources on the Core i that are the same as the required spectrum  number, and the service cannot be allocated.
                // do nothing, calculate and check the next core;

            } else {
            	// If it is not null, it means that there are enough resources to satisfy the spectrum consistency, and the service can be allocated. However, it is not yet determined whether the service can be successfully assigned.
                // Find the spectrum combination that will not cause crosstalk. Note that there may be multiple combinations of one spectrum segment.
                List<List<Integer>> noCrosstalkSpectrumBlock =
                        noCrossTalkFilterSameIndex(avaiSpectrumBlock, coreSCList, arrivalEvent.getRequiredWaveNum());
                // check if it is empty
                if (noCrosstalkSpectrumBlock == null || noCrosstalkSpectrumBlock.isEmpty()) {
                	// If it is null, it means that all resources that meet the spectrum consistency will cause crosstalk, cannot allocate services. check the next core.

                } else {
                	// all the core that satisfied can randomly be assigned
                    List<Integer> finalResult = selectRandomResult(noCrosstalkSpectrumBlock);
                    assignSpetrumResource(arrivalEvent, finalResult, coreSCList);
                  //  putCurrentService(new ServiceAssignment<>(arrivalEvent, arrivalEvent.getEventId(), path));;
                }
            }
        }
     // 6 cores are traversed or not satisfied, return false
      // return false;
    }
        putCurrentService(new ServiceAssignment<>(arrivalEvent, arrivalEvent.getEventId(), path));;

		return true;
    }

    /**
     *
     * According to the final set of spectrum numbers provided by finalResult, the resource occupation operation is performed in all Cores corresponding to maxCoreScPerEdge.
      * @param serviceEvent event
      * @param finalResult List of spectrum resource numbers eventually occupied
      * @param maxCoreScPerEdge Occupy CoreC information for Core on different links

     */
    private static void assignSpetrumResource(Service serviceEvent, List<Integer> finalResult, List<CoreSC> maxCoreScPerEdge) {

        int eventId = serviceEvent.getEventId();
        List<CoreSC> coreSCList = new ArrayList<CoreSC>();
        for (CoreSC coreSC : maxCoreScPerEdge) {
            LinkImplementation sdmEdge = (LinkImplementation)graph.getEdges().get(coreSC.getEdgeId());  
            int coreIndex = coreSC.getCoreIndex();                                        

            List<FrequencySlots> wavelengths = sdmEdge.getCoreList().get(coreSC.getCoreIndex()).getWavelength();
            for (int needOccupied : finalResult) {
                if (wavelengths.get(needOccupied).getIsOccupied()) {
                    log.error("Insufficient resources to allocate business");
                } else {
                    wavelengths.get(needOccupied).setOccupiedServiceIndex(1);
                    wavelengths.get(needOccupied).setwaveServiceId(eventId);
                }
            }

          //Build List<CoreSC> required for eventInfo
            CoreSC coreSCValue = calculateCoreSc(sdmEdge.getEdgeId(), sdmEdge.getCoreList().get(coreIndex),
                    serviceEvent.getRequiredWaveNum());                      
            double time = 0;                                                  
       /*     if (serviceEvent.getRequestType() == RequestType.IR){
                time = serviceEvent.getArriveTime();
            }else if(serviceEvent.getRequestType() == RequestType.AR){
                time = serviceEvent.getStartTime();
            }else {
                log.info("No such service request type");
            }
*/
            CoreSC coreScResult = new CoreSC(time, sdmEdge.getEdgeId(), coreIndex, coreSCValue.getSc());
            coreSCList.add(coreScResult);
        }

     // Put the service allocation information into eventInfo and update the time point global storage variable timeResource.
        StringBuilder occupiedIndex = new StringBuilder("{");
        for (int i : finalResult) {
            occupiedIndex.append(i+",");
        }
        occupiedIndex.deleteCharAt(occupiedIndex.lastIndexOf(","));
        occupiedIndex.append("}");
        log.info("Assign service success. The service id is {}\\t service occupation resource number is {}\\t\\t\\t, and the service passing node is {}\n" + 
        		"", occupiedIndex, maxCoreScPerEdge);
      //  System.out.println(occupiedIndex);

        serviceEventInfo.put(serviceEvent, new Pair<List<CoreSC>, List<Integer>>(maxCoreScPerEdge, finalResult));
    

    }

    /**
     * Verify that there are spectrum blocks in the maxCoreScPerEdge list that do not meet the spectral consistency and are capable of providing a sufficient number of spectra.
      * Note: The Integer value contained in the return value is incremented by subscript. List<Integer> in List<n> must be less than List<n+1>
      * @param maxCoreScPerEdge List of CoreSCs, looking for resources that maintain spectrum consistency in these CoreSCs
      * @param requiredWaveNum The number of requested spectrum resources
      * @return Returns List if it exists, List<Integer> in List represents the spectrum block; if it does not exist, it returns null.
     *///TODO
    public List<List<Integer>> checkAvaiSpectrumBlockInOrderSameIndex(List<CoreSC> maxCoreScPerEdge,
                                                                      int requiredWaveNum) {
    	// First get the first CoreSc in maxCoreScPerEdge corresponding to the unoccupied spectrum block on SdmCore.
        LinkCores sdmCore = mapToCore(maxCoreScPerEdge.get(0));
        if (sdmCore != null){
            List<List<Integer>> first = findAvaiSpectrumBlocksInOrder(sdmCore.getWavelength() , requiredWaveNum);
            if (first == null) {
                return null;
            }
         // Filter out List<Integer> that does not satisfy the requested spectrum in List<List<Integer>>
            List<List<Integer>> filtered = enoughSpectrumBlockFilter(first, requiredWaveNum);
            if (filtered == null) {
                return null;
            }
            if (maxCoreScPerEdge.size() == 1) {
                return filtered;
            }

         // If there is more than one Core in maxCoreScPerEdge, and the first selected Core contains spectrum resources that meet the consistency
            for (int i=1; i<maxCoreScPerEdge.size(); i++) {
            	// First find the intersection of the filtered and the available spectrum of the core being traversed
                LinkCores mapToCore = mapToCore(maxCoreScPerEdge.get(i));
                if (mapToCore != null){
                    List<FrequencySlots> wavelengths = mapToCore.getWavelength();
                 // Be sure to traverse from big to small, because once an element is removed from the list , the remaining elements will be forwarded.
                    for (int j=filtered.size()-1; j>=0; j--) {
                        List<Integer> tmpSpectrumBlock = filtered.get(j);
                        for (int k=tmpSpectrumBlock.size()-1; k>=0; k--) {
                            if (wavelengths.get(tmpSpectrumBlock.get(k)).getIsOccupied()) {
                                tmpSpectrumBlock.remove(k);
                            }
                        }
                    }
                 // After traversing a core completely, filter the List that satisfies the spectrum number
                    filtered = enoughSpectrumBlockFilter(filtered, requiredWaveNum);
                    if (filtered == null) {
                        return null;
                    }
                }else {
                    throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph");
                }

            }
            return filtered;
        }else {
            throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph");
        }
    }

    /**
     * Find the spectrum combination that does not cause crosstalk from the available spectrum blocks represented by avaiSpectrumBlock. Note that a spectrum segment may have multiple combinations.
      * Note: The return value and the reference avaiSpectrumBlock point to not the same memory address, but the avaiSpectrumBlock has been modified and can no longer be used.
      * @param avaiSpectrumBlock Available spectrum blocks
      * @param maxCoreScPerEdge The list of Cores with the largest SC value on each link selected from Path
      * @param requiredWaveNum Required spectrum resources
      * @return Spectral combination that does not cause crosstalk
     */
    private  List<List<Integer>> noCrossTalkFilterSameIndex(
            List<List<Integer>> avaiSpectrumBlock,  List<CoreSC> maxCoreScPerEdge, int requiredWaveNum) {

    	// Find the spectrum block that will not cause crosstalk first.
    	List<List<Integer>> tmp = avaiSpectrumBlock;
        for (CoreSC coreSC : maxCoreScPerEdge) {
        	// Find a spectrum block on the Core that does not cause crosstalk
        	tmp = noCrossTalkFilterFurtherSameIndex(tmp, coreSC, requiredWaveNum);
            if (tmp == null || tmp.isEmpty()) {
                return null;
            }
        }

     // Determine the spectrum combination of the filtered spectrum blocks
        return genAvaiCombinationsSameIndex(tmp, requiredWaveNum);
    }

    /**
     ** Find the spectrum block that does not cause crosstalk on the spectrum block avaiSpectrumBlock for the core coreSC.
      * Note 1: Looking for a spectrum block, not a combination of spectrum blocks
      * Note 2: return value and avaiSpectrumBlock, they do not point to the same memory address!
      * @param avaiSpectrumBlock Available spectrum blocks
      * @param coreSC core
      * @param requiredWaveNum Required spectrum resources
      * @return A list of spectrum blocks that will not cause crosstalk. Returns null if there are not enough spectrum resources.

     */
    private List<List<Integer>> noCrossTalkFilterFurtherSameIndex(List<List<Integer>> avaiSpectrumBlock, CoreSC coreSC,
                                                         int requiredWaveNum) {

        LinkImplementation sdmEdge = (LinkImplementation) graph.getEdges().get(coreSC.getEdgeId());
        LinkCores comparedCore = mapToCore(coreSC);
        List<List<Integer>> rtn = new ArrayList<List<Integer>>();

     // The parameter type List<List<Integer>> is not set properly, but it has been difficult to change.
        int waveInCoreNum = sdmEdge.getCoreList().get(0).getWavelength().size();
     // This variable occupiedTime is the dimensionality reduction of the avaiSpectrumBlock.
        List<Integer> occupiedTime = new ArrayList<Integer>();
        for (List<Integer> m : avaiSpectrumBlock) {
            for (int n : m) {
                occupiedTime.add(n);
            }
        }

        if (comparedCore != null){
        	// traversing from big to small
            for (int i=occupiedTime.size()-1; i>=0; i--) {
                int index = occupiedTime.get(i);
                int count = 0;
             // Traverse the adjacent Core
                for (LinkCores adjCore : comparedCore.getAdjacentCores()) {
                    if (adjCore.getWavelength().get(index).getIsOccupied()) {
                    	// If the previous count value is 1, this time, the spectrum resources of the adjacent Core are occupied. Therefore, crosstalk is generated and the spectrum is deleted.
                        //TODO modified the crosstalk condition

                        if (count == 6) {
                            occupiedTime.remove(i);
                         // After deleting, there is no need to traverse here, just jump out of the innermost for loop and start looking for the next for loop.
                            break;
                        } else {
                            count++;
                        }
                    }
                }
            }
         // The result obtained in the previous step indicates that the available spectrum does not generate crosstalk.
            // This step sorts the results of the previous step into the form of available spectrum segments, ie List<List<Integer>>, and removes the spectrum segments that do not meet the length requirements.
            if (occupiedTime.isEmpty()) {
                return null;
            } else {
                int point = occupiedTime.get(0);
                List<Integer> pointList = new ArrayList<Integer>();
                pointList.add(point);

                for (int i=1; i<occupiedTime.size(); i++) {
                	// If this one is th lasts available spectrum slot, we can use it
                	if (occupiedTime.get(i)-1 == occupiedTime.get(i-1)) {
                        pointList.add(occupiedTime.get(i));
                    } else {
                    	// If the next available spectrum and the previous discontinuity, the segmentation of this spectrum segment is successful, and the segmentation of the next spectrum segment is started.
                        // First determine if the length of the currently segmented spectrum segment meets the requirements. Only if it meets the requirements, will it be placed in rtn. If not, discard it.
                        if (pointList.size() >= requiredWaveNum) {
                            rtn.add(pointList);
                        }
                        pointList = new ArrayList<Integer>();
                        pointList.add(occupiedTime.get(i));
                    }
                }

                // After the for loop is over, there is no processing for the last constructed pointList instance, to do tail processing
                if (pointList.size() >= requiredWaveNum) {
                    rtn.add(pointList);
                }

                return rtn;
            }
        }else {
            throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph！");
        }
    }

    /**
     * The spectrum combination of the list avaiBlock of available spectrum resource blocks is determined.
      * Note 1: The return value and the incoming avaiBlock point to not the same memory address!
      * Note 2: This method defaults to avaiBlock non-null non-empty and contains enough resources. Therefore, the relevant decision is made when the method is called.
      * @param avaiBlocks List of available spectrum resource blocks
      * @param requiredWaveNum Required spectrum resources
      * @return According to Note 2, there must be a spectrum combination that satisfies the condition, so the return value cannot be null or empty.
     */
    private List<List<Integer>> genAvaiCombinationsSameIndex(List<List<Integer>> avaiBlocks, int requiredWaveNum) {

        List<List<Integer>> rtn = new ArrayList<List<Integer>>();
        for (List<Integer> block : avaiBlocks) {
        	// window indicates the size of the window whose length is requiredWaveNum can be slid in the block spectrum segment.
            int window = block.size() - requiredWaveNum;
            for (int i=0; i<=window; i++) {
            	// subList contains the left border and does not contain the right border
                rtn.add(
                        copyOf(
                                block.subList(i, requiredWaveNum+i)));
            }
        }

        return rtn;
    }



/**------------------------------------------------Auxiliary method-----------------------------------------------------------/
    /**
     *Randomly select a spectrum block
      * @param noCrosstalkSpectrumBlock available spectrum block
      * @return returns randomly selected results
     */
    public List<Integer> selectRandomResult(List<List<Integer>> noCrosstalkSpectrumBlock){
    	// randomly generate a traversal subscript of 0-noCrosstalkSpectrumBlock-1 size
        int index = (int)(Math.random()*(noCrosstalkSpectrumBlock.size()-1));
        List<Integer> rtn = noCrosstalkSpectrumBlock.get(index);
        return rtn;
    }

    /**
     * Map from CoreSC to a specific LinkCore object.
      * @param coreSC coreSC
      * @return Returns null if there are no mapped objects in the graph.
     */
    private LinkCores mapToCore(CoreSC coreSC) {
        LinkImplementation edge = (LinkImplementation)graph.getEdges().get(coreSC.getEdgeId());
        if (edge != null) {
            return edge.getCoreList().get(coreSC.getCoreIndex());
        } else {
            return null;
        }
    }


    /**
     * Deep copy a List<Integer> object. - Test succeeded
      * @param beCopied the object being copied
      * @return copy the result

     */
    private static List<Integer> copyOf(List<Integer> beCopied) {
        checkNotNull(beCopied);
        List<Integer> rtn = new ArrayList<Integer>();
        for (int i : beCopied) {
            rtn.add(new Integer(i));
        }
        return rtn;
    }

    /**
     * If all the spectrums on the Core are occupied, the SC value is 0; if no spectrum is occupied, the SC value is infinity. - The test is successful.
      * @param LinkID The id of the edge where the Core is located
      * @param core Core
      * @return returns an instance of CoreSC

     * @return 返回CoreSC的实例
     */
    private static CoreSC calculateCoreSc(LinkID edgeId, LinkCores core, int requiredWaveNum) {

    	// Construct an instance of CoreSC
    	CoreSC rtn = new CoreSC();
        rtn.setEdgeId(edgeId);
        rtn.setCoreIndex(core.getId());

        // Calculate the SC value
        double maxOccupiedSlotNum = -1;
        double minOccupiedSlotNum = -1;
        double occupiedSlotTotalNum = 0;
        double availSpectrumBlockTotalNum;
        boolean isFirstOccupied = true;
        double sc;

        for (int i=0; i<core.getWavelength().size(); i++) {
            FrequencySlots wavelength = core.getWavelength().get(i);
         // If the spectrum is occupied
            if (wavelength.getIsOccupied()) {
            	// If it is the first time to find the occupied spectrum
                if (isFirstOccupied) {
                    minOccupiedSlotNum = i;
                    occupiedSlotTotalNum++;
                    isFirstOccupied = false;
                } else {
                    maxOccupiedSlotNum = i;
                    occupiedSlotTotalNum++;
                }
            }
        }

     // If all spectrum resources are not occupied, the SC value is infinite
        if (maxOccupiedSlotNum == -1) {
            sc = Double.POSITIVE_INFINITY;
            rtn.setSc(sc);
            return rtn;
        }

     // If all spectrum resources are occupied, the SC value is 0.
        if (occupiedSlotTotalNum == core.getWavelength().size()) {
            sc = 0d;
            rtn.setSc(sc);
            return rtn;
        }

     // If it is not the above two extreme cases, the search for the occupied spectrum segment does not necessarily have to satisfy the length. The following method needs to be modified.
     // This method is not suitable for findAvaiSpectrumBlocksInOrder
        List<List<Integer>> avaiSpectrumBlocks = findAvaiSpectrumBlocksInOrder(core.getWavelength(),requiredWaveNum);
        if (avaiSpectrumBlocks == null) {
        	// Not necessarily, there may not be two extreme cases, the middle is occupied but the length of the request is not satisfied, so the latter is correct.
            log.info("No spectrum segment available");
        } else {
            availSpectrumBlockTotalNum = avaiSpectrumBlocks.size();
            sc = (maxOccupiedSlotNum - minOccupiedSlotNum + 1) / occupiedSlotTotalNum *
                    (core.getWavelength().size() - occupiedSlotTotalNum) / availSpectrumBlockTotalNum;
            rtn.setSc(sc);
        }
        return rtn;
    }
    protected void handleAllocationFail(Service blockedService, int index) {
        addBlockedService(blockedService);
    }

    public static void main(String[] args)  {
    //	assignSpetrumResource(null, null, null);
    //	assignFinalSpetrum(null, null);
    }


}
