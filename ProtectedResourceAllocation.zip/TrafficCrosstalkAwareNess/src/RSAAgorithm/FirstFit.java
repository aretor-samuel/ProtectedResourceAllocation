package RSAAgorithm;




import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

//import javafx.util.Pair;
import org.jgrapht.alg.util.Pair;

import TrafficGeneration.ServiceAssignment;
import TrafficGeneration.Service;
import Network.NodeId;
import Network.Link;
import Network.Link2;
import Network.LinkID;
import Network.LinkCores;
import Network.LinkImplementation;
import Network.Network;
import Network.Node2;
import DataCollection. DataCollectionPerSC;
import Network.CoreSC;
import Network.FrequencySlots;
import Network.NodeIdImplement;
import Network.Nodeimplement;
import Network.TopologySetup;
import Graph.GraphImplement;
import TrafficGeneration.Timestamp;
import Utility.Debug;
import Utility.MetricType;

import org.jgrapht.GraphPath;
import org.jgrapht.alg.interfaces.KShortestPathAlgorithm;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.shortestpath.KShortestPaths;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created on 2019/05/20.
 *Multi-core First Fit allocation algorithm 
 * @author sambabel.
 */
//public class CrosstalkAlgo extends BaseAlgorithm<Node2,Link2> extends FirstFit{
	public class FirstFit  extends BaseAlgorithm<Node2,Link2>{

//	public class FirstFitAllocAlgorithmn  {

    private static final Logger log = LoggerFactory.getLogger(FirstFit.class);
   // private DijkstraShortestPath<Nodeimplement, LinkImplementation> dijkstraShortestPath;
    private double threshold;
    //protected static GraphImplement graph;
    private SimpleWeightedGraph<Node2, Link2> graph;
    public static double mape;
	private int n;
    protected Network network;

    public static int predictionIntervalInMins =30;
    static final int minToMs = 60*1000;
    private Map<Link2, Double> futureMap;

    protected DataCollectionPerSC dataCollection;
    private DijkstraShortestPath<Node2, Link2> dijkstraShortestPath;
    private KShortestPathAlgorithm<Node2, Link2> kShortestPathAlgorithm;

    private int weightedCount=0;
    private int defaultCount=0;
    private int samePathCount=0;
    private int bothBlockCount=0;

    int gamma , Rho;
	protected Random linkCutter;

    public static ArrayList<Integer>noCrosstalkSpectrumBlock=Lists.newArrayList();
    // ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

     public static List<CoreSC> coreSCList=Lists.newArrayList();
     
 
    public FirstFit(//double threshold,
                final ArrayList<Service> service,
                final ArrayList<Timestamp> serviceTimestamp,
                final SimpleWeightedGraph<Node2, Link2> graph
            
    		) {
    	super(  service,serviceTimestamp, graph);
    	this.graph = graph;


dijkstraShortestPath = new DijkstraShortestPath<>(graph);


}


    
    

   
    public void Execute() {
    	
    	
  
    Calendar predictionTimePoint = Calendar.getInstance();
        predictionTimePoint.setTimeInMillis(getServicesOrderedQueue().get(0).getTime().getTimeInMillis()-1);

        for (int index=0; index<getServicesOrderedQueue().size(); index++) {
            Timestamp timestamp = getServicesOrderedQueue().get(index);
            Service serviceToBeAssigned = getServicesQueue().get(timestamp.getServiceIndex()-1);

           
            if (timestamp.isStartTime()) {
            	
            	
              	 
              	  Node2 src = new Node2(serviceToBeAssigned.getSource());
                  Node2 dst = new Node2(serviceToBeAssigned.getDestination());
                  

	            	

	            	linkCutter = new Random(serviceToBeAssigned.getseedValue());
              	network=new Network();
              	network.graph= graph;

              	network.setModualtionMetricType(MetricType.DYNAMIC);
              	network.setSeed(serviceToBeAssigned.getseedValue());
              	for (Node2 n: graph.vertexSet()){
  					n.setRegeneratorsCount(100);
  				}
                  GraphPath<Node2, Link2> defaultPath = dijkstraShortestPath.getPath(src, dst);
                //  int defaultSubscript = FindPathNoCrosstalkResourcesFirstAvailable2(defaultPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());

              //   int defaultSubscript = FindPathNoCrosstalkResourcesFirstAvailable4(defaultPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());
             //     int defaultSubscript = FindPathNoCrosstalkResourcesFirstAvailable5(defaultPath.getEdgeList(), serviceToBeAssigned.getRequiredWaveNum());
					Pair<Integer, Pair<Integer,  List<CoreSC>>>DefaultResorces = FindPathNoCrosstalkResourcesFirstAvailable4(defaultPath.getEdgeList(), serviceToBeAssigned);

                   //  if (defaultSubscript != BaseAlgorithm.UNAVAILABLE) {
                         if (DefaultResorces.getFirst() != BaseAlgorithm.UNAVAILABLE) {

                    //	 assignSameCore(serviceToBeAssigned, defaultSubscript, defaultPath.getEdgeList()) ;
                    	// if (	 assignSameCore(serviceToBeAssigned, defaultPath.getEdgeList()) ) {

                             assignSpetrumResource12(serviceToBeAssigned, DefaultResorces.getSecond().getFirst(),DefaultResorces.getFirst(), DefaultResorces.getSecond().getSecond(), defaultPath.getEdgeList());

                      //  assignSpetrumResource12(serviceToBeAssigned, DefaultResorces.getFirst(),requireWaveNum, DefaultResorces.getSecond(), defaultPath.getEdgeList());
                    //     assignSpetrumResource1(serviceToBeAssigned, defaultSubscript,noCrosstalkSpectrumBlock, defaultPath.getEdgeList().get(index).getCoreList(), defaultPath.getEdgeList());



                        putLinkUtilizationOutputData( graph, DefaultResorces.getSecond().getSecond());

                        putLinkCrosstalkaffectedSlots(graph, DefaultResorces.getSecond().getSecond());

                 }  else {
                 	
                     handleAllocationFail(serviceToBeAssigned , serviceToBeAssigned.getEventId());
             //       System.out.println("******************************handblocked*******************************111111111112");     	
               }
                         
                         
            /*             if (linkCutter.nextDouble() < gamma / Rho) {
                             
          					for (Service reallocate : network.cutLink()) {

          						 GraphPath<Node2, Link2> BackupPath = dijkstraShortestPath.getPath(src, dst);
          		                 
              					 Pair<Integer, Pair<Integer,  List<CoreSC>>> ReallocateBackupSpectrum = FindPathBackupResourcesFirstAvailable4(BackupPath.getEdgeList(), serviceToBeAssigned);


          					//	handleDemand(reallocate);
          						UpdateService(reallocate);
          					
          			 if (ReallocateBackupSpectrum.getSecond().getFirst() != BaseAlgorithm.UNAVAILABLE ) {
//          						      System.out.println("******************************Currentservices*******************************linkCutter777777");
          				       assignSpetrumResource12(reallocate, ReallocateBackupSpectrum.getSecond().getFirst(),ReallocateBackupSpectrum.getFirst(), ReallocateBackupSpectrum.getSecond().getSecond(), BackupPath.getEdgeList());
                      //              System.out.println("******************************Currentservices*******************************linkCutter777777");

                     }	
          					}
                         }*/
                  
                
            } else {
            	// If it is a business departure event
               // return releaseService(serviceToBeAssigned);
                handleServiceLeave(serviceToBeAssigned.getEventId());
               //System.out.println("**********************************handle pasedservices*************************88888*2");

            }
        }  
    }
    //////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////

    
          public boolean handleServiceLeave(int leaveServiceIndex) {
            if (getCurrentServices().containsKey(leaveServiceIndex)) {
                ServiceAssignment<Link2> serviceAssignment = getCurrentServices().get(leaveServiceIndex);
             //  releaseService(serviceAssignment.getService());
              releaseService1(serviceAssignment);
            //   releaseService12(serviceAssignment);

                putPassedService(
                        removeCurrentService(leaveServiceIndex));
            //   System.out.println(getPassedServices().size());
            } else if (getBlockedServices().containsKey(leaveServiceIndex)){
                // TODO
                // Actually, there is nothing to do here. Just for readability.
            } else {
                throw new RuntimeException("The leave service belongs to neither assigned services, nor blocked services.");
            }
			return true;
        }
          protected void UpdateService(Service Sevice) {
        	  removeCurrentService(Sevice.getEventId());
        	  
          }
///////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void releaseService1(ServiceAssignment<Link2> serviceAssignment) {
        	
      	  List<Link2> path = serviceAssignment.getPath();
      	  	//FrequencySlots slots
      	        int serviceIndex = serviceAssignment.getService().getEventId();
      	      //  for (int i = 0; i < 6 ; i++ ) {
      	           // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
      	           for (Link2 edge : path) {
      	            //    LinkImplementation sdmEdge = (LinkImplementation) edge;
      	          /*     for (int slotIndex=serviceAssignment.getStartIndex();
      	                        slotIndex<=serviceAssignment.getStartIndex()+serviceAssignment.getService().getRequiredWaveNum()-2;
      	                      slotIndex++) {*/
      	        	 for (int slotIndex=serviceAssignment.getStartIndex();
   	                        slotIndex<=serviceAssignment.getStartIndex()+serviceAssignment.getRequiredWaveNum1()-2;
   	                      slotIndex++) {
   	                  
      	                
      	    	// List<LinkCores> sdmCorelist1 = serviceAssignment.getLinkCores();

      	    	 List<CoreSC> coreSCList = serviceAssignment.getCores();
      	         List<Integer> occupiedIndexes = serviceAssignment.getConnections();
      	   //    System.out.println(occupiedIndexes);

    	          List<LinkCores> sdmCorelist = edge.getCoreList();
    	          

    	      	 //    for (LinkCores sdmCore : sdmCorelist) {
    	    /**             for (int j=0; j<sdmCorelist.size(); j++) {
    	               	  int totalSumCore, c,nextCore, totolCoreNum;
    	            	  totolCoreNum=7;
    	            	  totalSumCore=28;
    	            	  n=totolCoreNum+1;
    	            	     nextCore=(2*totalSumCore/n)+j;
    	    //      	 LinkCores sdmCore=sdmCorelist.get(nextCore-1);

      	      LinkCores sdmCore=sdmCorelist.get(j);*/
      	       // LinkCores sdmCore=sdmCorelist.get(sdmCore1.getId());
    	            for (int j=0; j<coreSCList.size(); j++) {

               // for (CoreSC coreSC : coreSCList) {

                  // LinkCores sdmCore = mapToCore(coreSC);
                    //LinkCores sdmCore=mapTolinkCore(edge, coreSC);
                        LinkCores sdmCore=sdmCorelist.get(coreSCList.get(j).getCoreIndex());

                  //     LinkCores sdmCore=sdmCorelist.get(coreSC.getCoreIndex());


      	      //    if (sdmCore != null){
      	       //     if (occupiedIndexes != null) {
      	                List<FrequencySlots> wavelengths = sdmCore.getWavelength();
      	              //  FrequencySlots slot= wavelengths.get(slotIndex-1);
      	 	 	//	for (int slotIndex=0; slotIndex<occupiedIndexes.size(); slotIndex++) {
                      
      	            //  for (int slotIndex : occupiedIndexes) {
      	                //    if (wavelengths.get(slotIndex-1).getSlotIndex()==slotIndex && !wavelengths.get(slotIndex-1).getIsOccupied()) {//||
          	                 if (wavelengths.get(slotIndex).getSlotIndex()==slotIndex && !wavelengths.get(slotIndex).getIsOccupied()) {//||
      	                          //  wavelengths.get(slotIndex).getWaveServiceId() != serviceIndex) {
          	                    	// if (!wavelengths.get(slotIndex).getIsOccupied() ||
          	                             //   wavelengths.get(slotIndex).getWaveServiceId() != serviceIndex) {
      	                    
      	                    	// If the service is successfully assigned when the service happens
      	                        throw new RuntimeException("Since the service does not occupy the corresponding resources, the service is released.\n" + 
      	                        		"！");
      	                   }
          	                    else {
      	                 // free resources
      	                  //  wavelengths.get(index).setIsOccupied(false);
      	                 //   wavelengths.get(slotIndex).setOccupiedServiceIndex(1);;

      	                   // wavelengths.get(slotIndex).setwaveServiceId(-1);
      	                    wavelengths.get(slotIndex).setOccupiedServiceIndex(0);;

      	                 // wavelengths.get(slotIndex).setwaveServiceId(-1);
      	                  	   }
      	                    
      	      
      	            }
      	  }
      	            }
        }
        //}
    
        private void releaseService12(ServiceAssignment<Link2> serviceAssignment) {
        	
      	  List<Link2> path = serviceAssignment.getPath();
      	  	//FrequencySlots slots
      	        int serviceIndex = serviceAssignment.getService().getEventId();
      	     
      	            for (Link2 edge : path) {
      	            //    LinkImplementation sdmEdge = (LinkImplementation) edge;
      	                for (int slotIndex=serviceAssignment.getStartIndex();
      	                        slotIndex<=serviceAssignment.getStartIndex()+serviceAssignment.getService().getRequiredWaveNum();
      	                      slotIndex++) {
      	                
      	                
      	 
      	            	     FrequencySlots withdrawSlot = edge.getSlots().get(slotIndex-1);
      	                // if both slotIndex and occupiedServiceIndex are matched.
      	                if (withdrawSlot.getSlotIndex() == slotIndex &&
      	                        withdrawSlot.getOccupiedServiceIndex() == serviceIndex) {
      	                    withdrawSlot.setOccupiedServiceIndex(FrequencySlots.AVAILABLE);
      	                } else {
      	                    throw new RuntimeException("slotIndex or occupiedServiceIndex doesn't match while withdrawing service.");
      	               
      	               }
      	                    
      	      
      	            }
      	  }
      	            }
    



    /**
     *
     * According to the final set of spectrum numbers provided by finalResult, the resource occupation operation is performed in all Cores corresponding to maxCoreScPerEdge.
      * @param serviceEvent event
      * @param finalResult List of spectrum resource numbers eventually occupied
      * @param maxCoreScPerEdge Occupy CoreC information for Core on different links

     */
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   
	//	private  void assignSpetrumResource1(Service serviceEvent, int startIndex,  List<Link2> path) {
	 //   public void handleAllocationFail(Service blockedService, int index) {
		    public void handleAllocationFail(Service blockedService, int index) {

  
        addBlockedService(blockedService);
        //  System.out.println(getBlockedServices().size());
    

  //  	}
    }
		    public void handleAllocatedFailedService(Service blockedService) {
		        addBlockedFailedService( blockedService);

  
        addBlockedService(blockedService);
     //   addBlockedFailedService( blockedService);
        //  System.out.println(getBlockedServices().size());
    

  //  	}
    }

    }


