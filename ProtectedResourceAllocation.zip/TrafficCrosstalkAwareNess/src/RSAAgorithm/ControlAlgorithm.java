package RSAAgorithm;

//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.ExplicitGroup;
//import com.sun.xml.internal.ws.server.ServerRtException;
//import javafx.util.Pair;
import org.jgrapht.alg.util.Pair;


import Network.Link;
import Network.LinkID;
import Graph.Graph;
import Network.LinkCores;
import Network.LinkImplementation;
import TrafficGeneration.Service;
import TrafficGeneration.Timestamp;
import Utility.RollbackException;
import Network.CoreSC;
import Network.FrequencySlots;
import Graph.GraphImplement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import DataCollection.DataCollectionPerSC;

import java.util.*;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by sambabel on 20119/05/17.
 *
 * Algorithm 1:
 * 1. Blocking trigger;
 * 2. According to the timeResource, calculate the link'SC value of each link in the timeResource all time points, such as the SC value of link1 at time points such as t1, t2, etc.;
 * 3. The time point on the Link exceeding the SC threshold is placed in the adjustment set Set1 (in descending order), the information includes (link l, time, SC), 24 links are all found, and Set1 traverses the adjustment algorithm before it ends;
 * 4. Traverse the adjustment set Set1 (), for a (link l, time, SC) time window adjustment, find all the core set Set2 on the link that exceeds the SC threshold (descending order);
 * 5. Traverse the core set Set2() that exceeds the threshold on the link. For a core that does not find the core (core, time, SC) of the other time points of the link, find all the ARrequests on the core as the set Set3;
 * 6. Traverse all ARrequest sets Set3() on the core, for the other time points when a request is moved to the core, the time set that satisfies the moving condition (crosstalk, SC see below) is Set4;
 * 7. Traverse Set4() selects the time with the least crosstalk perception in the time point in this set (measured by the formula); the core'SC of the previous time is lowered and now the core'SC of the time is not above the threshold, ie the move is successful, update Field;
 * 8. If the move succeeds or fails, it will not return, but also continue to traverse Set1;
 * Select other time window rules for the same core:
 * 1. The minimum crosstalk time as described above; (no code implementation)
 * 2. According to the code implementation (below), select the time at which the SC has the largest SC value on the core. Secondly, the four conditions are met, that is, the transfer is successful, and all the edges of the AR service below the threshold are moved.
 *
 * Algorithm 2:
 * 1. 2. 3. 4. 5. 6. 7. 8. All the same, the entry point is 6,
 * 6. Traverse all fragment ARrequest collection Set3() on the core, for other requests to move to the core at other points in time;
 * 7. For an alternative decision time point time, if only the time window shift condition (crosstalk, SC) is not satisfied, then all other cores are traversed, and all the times of other cores are found to satisfy the condition, and the FF is moved as long as it exists.
 * 8. Meet the moving condition to join the set Set4, if not satisfied, jump to the next alternative decision time point of the core; until Set1 is traversed;
 */
public class ControlAlgorithm {

    protected static final Logger log = LoggerFactory.getLogger(ControlAlgorithm.class);
    protected final double SC_THRESHOLD;

    protected DataCollectionPerSC dataCollection;

    protected final Map<Integer, Pair<List<CoreSC>, List<Integer>>> eventInfo;

    protected final Map<Service, Pair<List<CoreSC>, List<Integer>>> serviceEventInfo;
  //  protected final Map<ServiceEvent, Pair<List<CoreSC>, List<Integer>>> serviceEventInfo;

  //  protected  Map<Double, Map<Integer, Pair<List<CoreSC>, List<Integer>>>> timeEventInfo;


    protected Map<Double, GraphImplement> timeGraph;                                        
   protected Map<Double, Map<Service, Pair<List<CoreSC>, List<Integer>>>> timeServiceEventInfo;  
 //  protected Map<Double, Map<ServiceEvent, Pair<List<LinkCores>, List<Integer>>>> timeServiceEventInfo;  

	//private List<CoreSC> filteredCoreSC;

    
   /** public ControlAlgorithm(double threshold,
                             Map<Double, GraphImplement> timeGraph,
                             Map<Integer, Pair<List<CoreSC>, List<Integer>>> eventInfo,
                             Map<Service, Pair<List<CoreSC>, List<Integer>>> serviceEventInfo,
                             Map<Double, Map<Service, Pair<List<CoreSC>, List<Integer>>>> timeServiceEventInfo,
                         //    Map<Double, Map<Integer, Pair<List<CoreSC>, List<Integer>>>> timeEventInfo,

                            // Map<Double, Map<Integer, Pair<List<CoreSC>, List<Integer>>>> timeEventInfo,

                             DataCollectionPerSC dataCollection) {*/
   public ControlAlgorithm() {
    /*    SC_THRESHOLD = threshold;
        this.timeGraph = timeGraph;
        this.eventInfo = eventInfo;
        this.serviceEventInfo = serviceEventInfo;
        this.timeServiceEventInfo = timeServiceEventInfo;
        this.dataCollection = dataCollection;*/
    }

   
    
    

    /**
     * 
      * SC indicates the degree of spectral regularity.
      * service blocking will call this method once to re-adjust
      * Note: The two graphs of the input and output parameters point to the same memory address.
      * @param originGraph, eventIndex whenever the business is added or deleted after the Graph
      * @return returns the new Graph adjusted by the CASD-SS-DC algorithm
      */
     
    public Graph casd_ss_dcAdj(Graph originGraph, int eventIndex) throws RollbackException {

    	 while (true) {
         	//1. First find the core and time (link, core, time, SC) where the link exceeds the SC threshold.
             List<CoreSC> alledgeTimeSCList = new ArrayList<CoreSC>();         
             List<CoreSC> alledgeTimeBelowSCList = new ArrayList<CoreSC>();    
             Map<Link, List<CoreSC>> edgeToEachTimeSC = new HashMap<Link, List<CoreSC>>();
             Map<Link, List<CoreSC>> edgeToEachTimeBelowSC = new HashMap<Link, List<CoreSC>>();
             Set<LinkID> allEdgesSet = originGraph.getEdges().keySet();

             for (LinkID sdmEdgeId : allEdgesSet){
             	LinkImplementation sdmEdge = (LinkImplementation)originGraph.getEdges().get(sdmEdgeId);
                 List<CoreSC> oneEdgeToEachTimeSC = calculateEachTimeCoreSC(sdmEdge);       
                 List<CoreSC> scDescendingCoreAll = descendingScCore(oneEdgeToEachTimeSC);  
                 alledgeTimeSCList = addToAllCList(alledgeTimeSCList, scDescendingCoreAll); 
                 edgeToEachTimeSC.put(sdmEdge, scDescendingCoreAll);
                 List<CoreSC> oneEdgeToEachTimeBelowSC = filterEachTimeCoreBelowSC(scDescendingCoreAll); 
                 if (oneEdgeToEachTimeBelowSC == null || oneEdgeToEachTimeBelowSC.isEmpty()){
                 	// This side has no time, core with SC value exceeding the threshold, continue to traverse the next edge
                 	// connection  is blocked
                 }else {
                 	// 2. Descending the link set that exceeds the threshold, the SC values of the core are sorted in descending order beyond the threshold (sc, core, edge, time)
                     List<CoreSC> scDescendingCoreBelow = descendingScCore(oneEdgeToEachTimeBelowSC);
                     alledgeTimeBelowSCList = addToAllCList(alledgeTimeBelowSCList, scDescendingCoreBelow); // Add CoreSC below the threshold edge to the List
                     edgeToEachTimeBelowSC.put(sdmEdge, scDescendingCoreBelow);
                 }
             }
             if (edgeToEachTimeBelowSC.isEmpty() || alledgeTimeBelowSCList.isEmpty()){
                 log.info("All edges exceed the threshold without re-adjustment!"); 
                 return originGraph;   // All edges do not exceed the SC threshold time, core, do not enter the algorithm to return

             }

          // 3. Only the time window adjustment algorithm finds the ARrequests of the core on this link, adjusts to other times with the same core as the link, the original SC becomes larger, and now the threshold is not successful.
             alledgeTimeSCList = descendingScCore(alledgeTimeSCList);
             alledgeTimeBelowSCList = descendingScCore(alledgeTimeBelowSCList);
             for (CoreSC singleBelowCoreSC : alledgeTimeBelowSCList){
             	LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(singleBelowCoreSC.getEdgeId());
                 LinkCores singleSdmCore = mapToCore(singleBelowCoreSC, originGraph);
                 List<Service> ServiceConnections = findServiceConnections(singleSdmCore);  // 找ARrequests
               //  if (aloneConnections == null || aloneConnections.isEmpty()){
                     if (ServiceConnections == null || ServiceConnections.isEmpty()){

                 }else {
                     for (Service event: ServiceConnections){
                      //   List<CoreSC> occupiedARCoreSC = serviceEventInfo.get(event).getKey();
                        // List<Integer> occupiedWaveNum = serviceEventInfo.get(event).getValue();
                         List<CoreSC> occupiedARCoreSC = serviceEventInfo.get(event).getFirst();
                         List<Integer> occupiedWaveNum = serviceEventInfo.get(event).getSecond();
                         
                         List<CoreSC> allDescendingCoreSCList = edgeToEachTimeSC.get(sdmEdge);  
                         for (CoreSC singleDescendingCoreSC : allDescendingCoreSCList){
                         	// It is in descending order, SC chooses from big to small
                             // Whether the event service is moved to the coreSC, one spectrum is available, two is not crosstalk, and three times are satisfied, and the four-party SC raises one party without exceeding the threshold
                             if(isTimeAvailable()){
                                 log.info("Successful transfer！");
                                 break;
                             }else {
                             	// Continue to the next sc value of the target coreSC, this loop.
                             }
                         }
                     }
                 }
             }




             Map<LinkID, List<CoreSC>> belowScEdgeAllCoreScList = calculateLinkSC(originGraph);
             // no edge with a threshold of *6, no refactoring required
                if (belowScEdgeAllCoreScList == null || belowScEdgeAllCoreScList.isEmpty()){
                    log.info("No threshold is required to exceed the threshold！");
                    return originGraph;
                }

                Loop:
                for (LinkID edgeId : belowScEdgeAllCoreScList.keySet()) {

                    List<CoreSC> minScEdgeAllCoreSc = belowScEdgeAllCoreScList.get(edgeId);

                  // it is very important to check whether the SC value equal to 0 can be adjusted If there is not much service at the beginning, the SC of the first core is equal to 0, indicating that it is full, this time it is
                    //  adjustments to add resources in  the cores, may increase the  fragmentation, but if it is full for 6 cores, SC equals 0 does not adjust that reconstruction is meaningless.

                    for (CoreSC coreSC : minScEdgeAllCoreSc) {
                    	// If the SC of the core on the link is less than the SC_THRESHOLD*7 threshold, it is necessary to perform spectrum reconstruction.
                        // Screen out the 7th core in minScEdgeAllCoreSc, for the other 6 core traversal, less than the threshold of the core adjustment, exclude the 7th core, first adjust the threshold equal to 0
                        // until the SC of all the cores of the link is greater than the threshold *7, or the SC value is better than before

                        if (coreSC.getCoreIndex() !=6 && coreSC.getSc() < SC_THRESHOLD) {
                            log.info("Spectrum reconstruction！");
                            long startTime = System.currentTimeMillis();
                            dataCollection.addSpectrumShiftNum();

                            LinkImplementation edge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
                            LinkCores worstCore = edge.getCoreList().get(coreSC.getCoreIndex());
                            double oldWorstSc = calculateCoreSC(worstCore);

                            Map<Integer, List<Integer>> connections = getConnections(worstCore);
                            checkNotNull(connections);
                            Map<Integer, List<Integer>> aloneConnections = findAloneConnections(worstCore);
                            checkNotNull(aloneConnections);

                            for (Map.Entry<Integer, List<Integer>> connection : aloneConnections.entrySet()) {
                                int connectionId = connection.getKey();
                                // Get the spectrum resource number set occupied by the connection
                                List<Integer> occupiedByConn = connection.getValue();
                             // Traverse all other cores on the edge, find the core on which the resource number set corresponding to occupiedByConn is available, and exclude the current core (core index)
                                List<LinkCores> avaiForSpecificConn = getAvaiCoresForConn(edge, occupiedByConn,
                                            coreSC.getCoreIndex());
                             // If avaiForSpecificConn is non-null and not empty, indicating that the connection has the possibility of being adjusted to other cores on the edge
                                if (avaiForSpecificConn.size() >= 1) {  // The connection has a Core that can be moved

                                	// Traverse other available cores
                                    for (int j = 0; j < avaiForSpecificConn.size(); j++) {

                                    	// Is it a recalculation after the transfer is made in the past?
                                    	// connection takes up the destination orientedCore where the resource is to be transferred.
                                    	LinkCores orientedCore = avaiForSpecificConn.get(j);
                                        double oldOrientedSc = calculateCoreSC(orientedCore);
                                        // First transfer of spectrum resources between originalCore and orientedCore
                                        if (moveConn(worstCore, orientedCore, occupiedByConn)) {

                                        	// If the transfer is successful
                                            // Recalculate the spectral renormalization value SC of the two cores of the source and sink after the transfer
                                           // This edgeC and value calculation may be a bit problematic. Why is the coreSC method debugged?
                                            double newMinScSum = calculateLinkSCSum(edge);
                                            double newWorstSc = calculateCoreSC(worstCore);
                                            double newOrientedSc = calculateCoreSC(orientedCore);
                                           
                                            if (newMinScSum > SC_THRESHOLD * 7) {
                                                if (!checkIfCrosstalk(orientedCore, occupiedByConn)) {
                                                    //if there is no crosstalk
                                                    moveConnectionId(worstCore, orientedCore, occupiedByConn, edge.getEdgeId(),
                                                                connectionId);
                                                    long endTime = System.currentTimeMillis();
                                                    dataCollection.addSpectrumSuccessShiftNum();
                                                    dataCollection.addReconstructTime(eventIndex, startTime, endTime);
                                                    log.info("Refactoring is successful! The moving service is{}。", connectionId);
                                                    break Loop;
                                                } else {
                                                    if (!moveConn(orientedCore, worstCore, occupiedByConn)) {
                                                        throw new RollbackException("Rollback failure！");
                                                    }
                                                }
                                            }  else if (newWorstSc > oldWorstSc && newOrientedSc > SC_THRESHOLD) {
                                            if (!checkIfCrosstalk(orientedCore, occupiedByConn)) {
                                            	// If there is no crosstalk, it means that the adjustment is successful.
                                                // There is a problem here. If the adjustment is successful, the break should jump out of the traversal of connections instead of just jumping out.
                                                // Traversal of other available cores?
                                                // Compliant with refactoring, the serviceId in the band of the sink core is also moved (previous wavelength occupation has been modified), and eventinfo is modified.
                                                moveConnectionId(worstCore, orientedCore, occupiedByConn, edge.getEdgeId(),
                                                            connectionId);
                                                long endTime = System.currentTimeMillis();
                                                dataCollection.addSpectrumSuccessShiftNum();
                                                dataCollection.addReconstructTime(eventIndex, startTime, endTime);
                                                log.info("Refactoring is successful! The service is transmited {}。", connectionId);
                                                // do nothing, 跳到下一个avaiForSpecificConn
                                            } else {
                                            	// If crosstalk is caused, it means that this adjustment fails, and the spectrum transfer situation needs to be rolled back.   
                                                if (!moveConn(orientedCore, worstCore, occupiedByConn)) {

                                                    throw new RollbackException("Rollback failed！");
                                                }
                                            }

                                        } // If the SC and the value are not greater than the 6 threshold, the current core threshold is not increased, and the destination core is not greater than the
                                        else {
                                        	// If the new SC after modification cannot meet the threshold limit, it means that the adjustment fails, and the spectrum transfer situation needs to be rolled back.
                                            //Continue refactoring operation for the next avaiForSpecificConn

                                            if (!moveConn(orientedCore, worstCore, occupiedByConn)) {
                                            	// If the rollback fails, the program can be terminated.
                                                throw new RollbackException("Rollback failure！");
                                            }
                                        }

                                    } else {
                                        // do nothing ，Find the next core in the same edge that meets the moving conditions                                    }
                                }
                                    }

                            } else {
                            	//do nothing, then find the next connection
                                //TODO Casd_Ds_Sc algorithm replication
                                //handle return value is true, indicating that the refactoring is successful, returning return originGraph; returning false, indicating that the refactoring failed or
                                // Is the Cas_Ss_Dc algorithm, do not do any processing, make the next connection judgment
                                if (handle(worstCore, occupiedByConn, connectionId, originGraph, eventIndex,startTime)) {
                                    return originGraph;
                                }
                            }
                        }
                        log.info("The spectrum corresponding to all connectionIds on the worstCore, and other cores of the same edge do not satisfy the moving and crosstalk conditions.\\n\" + \n" + 
                        		"                        		\"，\" + \"Or have been refactored successfully, continue to the next core！");
                    }
                    log.info("All the spectrums corresponding to all connectionIds on the coreSc below the threshold, and other cores of the same edge do not satisfy the moving and crosstalk conditions.\\n\" + \n" + 
                    		"                    		\"，\" +\"This refactoring failed! Continue to the next side of the adjustment\\n\" + ");
                    // do nothing
                }
            }
            log.info("The edge traversal of all hell thresholds is completed, and the adjustment of the condition is still not met, and the reconstruction fails！");
            return originGraph;

        }

    }





    private boolean isTimeAvailable() {
		return true;
	}


private List<Service> findServiceConnections(LinkCores SdmCore) {
		
			Service ServiceEvent2= new Service(0, SC_THRESHOLD, null, null, 0, 0, 0);
    List<Service> ServiceConnection = new ArrayList<Service>();
        CoreSC CoreSC= new CoreSC(); 
            List<FrequencySlots> coreWavelength = SdmCore.getWavelength();
     //   	List<ServiceEvent> serviceEventi = ServiceEvent2.clone();
        //	ServiceEvent ServiceEvent2=(ServiceEvent) ServiceEvent2.clone();

            List<CoreSC> OccupiedARCoreSC = new ArrayList<CoreSC>();
        
          //Remove all the occupied spectrum blocks on the core, which is the spectrum block. This bool value indicates whether a new block value needs to be opened.
            boolean ServiceConnectionOnBlock = true;
            for (int i=0; i<coreWavelength.size(); i++) {
                if (coreWavelength.get(i).getIsOccupied()) {
                    if (ServiceConnectionOnBlock) {
                    	ServiceEvent2=null;
                    	ServiceConnection.add(ServiceEvent2);
                    	ServiceConnectionOnBlock=false;
                    } else {
                    	ServiceEvent2.setIndex(i);
                        ServiceEvent2.setSource(i);
                        ServiceEvent2.setDestination(i);
                        ServiceEvent2.setRequiredWaveNum(i);

                    }
                } else {
                	ServiceConnectionOnBlock = true;
                    if (ServiceEvent2 != null) {
                       // occupiedBlock.add(avaiSpecBlock);
                    	ServiceConnection.add( ServiceEvent2);
                       // avaiSpecBlock = null;
                        ServiceEvent2=null;
                    }
                }
            }
            if (ServiceEvent2 != null) {
             //   occupiedBlock.add(avaiSpecBlock);
            	ServiceConnection.add( ServiceEvent2);

            }
            if (ServiceConnection.isEmpty()) {
                return null;
            }
            if (ServiceEvent2!=null) {
            	ServiceConnection.add(ServiceEvent2);
            }
/////////////////////////////////////////////////////////////////////
           		return ServiceConnection ;
	}


	private List<CoreSC> filterEachTimeCoreBelowSC(List<CoreSC> scDescendingCoreAll) {
		
		
		
		for (int i=scDescendingCoreAll.size()-1; i>=0; i--) {
            if (scDescendingCoreAll.size() <  SC_THRESHOLD) {
            	scDescendingCoreAll.remove(i);//remove will move backwards, so choose reverse traversal
            }
        }
        if (scDescendingCoreAll.isEmpty()) {
            return null;
        }
        return scDescendingCoreAll;
    	//scDescendingCoreAll= new ArrayList<CoreSC>(); 
  /** 		List<CoreSC> filteredCoreSC = null;

    	for (CoreSC coreSC1 : scDescendingCoreAll) {

// converting Stream to List in Java
 filteredCoreSC = scDescendingCoreAll.stream()
                     //     .filter(num -> coreSC1.getSc() > SC_THRESHOLD)
                          .filter(CoreSC1 -> scDescendingCoreAll.size() > SC_THRESHOLD)

                           .collect(Collectors.toList());



        }
            return filteredCoreSC;*/
	}

	
	private List<CoreSC> addToAllCList(List<CoreSC> alledgeTimeSCList, List<CoreSC> scDescendingCoreAll) {
        List<CoreSC> lst = new ArrayList<CoreSC>();
        lst.addAll(alledgeTimeSCList);
        lst.addAll(scDescendingCoreAll);
		return lst;
	}


	private List<CoreSC> descendingScCore(List<CoreSC> descendingScCore) {
		

		 Collections.sort(descendingScCore, new CorscComparator()); 
     		Collections.reverse(descendingScCore);
				return descendingScCore;
	}


	protected boolean handle(LinkCores worstCore , List<Integer> occupiedByConn,int connectionId ,
                             Graph originGraph, int eventIndex,long startTime) {
        // do nothing
        return false;
    }

    /**
     * Calculate the spectral renormalization SC of all cores of all edges - not tested yet
     * @param originalGraph whenever the business is added or deleted after the Graph
     * @return List of all core SC values on all edges

    */
    public List<CoreSC> calculateGraphSC(Graph originalGraph){

        List<CoreSC> allCoreSc = new ArrayList<CoreSC>();
        Set<LinkID> edgeIds = originalGraph.getEdges().keySet();

        for (LinkID edgeId: edgeIds){

        	LinkImplementation edge = (LinkImplementation) originalGraph.getEdges().get(edgeId);
            for (int i=0; i< edge.getCoreList().size(); i++){

                int count = -1;
                CoreSC coreSC = new CoreSC();
                LinkCores sdmCore = edge.getCoreList().get(i);
                List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
             // Traverse the occupancy of the wavelength on the core, first find the maximum slot number and the total number of occupied slots

                for (int j = 0; j < coreWavelength.size(); j++){
                    if (coreWavelength.get(j).getIsOccupied()){
                    	// Find the maximum and minimum slot numbers, and the total number of occupied slots
                        count = j;
                    }
                }
                if ( count == -1){
                    coreSC.setSc(Double.POSITIVE_INFINITY);
                } else {
                    coreSC.setSc(calculateCoreSC(sdmCore));
                }

             // Calculate SC, join this edge this core
                coreSC.setEdgeId(edgeId);
                coreSC.setCoreIndex(i);
                allCoreSc.add(coreSC);
            }
        }
        return allCoreSc;
    }

    /**
     * Calculate all SC-based SC values in the entire network, select the SC with the smallest Link, and return all 7 core CoreSc on the edge.
      * @param originalGraph whenever the business is added or deleted after the Graph
      * @return SC value minimum list of SC values for all cores

     */
    public Map<LinkID, List<CoreSC>> calculateLinkSC(Graph originalGraph){
   //     public Map<EdgeId, List<CoreSC>> calculateLinkSC(Graph originalGraph){


//        List<CoreSC> rtn = new ArrayList<CoreSC>();
        Map<LinkID, List<CoreSC>> rtn = new HashMap<LinkID, List<CoreSC>>();

     // Store all edges and their corresponding 7-core SC, 7-core SC sums
        Set<LinkID> edgeIds = originalGraph.getEdges().keySet();
        Map<LinkID, List<CoreSC>> allEdgeScMap = new HashMap<LinkID, List<CoreSC>>();
        Map<LinkID, Double> allEdgeScSumMap = new HashMap<LinkID, Double>();
        List<Double> scSumList = new ArrayList<Double>();

        for (LinkID edgeId: edgeIds){

            double scSumPerEdge = 0;
            List<CoreSC> perScEdgeAllCoreSc = new ArrayList<CoreSC>();
            LinkImplementation edge = (LinkImplementation) originalGraph.getEdges().get(edgeId);
            for (int i=0; i< edge.getCoreList().size()-1; i++){

                int count = -1;
                CoreSC coreSC = new CoreSC();
                LinkCores sdmCore = edge.getCoreList().get(i);
                List<FrequencySlots> coreWavelength = sdmCore.getWavelength();

             // Traverse the occupancy of the wavelength on the core, first find the maximum slot number and the total number of occupied slots
                for (int j = 0; j < coreWavelength.size(); j++){
                    if (coreWavelength.get(j).getIsOccupied()){
                    	// Find the maximum and minimum slot numbers, and the total number of occupied slots
                        count = j;
                    }
                }
                if ( count == -1){
                    coreSC.setSc(Double.POSITIVE_INFINITY);
                } else {
                    coreSC.setSc(calculateCoreSC(sdmCore));
                }

                //计算SC，加入此edge此core
                coreSC.setEdgeId(edgeId);
                coreSC.setCoreIndex(i);
                scSumPerEdge = scSumPerEdge + coreSC.getSc();
                perScEdgeAllCoreSc.add(coreSC);
            }
            allEdgeScMap.put(edgeId, perScEdgeAllCoreSc);
            allEdgeScSumMap.put(edgeId, scSumPerEdge);
            scSumList.add(scSumPerEdge);
        }

        //找出所有小于阈值的edge，都要调整
        for (LinkID edgeId : allEdgeScSumMap.keySet()){
            if (allEdgeScSumMap.get(edgeId) < SC_THRESHOLD*6){
                rtn.put(edgeId, allEdgeScMap.get(edgeId));
            }
        }
     // returns null if there are no edges less than the threshold
        if (rtn == null || rtn.isEmpty()){
            return null;
        }

   
        return rtn;
    }

    /**
     * Calculate the value of all CoreSc for a given edge
      * @param edge side
      * @return link SC and values of all cores

     */
    public Double calculateLinkSCSum(Link edge){

        double scSumPerEdge = 0;
        LinkImplementation sdmEdge = (LinkImplementation) edge;
        for (int i = 0; i < sdmEdge.getCoreList().size()-1; i++) {
            CoreSC coreSC = new CoreSC();
            coreSC.setEdgeId(edge.getEdgeId());
            coreSC.setCoreIndex(i);
         // Traverse the occupancy of the wavelength on the core, first find the maximum slot number and the total number of occupied slots
            coreSC.setSc(calculateCoreSC(sdmEdge.getCoreList().get(i)));
            //计算
            scSumPerEdge = scSumPerEdge + coreSC.getSc();
        }
        return scSumPerEdge;
    }

    /**
     * Calculate the regularity SC based solely on the SdmCore core - successful test
      * * Calculate the regularity SC based only on the SdmCore core - successful test
      * @param sdmCore
      * @return SC
     */
    public double calculateCoreSC(LinkCores sdmCore){

        double maxSlotNum = -1;
        double minSlotNum = -1;
        int occupiedSlotTotalNum = 0;
        int spectrumBlockTotalNum = 0;
        double resultCoreSC = -1;
        List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
     // Traverse the occupancy of the wavelength on the core, first find the maximum slot number and the total number of occupied slots

        for (int j = 0; j < coreWavelength.size(); j++){
            if (coreWavelength.get(j).getIsOccupied()){
            	// Find the maximum and minimum slot numbers, and the total number of occupied slots

                maxSlotNum = j;
                occupiedSlotTotalNum = occupiedSlotTotalNum + 1;
            }
        }
        if ( maxSlotNum == -1){
            return (Double.POSITIVE_INFINITY);
        }
     // Traverse the occupancy of the wavelength on the core, first find the smallest slot number
        for (int j = 0; j < coreWavelength.size(); j++ ){
            if (coreWavelength.get(j).getIsOccupied()){
                minSlotNum = j;
                break;
            }
        }
        if (minSlotNum == 49){
            return 0;
        }

       
        // Split the spectrum block, and there is List<List<Integer>>
        // First find out the number of the wave that is not occupied, save it into the list
        List<Integer> unoccupiedList = new ArrayList<Integer>();
        for (int j = 0; j < coreWavelength.size(); j++){
            if (!coreWavelength.get(j).getIsOccupied()){
                unoccupiedList.add(j);
            }
        }
        
        // Traverse the list that is not occupied, according to whether the number is continuously divided into spectrum blocks, first of all, the extreme case, when the list has only one element
        // Because the following j has j+1, size is size () -1 when size is 1, j < 1-1; when there is no element, all are occupied, return 0
        if (unoccupiedList.size() == 0){
            return 0;
        }
        if (unoccupiedList.size() != 1) {
            for (int j = 0; j < unoccupiedList.size() - 1; j++) {
                //TODO 可能有问题
                if (!unoccupiedList.get(j + 1).equals(unoccupiedList.get(j) + 1)) {
                    spectrumBlockTotalNum = spectrumBlockTotalNum + 1;
                }
            }
        }
        spectrumBlockTotalNum = spectrumBlockTotalNum +1;

        //计算SC，加入此edge此core
        resultCoreSC = (maxSlotNum-minSlotNum+1)*(coreWavelength.size()-occupiedSlotTotalNum)
                /(occupiedSlotTotalNum*spectrumBlockTotalNum);
        return resultCoreSC;
    }

    /**
     * Calculate the corresponding connections on the worst-case core - the test is successful
      * @param worstCore Worst SdmCore
     * @return Map<connectionId/waveServiceId, occupiedResource of this connectionId>
     */
    public Map<Integer, List<Integer>> getConnections(LinkCores worstCore){

        Map<Integer, List<Integer>> coreConnectionMap = new HashMap<Integer, List<Integer>>();
        Set<Integer> waveServiceIdSet = new HashSet<Integer>();
        List<Integer> waveServiceIdList = new ArrayList<Integer>();
        List<Integer> innerConnectionList;
        List<FrequencySlots> coreWavelength = worstCore.getWavelength();
        // Remove all the connectionId in the core's wavelength into the Set, the set will not repeat
        for (int i = 0;i < coreWavelength.size()-1; i++){
            if (coreWavelength.get(i).getIsOccupied() && coreWavelength.get(i).getWaveServiceId() != -1) {
                waveServiceIdSet.add(coreWavelength.get(i).getWaveServiceId());
            }
        }
     // Convert Set to List Store // Convert Set to List store
        for (Integer waveServiceId : waveServiceIdSet){
            waveServiceIdList.add(waveServiceId);
        }

     // Traverse all connectionIds, find all the wavelengths corresponding to the connectionId, and store them in the Map
        for (int i = 0;i < waveServiceIdList.size();i++){
            innerConnectionList = new ArrayList<Integer>();
            for (int j =0;j < coreWavelength.size(); j++){
                if (waveServiceIdList.get(i) == coreWavelength.get(j).getWaveServiceId()){
                    innerConnectionList.add(coreWavelength.get(j).getId());
                }
            }
            coreConnectionMap.put(waveServiceIdList.get(i),innerConnectionList);
        }
        return coreConnectionMap;
    }

    /**
     * 
     * Find out the independent connections on the core that are not occupied by the left and right, and adjust these connections.
      * @param worstCore adjusted core
      * @return returns independent connections, serviceid - resource usag
     */
    public Map<Integer, List<Integer>> findAloneConnections(LinkCores worstCore){

        List<List<Integer>> occupiedBlock = new ArrayList<List<Integer>>();
        List<FrequencySlots> coreWavelength = worstCore.getWavelength();
        Set<Integer> waveServiceIdSet = new TreeSet<Integer>();
        List<Integer> waveServiceIdList = new ArrayList<Integer>();
        Map<Integer, List<Integer>> coreConnectionMap = new HashMap<Integer, List<Integer>>();

      //Remove all the occupied spectrum blocks on the core, which is the spectrum block. This bool value indicates whether a new block value needs to be opened.

        boolean newBlock = true;
        List<Integer> avaiSpecBlock = null;
        for (int i=0; i<coreWavelength.size(); i++) {
            if (coreWavelength.get(i).getIsOccupied()) {
                if (newBlock) {
                    avaiSpecBlock = new ArrayList<Integer>();
                    avaiSpecBlock.add(i);
                    newBlock = false;
                } else {
                    avaiSpecBlock.add(i);
                }
            } else {
                newBlock = true;
                if (avaiSpecBlock != null) {
                    occupiedBlock.add(avaiSpecBlock);
                    avaiSpecBlock = null;
                }
            }
        }
        if (avaiSpecBlock != null) {
            occupiedBlock.add(avaiSpecBlock);
        }
        if (occupiedBlock.isEmpty()) {
            return null;
        }

     // Filter out independent occupied spectrum blocks that are not occupied by left and right
        List<Integer> firstBlock = occupiedBlock.get(0);
        List<Integer> lastBlock = occupiedBlock.get(occupiedBlock.size()-1);
     // Remove the last block and the first block (first remove the last one), worry about the condition
        if (lastBlock.get(lastBlock.size()-1) == (coreWavelength.size()-1)){
            occupiedBlock.remove(occupiedBlock.size()-1);
        }
      
     // When the SC value is equal to 0, that is, when it is full, it only needs to be deleted once, that is, only one occupied spectrum block, size=1, only the last one is deleted.
        // is greater than 1, the last one and the first one are deleted, provided they are occupied

        if (occupiedBlock.size() > 1 && firstBlock.get(0) == 0){
            occupiedBlock.remove(0);
        }

        // Traverse the occupied block after the filter, the connected connection is stored separately, all connections are stored in the set
        for (List<Integer> oneOccupiedBlock: occupiedBlock){
            for (int j = 0; j < oneOccupiedBlock.size(); j++){
                if (coreWavelength.get(oneOccupiedBlock.get(j)).getWaveServiceId() != -1){
                    waveServiceIdSet.add(coreWavelength.get(oneOccupiedBlock.get(j)).getWaveServiceId());
                }
            }
        }

     // Convert Set to List store
        for (Integer waveServiceId : waveServiceIdSet){
            waveServiceIdList.add(waveServiceId);
        }

     // Traverse all connectionIds, find all the wavelengths corresponding to the connectionId, and store them in the Map

        for (int w = 0; w < waveServiceIdList.size(); w++){
            List<Integer> innerConnectionList = new ArrayList<Integer>();
            for (int v =0; v < coreWavelength.size(); v++){
                if (coreWavelength.get(v).getWaveServiceId() == waveServiceIdList.get(w)){
                    innerConnectionList.add(v);
                }
            }
            coreConnectionMap.put(waveServiceIdList.get(w),innerConnectionList);
        }
        return coreConnectionMap;
    }

    /**
     * Traversing the edge where the worstCore is located, traversing the edge, looking for other cores on the edge, there are available spectrum resources on the core for the moveCore to move - the test is successful
      * The spectrum resource number is the same as the spectrum resource slot occupied by the current connectionId of the worstCore, excluding the current worstCore
      * @param edge,occupiedByConn,coreIndex The edge of the worst SdmCore, the spectrum resource slot where the current connection is located on the worst core, the current core index
      * @return other cores of the same spectrum available on the edge

     */
    public List<LinkCores> getAvaiCoresForConn(LinkImplementation edge, List<Integer> occupiedByConn, int worstCoreIndex){

        List<LinkCores> availSdmCore = new ArrayList<LinkCores>();
     // Traverse to find other cores on the edge, except for the worstCore on the edge, i indicates the coreIndex of the list
        for (int i = 0; i < edge.getCoreList().size()-1; i++){
            if (i != worstCoreIndex){
                List<FrequencySlots> coreWavelength = edge.getCoreList().get(i).getWavelength();
                if (isThisCoreAvail(occupiedByConn,coreWavelength)){
                    availSdmCore.add(edge.getCoreList().get(i));
                }
            }
        }
        return availSdmCore;
    }

    /**
     *
     *  Transfer the connection spectrum resource of the worstCore to the same spectrum resource of the other core orientedCore on the edge, and the transfer succeeds and returns true.
      * is sequential, moving from the former to the latter - successful test
      * @param worstCore, orientedCore, occupiedByConn wish nuclear and sink cores, and the spectrum segments that need to be transferred
      * @return Whether the transfer succeeds and returns true.
     */
    public boolean moveConn(LinkCores worstCore, LinkCores orientedCore, List<Integer> occupiedByConn){

        List<FrequencySlots> worstCoreWave = worstCore.getWavelength();
        List<FrequencySlots> orientedCoreWave = orientedCore.getWavelength();
        boolean isEnough = true;
        for (int i : occupiedByConn) {
            if (orientedCoreWave.get(i).getIsOccupied()) {
                isEnough = false;
                break;
            }
        }

        if (isEnough) {
            for (int i : occupiedByConn) {
                orientedCoreWave.get(i).setOccupiedServiceIndex(0);
                worstCoreWave.get(i).setOccupiedServiceIndex(1);
            }
        }
        return isEnough;
    }

    /**
     *Move the connectionId of the worstCore and orientedCore and modify eventinfo
      * @param worstCore, orientedCore, occupiedByConn worstCore and oriented core, and the shifted spectrum segment
     */
    public void moveConnectionId(LinkCores worstCore, LinkCores orientedCore, List<Integer> occupiedByConn, LinkID edgeId,
                                 int connectionId){

        List<FrequencySlots> worstCoreWave = worstCore.getWavelength();
        List<FrequencySlots> orientedCoreWave = orientedCore.getWavelength();
     // Traverse the spectrum segment that needs to be transferred, the list content is the wave number
        for (int i = 0;i < occupiedByConn.size();i++){
        	// Traverse the worstCore, release the i th connectionId
            for (int j = 0;j < worstCoreWave.size();j++) {
                if (j == occupiedByConn.get(i)) {
//                    connectionId = worstCoreWave.get(j).getWaveServiceId();
                    worstCoreWave.get(j).setwaveServiceId(-1);
                }
            }
            for (int k = 0;k < orientedCoreWave.size();k++) {
                if (k == occupiedByConn.get(i)) {
                    orientedCoreWave.get(k).setwaveServiceId(connectionId);
                }
            }
        }
        try{
        //    List<CoreSC> coreSCList = eventInfo.get(connectionId).getKey();
            List<CoreSC> coreSCList = eventInfo.get(connectionId).getFirst();

//            List<CoreSC> coreSCList = serviceEventInfo.get(connectionId).getKey();
            CoreSC worstCoreSC = new CoreSC(edgeId, worstCore.getId());
            for (CoreSC coreSC : coreSCList) {
                if (coreSC.equals(worstCoreSC)) {
                    coreSC.setCoreIndex(orientedCore.getId());
                    coreSC.setSc(calculateCoreSC(orientedCore));
                    break;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }



    }

    /**
     * After the judgment is moved to the core, whether there is crosstalk at the core of the core - the test is successful.
      * @param orientedCore
      * @return boolesn, no crosstalk returns false, crosstalk returns true
     */
    public boolean checkIfCrosstalk(LinkCores orientedCore, List<Integer> occupiedByConn){

        List<FrequencySlots> orientedCoreWave = orientedCore.getWavelength();
        List<LinkCores> adjantCoreList = orientedCore.getAdjacentCores();

        // Record the number of slots without crosstalk in the spectrum segment
        int countSpecOccu = 0;
        for (int i = 0; i < occupiedByConn.size(); i++) {
            int index = occupiedByConn.get(i);
         // traverse all neighboring cores of the core

            int countAdjCoreOccu = 0;
            for (LinkCores adjacentCore : adjantCoreList) {
            	// Traversing the newly occupied spectrum segment of the sink core, whether its neighboring two cores are equally occupied, and no crosstalk

                if (adjacentCore.getWavelength().get(index).getIsOccupied()){
                    countAdjCoreOccu++;
                }
            }
          // modified the crosstalk condition
            if (countAdjCoreOccu >= adjantCoreList.size()){
           // 	Greater than or equal to 3 indicates crosstalk      
            	return true;
            }else {
            	// Explain that the indexSlot has no crosstalk, countSpecOccu plus one

            	countSpecOccu++;
            }
        }

     // Determine if all countSpecOccu has met the crosstalk-free condition
        if (countSpecOccu == occupiedByConn.size()){
       // Satisfy all tmpAvailResourceLocation without crosstalk, indicating that the core is completely OK, no crosstalk, return false
        	return false;
        }else {
            return true;
        }

    }

    /**
     *In addition to the method getAvaiCoresForConn(), it is really possible to judge whether the i-th core has a frequency band for the specified frequency band of the worstCore - the test is successful.
      * @param coreWavelength, coreWavelength specifies the frequency band, the current i core's wavelength occupancy
      * @return i core is available, available to return true

     */
    public boolean isThisCoreAvail(List<Integer> occupiedByConn, List<FrequencySlots> coreWavelength){

        int count = 0;
        boolean isAvail = false;
        for (int i = 0;i < occupiedByConn.size();i++){
            for (int j = 0;j < coreWavelength.size();j++){
            	// Determine the wavelength number of the ith value of the occupiedByConn, whether the number is occupied by the SdmWavelength corresponding to the coreWavelength
                if (j == occupiedByConn.get(i)) {
                    if (!coreWavelength.get(j).getIsOccupied()) {
                        count = count + 1;
                    }
                }
            }
        }
     // Description All bands in the occupiedBy LIts are available for this core, return true
        if (count == occupiedByConn.size()){
            isAvail = true;
        }
        return isAvail;
    }

    /**
     ** Sort the List
     */
    class CorscComparator implements Comparator<CoreSC> {

        public int compare(CoreSC o1, CoreSC o2) {
            double sc1 = o1.getSc();
            double sc2 = o2.getSc();
            Double dou = sc1;
            return dou.compareTo(sc2);
        }
    }
    /**
     * Sort List<Double>
     */
    class DoubleScComparator implements Comparator<Double> {

        public int compare(Double o1, Double o2) {
            Double dou = o1;
            return dou.compareTo(o2);
        }
    }

    /**
     * Map from CoreSC to a specific SdmCore object.
      * @param coreSC coreSC
      * @return Returns null if there are no mapped objects in the graph.
     */
    private LinkCores mapToCore(CoreSC coreSC, Graph graph) {
    	LinkImplementation edge = (LinkImplementation)graph.getEdges().get(coreSC.getEdgeId());
        if (edge != null) {
            return edge.getCoreList().get(coreSC.getCoreIndex());
        } else {
            return null;
        }
    }


    /**
     * Calculate the coreSC (time, edge, core, sc) for all moments of the edge
      * @param edge the edge to look for
      * @return returns the SC value corresponding to all moments on this edge
     */
    private List<CoreSC> calculateEachTimeCoreSC(Link edge){
     List<CoreSC> cores = new ArrayList<CoreSC>();
  // Only use the timeGraph to retrieve the corresponding data, you need to calculate the sc value (all moments - this side - seven core SC)
        for(Map.Entry<Double, GraphImplement> timeGraphPair: timeGraph.entrySet()){
            double time = timeGraphPair.getKey();
           LinkImplementation sdmEdge = (LinkImplementation) timeGraphPair.getValue().getEdges().get(edge.getEdgeId());
          //  Graph sdmEdge = (Graph) timeGraphPair.getValue().getEdges().get(edge.getLinkID());
         //   GraphImplement sdmEdge = (GraphImplement) timeGraphPair.getValue().getEdges().get(edge.getLinkID());

      //     calculateLinkSCSum(sdmEdge);
        //    calculateLinkSC((sdmEdge);
            calculateLinkSC((Graph) ( sdmEdge));

        }
		return cores;
    }





	protected boolean handle(LinkCores worstCore, List<Integer> occupiedByConn, int connectionId, Graph originGraph,
			int eventIndex, long startTime, List<Timestamp> orderedList) {
		// TODO Auto-generated method stub
		return false;
	}





	protected boolean handle(LinkCores worstCore, List<Integer> occupiedByConn, int connectionId, List<Link> path,
			Graph originGraph, int eventIndex, long startTime, List<Timestamp> orderedList) {
		// TODO Auto-generated method stub
		return false;
	}



}
