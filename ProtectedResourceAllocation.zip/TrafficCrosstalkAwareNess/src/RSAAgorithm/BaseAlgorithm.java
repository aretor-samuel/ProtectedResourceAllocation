package RSAAgorithm;

//import javafx.scene.Node;

//import javafx.util.Pair;
import org.jgrapht.alg.util.Pair;

import Utility.Debug;
import Utility.RollbackException;
import Network.Link;
import Network.Link2;
import Network.LinkID;
import Graph.Graph;
import Graph.GraphImplement;
import Network.LinkCores;
import Network.LinkImplementation;
import Network.Modulation;
import Network.Node2;
import Network.NodeIdImplement;
import TrafficGeneration.Service;
import Network.CoreSC;
import Network.FrequencySlots;
import TrafficGeneration.Timestamp;
import TrafficGeneration.ServiceAssignment;
import DataCollection.CrosstalkCalculations;
import DataCollection.DataCollectionPerSC;
import DataCollection.SpectrumUtilizationRate;

import org.jgrapht.GraphPath;
import org.jgrapht.graph.SimpleWeightedGraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * Created on 2017/05/19.
 * 
 * @author sambabel.
 */
//public class BaseAlgorithm extends ControlAlgorithm {


//public class BaseAlgorithm<V, E extends Link2> extends ControlAlgorithm {
	public abstract class BaseAlgorithm<V extends Node2, E extends Link2> {
	    private static final Logger log = LoggerFactory.getLogger(BaseAlgorithm.class);

	//private Graph graph;
	private SimpleWeightedGraph<V, E> graph;


    // services queue with service index ascend
    private ArrayList<Service> servicesQueue;

    // services queue with service startTime/endTime ascend, so each service will appear twice.
    private ArrayList<Timestamp> servicesOrderedQueue;
  //  private ArrayList<Double> LinkUtilizationData= Lists.newArrayList();
   // private final static ArrayList<Double> LinkUtilizationData= Lists.newArrayList();
    private static ArrayList<Double> LinkUtilizationData= Lists.newArrayList();
    private static ArrayList<Double> CrosstalkAffectedSlots= Lists.newArrayList();




    
    // current services in Graph ordered by ascend. The key represents service index. Be called when new Service arrivals, and old service leaves.
    private  TreeMap<Integer, ServiceAssignment<E>> currentServices;
    // blocked services in Graph ordered by ascend. The key represents service index. Be called when new arrived service failures.
    private TreeMap<Integer, Service> blockedServices;
    private TreeMap<Integer, Service> blockedFailedServices=Maps.newTreeMap();

   // private TreeMap<Integer, FrequencySlots> spectrumSuccessShiftNum;
    public static ArrayList<Pair<Calendar, Integer>> serviceShiftTimeRecords = Lists.newArrayList();
    private List<Link2>path1=Lists.newArrayList();

    public static int serviceShiftTime = 0;
	private int n;

    // passed services in Graph ordered by ascend. The key represents service index. Be called when withdrawing current service.
    private TreeMap<Integer, ServiceAssignment<E>> passedServices;
    
    private  Set<Link2> linkSet= Sets.newHashSet();
    private static int occupiedNum; // the number of slots occupied by different services

   private 	    LinkCores linkcores;

    public static final int UNAVAILABLE = -1;

    /**
     * allocate spectrum resources to services' demand.
     */
   public abstract void Execute();

    public SimpleWeightedGraph<V, E> getGraph() {
        return graph;
    }

    public void setGraph(final SimpleWeightedGraph<V, E> graph) {
        this.graph = graph;
    }

    public ArrayList<Service> getServicesQueue() {
        return servicesQueue;
    }

    public void setServicesQueue(final ArrayList<Service> servicesQueue) {
        this.servicesQueue = servicesQueue;
    }

	public TreeMap<Integer, ServiceAssignment<E>> getCurrentServices() {
        return currentServices;
    }

    public TreeMap<Integer, Service> getBlockedServices() {
        return blockedServices;
    }

  	 public TreeMap<Integer, Service> getblockedFailedServices() {
  	        return blockedFailedServices;
  	    }
    

    public ArrayList<Timestamp> getServicesOrderedQueue() {
        return servicesOrderedQueue;
    }

    public TreeMap<Integer, ServiceAssignment<E>> getPassedServices() {
        return passedServices;
    }

    public void setServicesOrderedQueue(final ArrayList<Timestamp> servicesOrderedQueue) {
        this.servicesOrderedQueue = servicesOrderedQueue;
    }
    
    public  void putCurrentService(ServiceAssignment<E> serviceAssignment) {
        if (currentServices.containsKey(serviceAssignment.getService().getEventId())) {
            throw new RuntimeException("allocate the same services twice.");
        } else {
            currentServices.put(serviceAssignment.getService().getEventId(), serviceAssignment);
        }
    }
    
    public ArrayList<Double> getLinkUtilizationData() {
        return LinkUtilizationData;
    }

    protected static void putLinkUtilizationOutputData(SimpleWeightedGraph<Node2, Link2> graph, List<CoreSC> CoreSclist) {


        SpectrumUtilizationRate ourInstance =  SpectrumUtilizationRate.getInstance();
     

double LinkSetUtilization=ourInstance.calculateUR( graph, CoreSclist);
LinkUtilizationData.add(LinkSetUtilization);

//System.out.println(LinkSetUtilization);
    }
    public ArrayList<Double> getLinkCrosstalkaffectedSlots() {
        return CrosstalkAffectedSlots;
    }

    protected static void putLinkCrosstalkaffectedSlots(SimpleWeightedGraph<Node2, Link2> graph, List<CoreSC> CoreSclist) {


    	CrosstalkCalculations ourInstance =  CrosstalkCalculations.getInstance();
     

double XTPerLinK=ourInstance.calculateCrosstalk( graph, CoreSclist);
CrosstalkAffectedSlots.add(XTPerLinK);

//System.out.println(LinkSetUtilization);
    }

    /**
     * remove a service from current service map.
     * @param serviceIndex
     * @return
     */
    public ServiceAssignment<E> removeCurrentService(int serviceIndex) {
        return currentServices.remove(serviceIndex);
    }

    /**
     * put a passed service.
     * @param serviceAssignment
     */
    public void putPassedService(ServiceAssignment<E> serviceAssignment) {
        if (passedServices.containsKey(serviceAssignment.getService().getEventId())) {
            throw new RuntimeException("put duplicate passed service to passedServices");
        } else {
            passedServices.put(serviceAssignment.getService().getEventId(), serviceAssignment);
        }
    }
    public void addBlockedService(Service service) {
    	 if (passedServices.containsKey(service.getEventId())) {
             throw new RuntimeException("put duplicate bloacked service to bloakservice");
         } else {
        blockedServices.put(service.getEventId(), service);
         }
    }
    public void addBlockedFailedService(Service service) {
      	 if (passedServices.containsKey(service.getEventId())) {
               throw new RuntimeException("put duplicate bloacked service to bloakservice");
           } else {
           	blockedFailedServices.put(service.getEventId(), service);
           }
      }


    public void addServiceShiftTime(int time, Calendar happenedTime) {
        serviceShiftTime = serviceShiftTime + time;
        serviceShiftTimeRecords.add(new Pair<>(happenedTime, time));
    }
    public static ArrayList<Pair<Calendar, Integer>> getServiceShiftTimeRecords() {
        return serviceShiftTimeRecords;
    }

    public static int getServiceShiftTime() {
        return serviceShiftTime;
    }
    
public BaseAlgorithm( final	ArrayList<Service> servicesQueue, final ArrayList<Timestamp> servicesOrderedQueue, final SimpleWeightedGraph<V, E> graph) { 
this.graph = graph;
this.servicesQueue = servicesQueue;
this.servicesOrderedQueue = servicesOrderedQueue;
this.currentServices = Maps.newTreeMap();
this.blockedServices = Maps.newTreeMap();
this.passedServices = Maps.newTreeMap();


}

	//protected  void assignSpetrumResource1(Service serviceEvent, int startIndex,List<Integer> finalResult, List<LinkCores> LinkCores1, List<E> path) {
public List<Modulation> getAllowedModulations() {
	//	return new ArrayList<Modulation>(modulations);
	//	return new ArrayList<Modulation>(Modulation.values()
		List<Modulation> modulations = new ArrayList<Modulation>();
	     int   ordinalno = (int) Math.floor(Math.random() * 5);
	   //  int   ordinalno = generateOrdinalNo();


			for (Modulation modulation : Modulation.values()) {// if (this.modulations[modulation.ordinal()].isSelected())
				
				if (modulation.ordinal()==ordinalno) {
				modulations.add(modulation);
				}
			}
			return modulations;

	}


//protected  void assignSpetrumResource1(Service serviceEvent, int startIndex,List<Integer> finalResult, List<CoreSC> maxCoreScPerEdge, List<E> path) {

	protected  void assignSpetrumResource(Service serviceEvent, List<Integer> finalResult, List<CoreSC> maxCoreScPerEdge, List<E> path) {
	
		
		  int eventId = serviceEvent.getEventId();
	 //     List<CoreSC> coreSCList = new ArrayList<CoreSC>();
	  //    List<LinkCores> LinkCores1 = new ArrayList<LinkCores>();

	      for (CoreSC coreSC : maxCoreScPerEdge) {
	      	for (Link2 edge: path) {
							 
	      		List<LinkCores>sdmCores=edge.getCoreList();
			//	 for (int j=0; j<sdmCores.size(); j++) {
				//for (int j=0; j<sdmCores.size()-1; j++) {
				 LinkCores linkcores=sdmCores.get(coreSC.getCoreIndex());
		//  for (CoreSC coreSC : maxCoreScPerEdge) {
 			//	for (int i=startIndex; i<=startIndex+serviceEvent.getRequiredWaveNum()-3; i++) {
 	 		for (int i=0;i<finalResult.size(); i++) {

 			//	}
 		   //   for (int i : finalResult) {

			//  for ( LinkCores linkcores : sdmCores) {

                //   	for (LinkCores linkcores1: LinkCores1) {
                    //	for (int j=0; j<sdmCores.size(); j++) {
                //		 LinkCores linkcores=sdmCores.get(j);
                   //    	 LinkCores linkcores=sdmCores.get(linkcores1.getId());

                   	//	LinkCores1.add(linkcores);
         			//	for (int i=startIndex; i<=startIndex+serviceEvent.getRequiredWaveNum()-1; i++) {

			// LinkCores linkcores=sdmCores.get(coreSC.getCoreIndex());

//						 LinkCores linkcores=sdmCores.get(i);

			//	for (int i=startIndex; i<=serviceEvent.getRequiredWaveNum()-1; i++) {
		          List<FrequencySlots> wavelengths =linkcores.getWavelength();

	                  if (wavelengths.get(i).getIsOccupied()) {
	           
	                  log.error("Insufficient resources to allocate business");
	              } 
	                  else {
	                	  wavelengths.get(i).setOccupiedServiceIndex(1);
	                wavelengths.get(i).setwaveServiceId(eventId);
	                  wavelengths.get(i).accumulate();
	                 // accumulate();-

	              }
	  }

	                                                     
	      }


	      }
//		       putCurrentService(new ServiceAssignment<>(serviceEvent,startIndex,LinkCores1,finalResult, path));

	   //   putCurrentService(new ServiceAssignment<>(serviceEvent, startIndex,maxCoreScPerEdge,finalResult, path));

			                                                   
			   }
	
protected  void assignSpetrumResource12(Service serviceEvent, int startIndex,int requireWaveNum, List<CoreSC> maxCoreScPerEdge, List<E> path) {

	
	
	  int eventId = serviceEvent.getEventId();
//     List<CoreSC> coreSCList = new ArrayList<CoreSC>();
//    List<LinkCores> LinkCores1 = new ArrayList<LinkCores>();

   // for (CoreSC coreSC : maxCoreScPerEdge) {
    	for (Link2 edge: path) {
						 
    		List<LinkCores>sdmCores=edge.getCoreList();
		//	 for (int j=0; j<sdmCores.size(); j++) {
		//or (int j=0; j<sdmCores.size()-1; j++) {
			//inkCores linkcores=sdmCores.get(j);
	  for (CoreSC coreSC : maxCoreScPerEdge) {
		//	for (int i=startIndex; i<=startIndex+serviceEvent.getRequiredWaveNum()-2;i++) {
				for (int i=startIndex; i<=startIndex+requireWaveNum-2;i++) {


		//for ( LinkCores linkcores : sdmCores) {

          //	for (LinkCores linkcores1: LinkCores1) {
           //   for (int j=0; j<sdmCores.size(); j++) {
            	  int totalSumCore, c,nextCore, totolCoreNum;
            	  totolCoreNum=7;
            	  totalSumCore=28;
            	  n=totolCoreNum+1; 
            	 //    nextCore=(2*totalSumCore/n)+j;
                //  	 LinkCores linkcores=sdmCores.get(nextCore-1);

          	 LinkCores linkcores=sdmCores.get(coreSC.getCoreIndex());
             //    	 LinkCores linkcores=sdmCores.get(linkcores1.getId());
          	linkcores.setService(serviceEvent);
             	//	LinkCores1.add(linkcores);
   			//	for (int i=startIndex; i<=startIndex+serviceEvent.getRequiredWaveNum()-1; i++) {

		// LinkCores linkcores=sdmCores.get(coreSC.getCoreIndex());

//					 LinkCores linkcores=sdmCores.get(i);
         /**   for (LinkCores adjCore : linkcores.getAdjacentCores()) {
                 if (!adjCore.getWavelength().get(i).getIsOccupied()) {*/

		//	for (int i=startIndex; i<=serviceEvent.getRequiredWaveNum()-1; i++) {
	          List<FrequencySlots> wavelengths =linkcores.getWavelength();
	          

                if (wavelengths.get(i).getIsOccupied()) {
         
                log.error("Insufficient resources to allocate business");
            } 
                wavelengths.get(i).setOccupiedServiceIndex(eventId);
             //   wavelengths.get(i.stwaveServiceId(eventId);
                wavelengths.get(i).accumulate();
               // accumulate();-

       //    }
//}
			}
                                                   
    }


    }
//	       putCurrentService(new ServiceAssignment<>(serviceEvent,startIndex,LinkCores1,finalResult, path));

    putCurrentService(new ServiceAssignment<>(serviceEvent, startIndex,maxCoreScPerEdge,requireWaveNum, path));

		                                                   
		   }
    
   /** private void putCurrentService(Object serviceAssignment) {
		// TODO Auto-generated method stub
		
	}*/
		
		
//protected void assignSameCore(Service arrivalEvent,int startIndex, List<E> path) {
		protected boolean assignSameCore(Service arrivalEvent, List<E> path) {
	//			protected void assignSameCore(Service arrivalEvent, List<E> path) {


			
	        // TODO
	       int requireWaveNum = arrivalEvent.getRequiredWaveNum();
		//	Link2 sdmEdge =  graph.getEdge(src, dst);

	    	 List<Integer> finalResult = null;
	         List<CoreSC> coreSCList = new ArrayList<CoreSC>();
          /**      for (int i = 0; i < 6 ; i++ ) {
          	            for (Link2 edge : path) {
          	                	
          	                //	  List<LinkCores> firstSdmEdgeCoreList = sdmEdge.getCoreList();
          	  List<LinkCores> firstSdmEdgeCoreList = edge.getCoreList();

          	                    
          	                LinkCores sdmCore =firstSdmEdgeCoreList.get(i);
          	              CoreSC coreSC = calculateCoreSc(edge, sdmCore, requireWaveNum);
      	                coreSCList.add(coreSC);*/
      	                  

	          //  for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size()-1; coreNum++){
	            for (Link2 edge : path) {
	              //  LinkImplementation sdmEdge = (LinkImplementation) edge;
	             //   for (int i = 0; i < 6 ; i++ ) {
	                	
	                //	  List<LinkCores> firstSdmEdgeCoreList = sdmEdge.getCoreList();
	                	  List<LinkCores> firstSdmEdgeCoreList = edge.getCoreList();

	                      // Exclude the 7th core
	                  for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size()-1; coreNum++){

	               //       for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

	              //  LinkCores sdmCore =edge.getCoreList().get(coreNum);
	                LinkCores sdmCore =firstSdmEdgeCoreList.get(coreNum);

	           //     CoreSC coreSC = calculateCoreSc(sdmEdge.getEdgeId(), sdmCore, arrivalEvent.getRequiredWaveNum());
	                CoreSC coreSC = calculateCoreSc(edge, sdmCore, requireWaveNum);
	                coreSCList.add(coreSC);
	                  
	        //    List<List<Integer>> avaiSpectrumBlock = checkAvaiSpectrumBlockInOrderSameIndex(coreSCList, requireWaveNum);
	            List<ArrayList<Integer>> avaiSpectrumBlock = checkAvaiSpectrumBlockInOrderSameIndex( sdmCore,coreSCList, requireWaveNum);

	           if (avaiSpectrumBlock == null || avaiSpectrumBlock.isEmpty()) {
	          //      if (avaiSpectrumBlock != null) {
	          
	            	// If it is null, it means that there are not enough resources on the Core i that are the same as the required spectrum  number, and the service cannot be allocated.
	                // do nothing, calculate and check the next core;

	            } else {
	            	// If it is not null, it means that there are enough resources to satisfy the spectrum consistency, and the service can be allocated. However, it is not yet determined whether the service can be successfully assigned.
	                // Find the spectrum combination that will not cause crosstalk. Note that there may be multiple combinations of one spectrum segment.
	                List<ArrayList<Integer>> noCrosstalkSpectrumBlock =
	                        noCrossTalkFilterSameIndex(sdmCore, avaiSpectrumBlock, coreSCList, requireWaveNum);
	                
	                // check if it is empty
	                if (noCrosstalkSpectrumBlock == null || noCrosstalkSpectrumBlock.isEmpty()) {
	             //      if (noCrosstalkSpectrumBlock != null ) {
	                	

	                	// If it is null, it means that all resources that meet the spectrum consistency will cause crosstalk, cannot allocate services. check the next core.

	               } else {
	                	// all the core that satisfied can randomly be assigned
	                   // List<Integer> finalResult = selectRandomResult(noCrosstalkSpectrumBlock);
	                     finalResult = selectRandomResult(noCrosstalkSpectrumBlock);
	                    assignSpetrumResource(arrivalEvent, finalResult, coreSCList, path);
	                  //  assignSpetrumResource1(arrivalEvent, startIndex,finalResult, coreSCList, path);

	                }
	           //     putCurrentService(new ServiceAssignment<>(arrivalEvent, arrivalEvent.getEventId(), path));;

	            }
	         
	        }
	    

	   }
	     //   putCurrentService(new ServiceAssignment<>(arrivalEvent, arrivalEvent.getEventId(), path));;
//	       putCurrentService(new ServiceAssignment<>(arrivalEvent, arrivalEvent.getEventId(),coreSCList,finalResult, path));;
        return true;

	    }
		
		
		/**
	     *
	     * According to the final set of spectrum numbers provided by finalResult, the resource occupation operation is performed in all Cores corresponding to maxCoreScPerEdge.
	      * @param serviceEvent event
	      * @param finalResult List of spectrum resource numbers eventually occupied
	      * @param maxCoreScPerEdge Occupy CoreC information for Core on different links

	       /**
	     * Verify that there are spectrum blocks in the maxCoreScPerEdge list that do not meet the spectral consistency and are capable of providing a sufficient number of spectra.
	      * Note: The Integer value contained in the return value is incremented by subscript. List<Integer> in List<n> must be less than List<n+1>
	      * @param coreSCList List of CoreSCs, looking for resources that maintain spectrum consistency in these CoreSCs
	      * @param requiredWaveNum The number of requested spectrum resources
	      * @return Returns List if it exists, List<Integer> in List represents the spectrum block; if it does not exist, it returns null.
	     *///TODO
	//    public List<ArrayList<Integer>> checkAvaiSpectrumBlockInOrderSameIndex(Link2 edge, List<CoreSC> coreSCList,
	   //                                                                   int requiredWaveNum) {
	    	  public List<ArrayList<Integer>> checkAvaiSpectrumBlockInOrderSameIndex( LinkCores sdmCore, List<CoreSC> coreSCList, int requiredWaveNum) {
	    	// First get the first CoreSc in maxCoreScPerEdge corresponding to the unoccupied spectrum block on SdmCore.
	    //    LinkCores sdmCore = mapToCore(coreSCList.get(0));
	    	// LinkCores sdmCore =mapTolinkCore( edge, coreSCList.get(0));
	    //    List<LinkCores> linkcores=edge.getCoreList();
	       	        if (sdmCore != null){
	        	
	            List<ArrayList<Integer>> first = findAvaiSpectrumBlocksInOrder(sdmCore.getWavelength() , requiredWaveNum);
	            if (first == null) {
	                return null;
	            }
	         // Filter out List<Integer> that does not satisfy the requested spectrum in List<List<Integer>>
	            List<ArrayList<Integer>> filtered = enoughSpectrumBlockFilter(first, requiredWaveNum);
	            if (filtered == null) {
	                return null;
	            }
	            else {
	            	return filtered;
	            }
	          /*if (coreSCList.size() == 1) {
	                return filtered;
	            }

	         // If there is more than one Core in maxCoreScPerEdge, and the first selected Core contains spectrum resources that meet the consistency
	         /*   for (int i=1; i<coreSCList.size(); i++) {
	            	// First find the intersection of the filtered and the available spectrum of the core being traversed
	            //    LinkCores mapToCore = mapToCore(coreSCList.get(i));
	    	     //   LinkCores mapToCore =linkcores.get(i);
	   	    	 LinkCores mapToCore =mapTolinkCore( edge, coreSCList.get(i));


	                if (mapToCore != null){
	                    List<FrequencySlots> wavelengths = mapToCore.getWavelength();
	                 // Be sure to traverse from big to small, because once an element is removed from the list , the remaining elements will be forwarded.
	                    for (int j=filtered.size()-1; j>=0; j--) {
	                        List<Integer> tmpSpectrumBlock = filtered.get(j);
	                        for (int k=tmpSpectrumBlock.size()-1; k>=0; k--) {
	                            if (wavelengths.get(tmpSpectrumBlock.get(k)).getIsOccupied()) {
	                                tmpSpectrumBlock.remove(k);
	                            }
	                        }
	                    }
	                 // After traversing a core completely, filter the List that satisfies the spectrum number
	                    filtered = enoughSpectrumBlockFilter(filtered, requiredWaveNum);
	                    if (filtered == null) {
	                        return null;
	                    }
	                }else {
	                    throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph");
	                }

	            }
	            return filtered;*/
	        }else {
	            throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph");
	        }
	    }
	    
	// 	private  List<ArrayList<Integer>> noCrossTalkFilterSameIndex( Link2 edge,
     //         List<ArrayList<Integer>> avaiSpectrumBlock,  List<CoreSC> maxCoreScPerEdge, int requiredWaveNum) {
	   		private  List<ArrayList<Integer>> noCrossTalkFilterSameIndex(LinkCores comparedCore ,List<ArrayList<Integer>> avaiSpectrumBlock,  List<CoreSC> maxCoreScPerEdge, int requiredWaveNum) {
    	// Find the spectrum block that will not cause crosstalk first.
    	List<ArrayList<Integer>> tmp = avaiSpectrumBlock;
        for (CoreSC coreSC : maxCoreScPerEdge) {
        	// Find a spectrum block on the Core that does not cause crosstalk
        	tmp = noCrossTalkFilterFurtherSameIndex(comparedCore,tmp, coreSC, requiredWaveNum);
            if (tmp == null || tmp.isEmpty()) {
                return null;
            }
        }

     // Determine the spectrum combination of the filtered spectrum blocks
        return genAvaiCombinationsSameIndex(tmp, requiredWaveNum);
    }
	   	 /**
         * The spectrum combination of the list avaiBlock of available spectrum resource blocks is determined.
          * Note 1: The return value and the incoming avaiBlock point to not the same memory address!
          * Note 2: This method defaults to avaiBlock non-null non-empty and contains enough resources. Therefore, the relevant decision is made when the method is called.
          * @param tmp List of available spectrum resource blocks
          * @param requiredWaveNum Required spectrum resources
          * @return According to Note 2, there must be a spectrum combination that satisfies the condition, so the return value cannot be null or empty.
         */
    	           
   ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //  private List<List<Integer>> noCrossTalkFilterFurtherSameIndex(List<List<Integer>> avaiSpectrumBlock, CoreSC coreSC, Node2 src, Node2 dst,
 //private List<ArrayList<Integer>> noCrossTalkFilterFurtherSameIndex(Link2 edge, List<ArrayList<Integer>> avaiSpectrumBlock, CoreSC coreSC,

//                                                      int requiredWaveNum) {
	   private List<ArrayList<Integer>> noCrossTalkFilterFurtherSameIndex( LinkCores comparedCore, List<ArrayList<Integer>> avaiSpectrumBlock, CoreSC coreSC,

               int requiredWaveNum) {

   //     LinkImplementation sdmEdge = (LinkImplementation) graph.getEdges().get(coreSC.getEdgeId());
     //  Link2 sdmEdge =  graph.getEdge(src, dst);
   //     LinkCores comparedCore = mapToCore(coreSC);
  // LinkCores comparedCore =mapTolinkCore( edge, coreSC);

        List<ArrayList<Integer>> rtn = new ArrayList<ArrayList<Integer>>();

     // The parameter type List<List<Integer>> is not set properly, but it has been difficult to change.
     //   int waveInCoreNum = edge.getCoreList().get(0).getWavelength().size();
     // This variable occupiedTime is the dimensionality reduction of the avaiSpectrumBlock.
        List<Integer> occupiedTime = new ArrayList<Integer>();
        for (List<Integer> m : avaiSpectrumBlock) {
            for (int n : m) {
                occupiedTime.add(n);
            }
        }

        if (comparedCore != null){
        	// traversing from big to small
            for (int i=occupiedTime.size()-1; i>=0; i--) {
                int index = occupiedTime.get(i);
                int count = 0;
             // Traverse the adjacent Core
                for (LinkCores adjCore : comparedCore.getAdjacentCores()) {
                    if (adjCore.getWavelength().get(index).getIsOccupied()) {
                    	
                    	// If the previous count value is 1, this time, the spectrum resources of the adjacent Core are occupied. Therefore, crosstalk is generated and the spectrum is deleted.
                        //TODO modified the crosstalk condition

                        if (count == 6) {
                            occupiedTime.remove(i);
                         // After deleting, there is no need to traverse here, just jump out of the innermost for loop and start looking for the next for loop.
                            break;
                        } else {
                            count++;
                        }
                    }
                }
            }
         // The result obtained in the previous step indicates that the available spectrum does not generate crosstalk.
            // This step sorts the results of the previous step into the form of available spectrum segments, ie List<List<Integer>>, and removes the spectrum segments that do not meet the length requirements.
            if (occupiedTime.isEmpty()) {
                return null;
            } else {
                int point = occupiedTime.get(0);
                ArrayList<Integer> pointList = new ArrayList<Integer>();
                pointList.add(point);

                for (int i=1; i<occupiedTime.size(); i++) {
                	// If this one is th lasts available spectrum slot, we can use it
                	if (occupiedTime.get(i)-1 == occupiedTime.get(i-1)) {
                        pointList.add(occupiedTime.get(i));
                    } else {
                    	// If the next available spectrum and the previous discontinuity, the segmentation of this spectrum segment is successful, and the segmentation of the next spectrum segment is started.
                        // First determine if the length of the currently segmented spectrum segment meets the requirements. Only if it meets the requirements, will it be placed in rtn. If not, discard it.
                        if (pointList.size() >= requiredWaveNum) {
                            rtn.add(pointList);
                        }
                        pointList = new ArrayList<Integer>();
                        pointList.add(occupiedTime.get(i));
                    }
                }

                // After the for loop is over, there is no processing for the last constructed pointList instance, to do tail processing
                if (pointList.size() >= requiredWaveNum) {
                    rtn.add(pointList);
                }

                return rtn;
            }
        }else {
            throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph！");
        }
    }
	   	
	    protected LinkCores mapToCore(CoreSC coreSC) {
	    	       Set<E> edge1 = graph.edgeSet();
                  for (Link2 edge: edge1 ) {
	    	        if (edge != null) {
	    	        	linkcores= edge.getCoreList().get(coreSC.getCoreIndex());

	    	          //  return edge.getCoreList().get(coreSC.getCoreIndex());
	    	        } else {
	    	        	linkcores=null;
	    	         //   return null;
	    	        }
	    	    }
				return linkcores;
	    }
	    protected LinkCores mapTolinkCore(Link2 edge, CoreSC coreSC) {
 	       Set<E> edge1 = graph.edgeSet();
 	       List<LinkCores> linkcores = edge.getCoreList();

         //  for (LinkCores Sdmcores: linkcores ) {
 	        if (edge != null) {
 	        	//linkcores= edge.getCoreList().get(coreSC.getCoreIndex());

 	            return edge.getCoreList().get(coreSC.getCoreIndex());
 	        } else {
 	       // 	linkcores=null;
 	            return null;
 	       // }
 	    }
		//	return Sdmcores;
 }
	    /**
	     * The spectrum combination of the list avaiBlock of available spectrum resource blocks is determined.
	      * Note 1: The return value and the incoming avaiBlock point to not the same memory address!
	      * Note 2: This method defaults to avaiBlock non-null non-empty and contains enough resources. Therefore, the relevant decision is made when the method is called.
	      * @param tmp List of available spectrum resource blocks
	      * @param requiredWaveNum Required spectrum resources
	      * @return According to Note 2, there must be a spectrum combination that satisfies the condition, so the return value cannot be null or empty.
	     */
	    private List<ArrayList<Integer>> genAvaiCombinationsSameIndex(List<ArrayList<Integer>> tmp, int requiredWaveNum) {

	        List<ArrayList<Integer>> rtn = new ArrayList<ArrayList<Integer>>();
	        for (List<Integer> block : tmp) {
	        	// window indicates the size of the window whose length is requiredWaveNum can be slid in the block spectrum segment.
	            int window = block.size() - requiredWaveNum;
	            for (int i=0; i<=window; i++) {
	            	// subList contains the left border and does not contain the right border
	                rtn.add(
	                        copyOf(
	                                block.subList(i, requiredWaveNum+i)));
	            }
	        }

	        return rtn;
	    } 	
	    /**
	     * Deep copy a List<Integer> object. - Test succeeded
	      * @param beCopied the object being copied
	      * @return copy the result

	     */
	    private static ArrayList<Integer> copyOf(List<Integer> beCopied) {
	        checkNotNull(beCopied);
	        ArrayList<Integer> rtn = new ArrayList<Integer>();
	        for (int i : beCopied) {
	            rtn.add(new Integer(i));
	        }
	        return rtn;
	    }
		private ArrayList<Integer> noCrossTalkFilterFurtherSameIndex2(Link2 edge,ArrayList<Integer> avaiSpectrumBlock, CoreSC coreSC,
				int requiredWaveNum) {

	//LinkImplementation sdmEdge = (LinkImplementation) graph.getEdges().get(coreSC.getEdgeId());
	//Link2 sdmEdge =  graph.getEdge(src, dst);

	//LinkCores comparedCore = mapToCore(coreSC);
	LinkCores comparedCore = edge.getCoreList().get(coreSC.getCoreIndex());
	List<FrequencySlots> wavelengths = comparedCore.getWavelength();

	List<ArrayList<Integer>> rtn = new ArrayList<ArrayList<Integer>>();
	ArrayList<Integer> rtn1 = Lists.newArrayList();


	//The parameter type List<List<Integer>> is not set properly, but it has been difficult to change.
	//int waveInCoreNum = edge.getCoreList().get(0).getWavelength().size();
	//This variable occupiedTime is the dimensionality reduction of the avaiSpectrumBlock.
	ArrayList<Integer> occupiedTime = Lists.newArrayList();
	//for (List<Integer> m : avaiSpectrumBlock) {
	         for (int n : avaiSpectrumBlock) {
	       occupiedTime.add(n);
	          }
	//}

	            if (comparedCore != null){
	//traversing from big to small
	    for (int i=occupiedTime.size()-1; i>=0; i--) {
	     int index = occupiedTime.get(i);
	          int count = 0;
	//Traverse the adjacent Core
	     for (LinkCores adjCore : comparedCore.getAdjacentCores()) {
	if (adjCore.getWavelength().get(index).getIsOccupied()) {
	//If the previous count value is 1, this time, the spectrum resources of the adjacent Core are occupied. Therefore, crosstalk is generated and the spectrum is deleted.
	//TODO modified the crosstalk condition

	         if (count == 6) {
	       occupiedTime.remove(i);
	//After deleting, there is no need to traverse here, just jump out of the innermost for loop and start looking for the next for loop.
	        break;
	      } else {
	        count++;
	   }
	      }
	}
	}
	//The result obtained in the previous step indicates that the available spectrum does not generate crosstalk.
	//This step sorts the results of the previous step into the form of available spectrum segments, ie List<List<Integer>>, and removes the spectrum segments that do not meet the length requirements.
	 if (occupiedTime.isEmpty()) {
	return null;
	} else {
//		for (int i=0;i<occupiedTime.size(); i--) {

		if (occupiedTime.size() >= requiredWaveNum) {
		////	rtn1.add(occupiedTime.get(i));
			//}
		//}

	return occupiedTime;

	}
	}
	}else {
	throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph！");
	}
	return occupiedTime;
	}	   	
	    /**
	     *Randomly select a spectrum block
	      * @param noCrosstalkSpectrumBlock available spectrum block
	      * @return returns randomly selected results
	     */
	    public ArrayList<Integer> selectRandomResult(List<ArrayList<Integer>> noCrosstalkSpectrumBlock){
	    	// randomly generate a traversal subscript of 0-noCrosstalkSpectrumBlock-1 size
	        int index = (int)(Math.random()*(noCrosstalkSpectrumBlock.size()-1));
	        ArrayList<Integer> rtn = noCrosstalkSpectrumBlock.get(index);
	        return rtn;
	    }
	    
	    private static List<ArrayList<Integer>> findAvaiSpectrumBlocksInOrder(List<FrequencySlots> wavelengths, int requiredWaveNum) {
	        List<ArrayList<Integer>> rtn = new ArrayList<ArrayList<Integer>>();
	     // This bool value indicates whether a new block value needs to be opened.
	        boolean newBlock = true;
	        ArrayList<Integer> avaiSpecBlock = null;
	        for (int i=0; i<wavelengths.size(); i++) {
	            if (!wavelengths.get(i).getIsOccupied()) {
	                if (newBlock) {
	                    avaiSpecBlock = new ArrayList<Integer>();
	                    avaiSpecBlock.add(i);
	                    newBlock = false;
	                } else {
	                    avaiSpecBlock.add(i);
	                }
	            } else {
	                newBlock = true;
	                if (avaiSpecBlock != null) {
	                    rtn.add(avaiSpecBlock);
	                    avaiSpecBlock = null;
	                }
	            }
	        }
	        if (avaiSpecBlock != null) {
	            rtn.add(avaiSpecBlock);
	        }

	     // Determine the combination of the last available spectrum block. If it is null, it returns null. If it is not empty, the length of the spectrum segment is greater than or equal to the request length.       
	        if (rtn.isEmpty()) {
	            return null;
	        } else {
	        	// Filter out List<Integer> that does not satisfy the requested spectrum in List<List<Integer>>        	
	            List<ArrayList<Integer>> filtered = enoughSpectrumBlockFilter(rtn, requiredWaveNum);
	            if (filtered == null) {
	                return null;
	            }else {
	            	// All combinations of spectra for the spectrum block that meets the length, the length is requiredWaveNum, and returns
	                List<ArrayList<Integer>> filtered1 = genAvaiCombinations(filtered, requiredWaveNum);
	                if (filtered1 == null) {
	                    return null;
	                }else {
	                    return filtered1;
	                }
	            }
	        }
	    }
	    private static List<ArrayList<Integer>> genAvaiCombinations(List<ArrayList<Integer>> filtered, int requiredWaveNum) {

	        List<ArrayList<Integer>> rtn = new ArrayList<ArrayList<Integer>>();
	        for (List<Integer> block : filtered) {
	        	// window indicates the size of the window whose length is requiredWaveNum can be slid in the block spectrum segment.
	            int window = block.size() - requiredWaveNum;
	            for (int i=0; i<=window; i++) {
	            	// subList contains the left border and does not contain the right border
	                rtn.add(
	                        copyOf(
	                                block.subList(i, requiredWaveNum+i)));
	            }
	        }

	        return rtn;
	    }

	    /**
	     * Filter out the spectrum segment of the spectrum segment that does not provide the requiredWaveNum number in the spectrumBlock.
	      * Note 1: The content of the default input spectrumBlock is ascending, and List<Integer> in List<n> must be smaller than List<n+1>. The return value is also ascending.
	      * Note 2: The return value is actually the reference spectrumBlock, they point to the same block of memory. Need to change the return value to void?
	      * Note 3: This method does not detect the incoming spectrumBlock. The logic that calls this method by default should ensure that the parameter is not null and is not empty.
	      * @param spectrumBlock spectrum block to be filtered
	      * @param requiredWaveNum Required contiguous spectrum block resources
	      * @return Returns null if none of the required spectrum blocks are present.。
	     */
	    private static List<Integer> enoughSpectrumBlockFilter1(List<Integer> spectrumBlock, int requiredWaveNum) {
	        for (int i=spectrumBlock.size()-1; i>=0; i--) {
	            if (spectrumBlock.size() < requiredWaveNum) {
	                spectrumBlock.remove(i);//remove it and reverse traversal

	            }
	        }
	        if (spectrumBlock.isEmpty()) {
	            return null;
	        }
	        return spectrumBlock;
	    }
	    private static List<ArrayList<Integer>> enoughSpectrumBlockFilter(List<ArrayList<Integer>> rtn, int requiredWaveNum) {
	        for (int i=rtn.size()-1; i>=0; i--) {
	            if (rtn.get(i).size() < requiredWaveNum) {
	                rtn.remove(i);//remove it and reverse traversal

	            }
	        }
	        if (rtn.isEmpty()) {
	            return null;
	        }
	        return rtn;
	    }


		 /**
	     * If all the spectrums on the Core are occupied, the SC value is 0; if no spectrum is occupied, the SC value is infinity. - The test is successful.
	      * @param LinkID The id of the edge where the Core is located
	      * @param core Core
	      * @return returns an instance of CoreSC

	     * @return 返回CoreSC的实例
	     */
	    private static CoreSC calculateCoreSc(Link2 edgeId, LinkCores core, int requiredWaveNum) {

	    	// Construct an instance of CoreSC
	    	CoreSC rtn = new CoreSC();
	        rtn.setEdgeId2(edgeId);
	        rtn.setCoreIndex(core.getId());

	        // Calculate the SC value
	        double maxOccupiedSlotNum = -1;
	        double minOccupiedSlotNum = -1;
	        double occupiedSlotTotalNum = 0;
	        double availSpectrumBlockTotalNum;
	        boolean isFirstOccupied = true;
	        double sc;

	        for (int i=0; i<core.getWavelength().size(); i++) {
	            FrequencySlots wavelength = core.getWavelength().get(i);
	         // If the spectrum is occupied
	            if (wavelength.getIsOccupied()) {
	            	// If it is the first time to find the occupied spectrum
	                if (isFirstOccupied) {
	                    minOccupiedSlotNum = i;
	                    occupiedSlotTotalNum++;
	                    isFirstOccupied = false;
	                } else {
	                    maxOccupiedSlotNum = i;
	                    occupiedSlotTotalNum++;
	                }
	            }
	        }

	     // If all spectrum resources are not occupied, the SC value is infinite
	        if (maxOccupiedSlotNum == -1) {
	            sc = Double.POSITIVE_INFINITY;
	            rtn.setSc(sc);
	            return rtn;
	        }
	        // If all spectrum resources are occupied, the SC value is 0.
	        if (occupiedSlotTotalNum == core.getWavelength().size()) {
	            sc = 0d;
	            rtn.setSc(sc);
	            return rtn;
	        }

	     // If it is not the above two extreme cases, the search for the occupied spectrum segment does not necessarily have to satisfy the length. The following method needs to be modified.
	     // This method is not suitable for findAvaiSpectrumBlocksInOrder
	        List<ArrayList<Integer>> avaiSpectrumBlocks = findAvaiSpectrumBlocksInOrder(core.getWavelength(),requiredWaveNum);
	        if (avaiSpectrumBlocks == null) {
	        	// Not necessarily, there may not be two extreme cases, the middle is occupied but the length of the request is not satisfied, so the latter is correct.
	            log.info("No spectrum segment available");
	        } else {
	            availSpectrumBlockTotalNum = avaiSpectrumBlocks.size();
	            sc = (maxOccupiedSlotNum - minOccupiedSlotNum + 1) / occupiedSlotTotalNum *
	                    (core.getWavelength().size() - occupiedSlotTotalNum) / availSpectrumBlockTotalNum;
	            rtn.setSc(sc);
	        }
	        return rtn;
	    }
	    protected Pair<Integer, Pair<Integer,  List<CoreSC>>> FindPathNoCrosstalkResourcesFirstAvailable4(List<Link2> path, Service demand) {
//			public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {

			//  ArrayList<Integer>finalResult = new ArrayList<>(); 
		      List<CoreSC> coreSCList = new ArrayList<CoreSC>();
		       ArrayList<Integer> list=new ArrayList<>();
		         int k=0;
		    //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
		    //     ArrayList<Integer> avaiIntersectionList;
		         Pair<ArrayList<Integer>,  List<CoreSC>> avaiIntersectionList;

		            for (Modulation modulation : getAllowedModulations()) {
		   				//		 for (Modulation modulation : Modulation.values()) {
		   							 
		            	//part.getCoreList();
		           	 path.get(0).setModulationIfBetter(modulation, 4);


		          // 	 part.setModulationIfBetter(modulation, 4);
		   							}
		  // }
					int	requireWaveNum = path.get(0).getModulation().slicesConsumption1()[(int) Math.ceil(demand.getVolume() / 10) - 1];

								 
			     //   System.out.println(metric+"****"+this.metric+"****" +modulation.toString());
		         if (path.isEmpty()) {
		        //     return UNAVAILABLE;
		          //   return new Pair<>(UNAVAILABLE, coreSCList);
		             return   new Pair<>(UNAVAILABLE, new Pair<Integer,  List<CoreSC>>(UNAVAILABLE, coreSCList));

		         } else if (path.size() == 1){

	     
		        	 avaiIntersectionList = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

		                   if (avaiIntersectionList.getFirst().size() < requireWaveNum) {
		                   //    return UNAVAILABLE;
		      	          //   return new Pair<>(UNAVAILABLE, avaiIntersectionList.getSecond());
		        	           return   new Pair<>(UNAVAILABLE, new Pair<Integer,  List<CoreSC>>(UNAVAILABLE, avaiIntersectionList.getSecond()));

		                   }
		               } else {
		                   
		              //      TreeSet<Integer> avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
		                    Pair<TreeSet<Integer>,  List<CoreSC>>avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);

		                    // Exclude the 7th core
		        /*        for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

		             //       for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

		            //  LinkCores sdmCore =edge.getCoreList().get(coreNum);
		              LinkCores sdmCore =firstSdmEdgeCoreList.get(coreNum);

		         //     CoreSC coreSC = calculateCoreSc(sdmEdge.getEdgeId(), sdmCore, arrivalEvent.getRequiredWaveNum());
		              CoreSC coreSC = calculateCoreSc(path.get(0), sdmCore, requireWaveNum);
		              coreSCList.add(coreSC);
		                }*/

		                   for (int i=1; i<path.size(); i++) {
		                //     TreeSet<Integer> specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
		                	   Pair<TreeSet<Integer>,  List<CoreSC>>specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);

		            	
		                  //     intersection(avaiIntersectionSet, specificEdgeAvailSet);
		                       intersection(avaiIntersectionSet.getFirst(), specificEdgeAvailSet.getFirst());

		                       // if the size of intersection set is small than requiredSlotNum, return -1.
		                       if (avaiIntersectionSet.getFirst().size() < requireWaveNum) {
		                        //   return UNAVAILABLE;
		          	          //   return new Pair<>(UNAVAILABLE, avaiIntersectionSet.getSecond());
		            	           return   new Pair<>(UNAVAILABLE, new Pair<Integer,  List<CoreSC>>(UNAVAILABLE, avaiIntersectionSet.getSecond()));


		                       }
		                   }
		                   // transform set to list.
		                   // In TreeSet, over the elements in this set in ascending order.
		                   avaiIntersectionList = treesetToArraylist1(avaiIntersectionSet);
		               }
		                   
		  
			//	return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	          //  return new Pair<>(searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum), coreSCList);
	       //     return new Pair<>(searchLowestAvaiIndex(avaiIntersectionList.getFirst(), requireWaveNum), avaiIntersectionList.getSecond());

	            return   new Pair<>(requireWaveNum, new Pair<Integer,  List<CoreSC>>(searchLowestAvaiIndex(avaiIntersectionList.getFirst(), requireWaveNum), avaiIntersectionList.getSecond()));

		  
		  }

	    protected Pair<Integer, Pair<Integer,  List<CoreSC>>> FindPathBackupResourcesFirstAvailable4(List<Link2> path, Service demand) {
//			public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {

			//  ArrayList<Integer>finalResult = new ArrayList<>(); 
		      List<CoreSC> coreSCList = new ArrayList<CoreSC>();
		       ArrayList<Integer> list=new ArrayList<>();
		         int k=0;
		    //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
		    //     ArrayList<Integer> avaiIntersectionList;
		         Pair<ArrayList<Integer>,  List<CoreSC>> avaiIntersectionList;

		            for (Network.Modulation modulation : getAllowedModulations()) {
		   				//		 for (Modulation modulation : Modulation.values()) {
		   							 
		            	//part.getCoreList();
		           	 path.get(0).setModulationIfBetter(modulation, 4);


		          // 	 part.setModulationIfBetter(modulation, 4);
		   							}
	     			//int	volume2 = (int) Math.ceil(serviceToBeAssigned.getSqueezedVolume() / 10) - 1;

		  // }
					int	requireWaveNum = path.get(0).getModulation().slicesConsumption1()[(int) Math.ceil(demand.getSqueezedVolume() / 10) - 1];

								 
			     //   System.out.println(metric+"****"+this.metric+"****" +modulation.toString());
		         if (path.isEmpty()) {
		        //     return UNAVAILABLE;
		          //   return new Pair<>(UNAVAILABLE, coreSCList);
		             return   new Pair<>(UNAVAILABLE, new Pair<Integer,  List<CoreSC>>(UNAVAILABLE, coreSCList));

		         } else if (path.size() == 1){

	     
		        	 avaiIntersectionList = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

		                   if (avaiIntersectionList.getFirst().size() < requireWaveNum) {
		                   //    return UNAVAILABLE;
		      	          //   return new Pair<>(UNAVAILABLE, avaiIntersectionList.getSecond());
		        	           return   new Pair<>(UNAVAILABLE, new Pair<Integer,  List<CoreSC>>(UNAVAILABLE, avaiIntersectionList.getSecond()));

		                   }
		               } else {
		                   
		              //      TreeSet<Integer> avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
		                    Pair<TreeSet<Integer>,  List<CoreSC>>avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);

		                    // Exclude the 7th core
		        /*        for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

		             //       for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

		            //  LinkCores sdmCore =edge.getCoreList().get(coreNum);
		              LinkCores sdmCore =firstSdmEdgeCoreList.get(coreNum);

		         //     CoreSC coreSC = calculateCoreSc(sdmEdge.getEdgeId(), sdmCore, arrivalEvent.getRequiredWaveNum());
		              CoreSC coreSC = calculateCoreSc(path.get(0), sdmCore, requireWaveNum);
		              coreSCList.add(coreSC);
		                }*/

		                   for (int i=1; i<path.size(); i++) {
		                //     TreeSet<Integer> specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
		                	   Pair<TreeSet<Integer>,  List<CoreSC>>specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);

		            	
		                  //     intersection(avaiIntersectionSet, specificEdgeAvailSet);
		                       intersection(avaiIntersectionSet.getFirst(), specificEdgeAvailSet.getFirst());

		                       // if the size of intersection set is small than requiredSlotNum, return -1.
		                       if (avaiIntersectionSet.getFirst().size() < requireWaveNum) {
		                        //   return UNAVAILABLE;
		          	          //   return new Pair<>(UNAVAILABLE, avaiIntersectionSet.getSecond());
		            	           return   new Pair<>(UNAVAILABLE, new Pair<Integer,  List<CoreSC>>(UNAVAILABLE, avaiIntersectionSet.getSecond()));


		                       }
		                   }
		                   // transform set to list.
		                   // In TreeSet, over the elements in this set in ascending order.
		                   avaiIntersectionList = treesetToArraylist1(avaiIntersectionSet);
		               }
		                   
		  
			//	return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	          //  return new Pair<>(searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum), coreSCList);
	       //     return new Pair<>(searchLowestAvaiIndex(avaiIntersectionList.getFirst(), requireWaveNum), avaiIntersectionList.getSecond());

	            return   new Pair<>(requireWaveNum, new Pair<Integer,  List<CoreSC>>(searchLowestAvaiIndex(avaiIntersectionList.getFirst(), requireWaveNum), avaiIntersectionList.getSecond()));

		  
		  }

	/**    protected Pair<Integer,  List<CoreSC>> FindPathNoCrosstalkResourcesFirstAvailable4(List<Link2> path, int requireWaveNum) {
//			public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {

			//  ArrayList<Integer>finalResult = new ArrayList<>(); 
		      List<CoreSC> coreSCList = new ArrayList<CoreSC>();
		       ArrayList<Integer> list=new ArrayList<>();
		         int k=0;
		    //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
		         ArrayList<Integer> avaiIntersectionList;
		         if (path.isEmpty()) {
		        //     return UNAVAILABLE;
		             return new Pair<>(UNAVAILABLE, coreSCList);
		         } else if (path.size() == 1){

	           	  List<LinkCores> firstSdmEdgeCoreList = path.get(0).getCoreList();

	              // Exclude the 7th core
	          for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

	       //       for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

	      //  LinkCores sdmCore =edge.getCoreList().get(coreNum);
	        LinkCores sdmCore =firstSdmEdgeCoreList.get(coreNum);

	   //     CoreSC coreSC = calculateCoreSc(sdmEdge.getEdgeId(), sdmCore, arrivalEvent.getRequiredWaveNum());
	        CoreSC coreSC = calculateCoreSc(path.get(0), sdmCore, requireWaveNum);
	        coreSCList.add(coreSC);
	          }
		                  avaiIntersectionList = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

		                   if (avaiIntersectionList.size() < requireWaveNum) {
		                   //    return UNAVAILABLE;
		      	             return new Pair<>(UNAVAILABLE, coreSCList);

		                   }
		               } else {
		                   
		                    TreeSet<Integer> avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
		                    List<LinkCores> firstSdmEdgeCoreList = path.get(0).getCoreList();

		                    // Exclude the 7th core
		                for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

		             //       for (int coreNum = 0; coreNum < firstSdmEdgeCoreList.size(); coreNum++){

		            //  LinkCores sdmCore =edge.getCoreList().get(coreNum);
		              LinkCores sdmCore =firstSdmEdgeCoreList.get(coreNum);

		         //     CoreSC coreSC = calculateCoreSc(sdmEdge.getEdgeId(), sdmCore, arrivalEvent.getRequiredWaveNum());
		              CoreSC coreSC = calculateCoreSc(path.get(0), sdmCore, requireWaveNum);
		              coreSCList.add(coreSC);
		                }

		                   for (int i=1; i<path.size(); i++) {
		                     TreeSet<Integer> specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
		            	
		                       intersection(avaiIntersectionSet, specificEdgeAvailSet);
		                       // if the size of intersection set is small than requiredSlotNum, return -1.
		                       if (avaiIntersectionSet.size() < requireWaveNum) {
		                        //   return UNAVAILABLE;
		          	             return new Pair<>(UNAVAILABLE, coreSCList);

		                       }
		                   }
		                   // transform set to list.
		                   // In TreeSet, over the elements in this set in ascending order.
		                   avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
		               }
		                   
		                   
		                   
		                 //  k=searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
		                   
		                   
		           //     k= searchLowestAvaiIndex(finalResult, requireWaveNum);
		  //}

		 // }
		   //    }
		             //    }
			//	return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	          //  return new Pair<>(searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum), coreSCList);
	            return new Pair<>(searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum), coreSCList);


		  
		  }
/**	protected int FindPathNoCrosstalkResourcesFirstAvailable4(List<Link2> path, int requireWaveNum) {
//		public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {

		//  ArrayList<Integer>finalResult = new ArrayList<>(); 
	      // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
	       ArrayList<Integer> list=new ArrayList<>();
	         int k=0;
	    //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
	         ArrayList<Integer> avaiIntersectionList;
	         if (path.isEmpty()) {
	             return UNAVAILABLE;
	         } else if (path.size() == 1){

	      
	                  avaiIntersectionList = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

	                   if (avaiIntersectionList.size() < requireWaveNum) {
	                       return UNAVAILABLE;
	                   }
	               } else {
	                   
	                    TreeSet<Integer> avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);


	                   for (int i=1; i<path.size(); i++) {
	                     TreeSet<Integer> specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
	            	
	                       intersection(avaiIntersectionSet, specificEdgeAvailSet);
	                       // if the size of intersection set is small than requiredSlotNum, return -1.
	                       if (avaiIntersectionSet.size() < requireWaveNum) {
	                           return UNAVAILABLE;
	                       }
	                   }
	                   // transform set to list.
	                   // In TreeSet, over the elements in this set in ascending order.
	                   avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
	               }
	                   
	                   
	                   
	                 //  k=searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	                   
	                   
	           //     k= searchLowestAvaiIndex(finalResult, requireWaveNum);
	  //}

	 // }
	   //    }
	             //    }
			return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	  
	  }

  protected int FindPathNoCrosstalkResourcesFirstAvailable5(List<Link2> path, int requireWaveNum) {
//		public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {

		//  ArrayList<Integer>finalResult = new ArrayList<>(); 
	      // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
	       ArrayList<Integer> list=new ArrayList<>();
	         int k=0;
	    //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
	         ArrayList<Integer> avaiIntersectionList;
	         if (path.isEmpty()) {
	             return UNAVAILABLE;
	         } else if (path.size() == 1){

	      
	                  avaiIntersectionList = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

	                   if (avaiIntersectionList.size() < requireWaveNum) {
	                       return UNAVAILABLE;
	                   }
	               } else {
	                   
	                  //  TreeSet<Integer> avaiIntersectionSet = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
	            	   ArrayList<Integer> avaiIntersectionList0 = path.get(0).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

	            	   ArrayList<Integer> avaiIntersectionList1=new  ArrayList<>();
	                   for (int i=1; i<path.size(); i++) {
	                    // TreeSet<Integer> specificEdgeAvailSet = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1tree(requireWaveNum);
	                	    avaiIntersectionList1 = path.get(i).checkAvaiSpectrumBlockInOrderSameIndex1(requireWaveNum);

	                   //    intersection(avaiIntersectionSet, specificEdgeAvailSet);
		                     intersection1(avaiIntersectionList0, avaiIntersectionList1);

	                       // if the size of intersection set is small than requiredSlotNum, return -1.
	                       if (avaiIntersectionList0.size() < requireWaveNum) {
	                           return UNAVAILABLE;
	                       }
	                   }
	                   // transform set to list.
	                   // In TreeSet, over the elements in this set in ascending order.
	                 //  avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
	                   avaiIntersectionList=avaiIntersectionList0;
	               }
	                   
	                   
	                   
	    
			return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	  
	  }*/

  protected int FindPathNoCrosstalkResourcesFirstAvailable6(List<Link2> path, int requireWaveNum) {
//	  // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
      ArrayList<Integer> list=new ArrayList<>();
      int k=0;
 //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
      ArrayList<Integer> avaiIntersectionList;
      if (path.isEmpty()) {
          return UNAVAILABLE;
      } else if (path.size() == 1){
      //    avaiIntersectionList = availableSlotsIndexList(path.get(0));

     	 List<LinkCores> firstSdmEdgeCoreList = path.get(0).getCoreList();
      
           LinkCores sdmCore =firstSdmEdgeCoreList.get(0);


    	                 //  if (finalResult != null) {
                avaiIntersectionList = sdmCore.availableSlotsIndexList1();
              //  avaiIntersectionList = path.get(0).availableSlotsIndexList(finalResult);*/

                if (avaiIntersectionList.size() < requireWaveNum) {
                    return UNAVAILABLE;
                }
            } else {
                
          //     TreeSet<Integer> avaiIntersectionSet = availableSlotsIndexSet(path.get(0));

            //    for (int i=1; i<path.size(); i++) {
                  //  TreeSet<Integer> specificEdgeAvailSet = availableSlotsIndexSet(path.get(i));
                 //   TreeSet<Integer> specificEdgeAvailSet = path.get(i).availableSlotsIndexSet(finalResult);
           List<LinkCores> firstSdmEdgeCoreList = path.get(0).getCoreList();
                
                LinkCores sdmCore =firstSdmEdgeCoreList.get(0);
             //  TreeSet<Integer> avaiIntersectionSet = sdmCore.availableSlotsIndexSet1();
               TreeSet<Integer> avaiIntersectionSet = path.get(0).getCoreList().get(0).availableSlotsIndexSet1();

                for (int i=1; i<path.size(); i++) {
                    TreeSet<Integer> specificEdgeAvailSet = path.get(i).getCoreList().get(0).availableSlotsIndexSet1();
                 //   TreeSet<Integer> specificEdgeAvailSet = path.get(i).availableSlotsIndexSet(finalResult);*/

                    // intersection
                   intersection(avaiIntersectionSet, specificEdgeAvailSet);
                    // if the size of intersection set is small than requiredSlotNum, return -1.
                    if (avaiIntersectionSet.size() < requireWaveNum) {
                        return UNAVAILABLE;
                    }
                }
                // transform set to list.
                // In TreeSet, over the elements in this set in ascending order.
                avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
            }
                
                
                
              //  k=searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
                
                
        //     k= searchLowestAvaiIndex(finalResult, requireWaveNum);
//}

// }
//    }
          //    }
		return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);

}

  protected int FindPathNoCrosstalkResourcesFirstAvailable3(List<Link2> path, int requireWaveNum) {
//		public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {

		//  ArrayList<Integer>finalResult = new ArrayList<>(); 
	      // List<CoreSC> coreSCList = new ArrayList<CoreSC>();
	       ArrayList<Integer> list=new ArrayList<>();
	         int k=0;
	    //     ArrayList<Integer> avaiIntersectionList = new ArrayList<>();;
	         ArrayList<Integer> avaiIntersectionList;
	         if (path.isEmpty()) {
	             return UNAVAILABLE;
	         } else if (path.size() == 1){
             //    avaiIntersectionList = availableSlotsIndexList(path.get(0));

	        	 List<LinkCores> firstSdmEdgeCoreList = path.get(0).getCoreList();
             
                  LinkCores sdmCore =firstSdmEdgeCoreList.get(0);


	       	                 //  if (finalResult != null) {
	                   avaiIntersectionList = sdmCore.availableSlotsIndexList1();
	                 //  avaiIntersectionList = path.get(0).availableSlotsIndexList(finalResult);*/

	                   if (avaiIntersectionList.size() < requireWaveNum) {
	                       return UNAVAILABLE;
	                   }
	               } else {
	                   
	             //     TreeSet<Integer> avaiIntersectionSet = availableSlotsIndexSet(path.get(0));

	               //    for (int i=1; i<path.size(); i++) {
	                     //  TreeSet<Integer> specificEdgeAvailSet = availableSlotsIndexSet(path.get(i));
	                    //   TreeSet<Integer> specificEdgeAvailSet = path.get(i).availableSlotsIndexSet(finalResult);
	              List<LinkCores> firstSdmEdgeCoreList = path.get(0).getCoreList();
	                   
	                   LinkCores sdmCore =firstSdmEdgeCoreList.get(0);
	                //  TreeSet<Integer> avaiIntersectionSet = sdmCore.availableSlotsIndexSet1();
	                  TreeSet<Integer> avaiIntersectionSet = path.get(0).getCoreList().get(0).availableSlotsIndexSet1();

	                   for (int i=1; i<path.size(); i++) {
	                       TreeSet<Integer> specificEdgeAvailSet = path.get(i).getCoreList().get(0).availableSlotsIndexSet1();
	                    //   TreeSet<Integer> specificEdgeAvailSet = path.get(i).availableSlotsIndexSet(finalResult);*/

	                       // intersection
	                      intersection(avaiIntersectionSet, specificEdgeAvailSet);
	                       // if the size of intersection set is small than requiredSlotNum, return -1.
	                       if (avaiIntersectionSet.size() < requireWaveNum) {
	                           return UNAVAILABLE;
	                       }
	                   }
	                   // transform set to list.
	                   // In TreeSet, over the elements in this set in ascending order.
	                   avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
	               }
	                   
	                   
	                   
	                 //  k=searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	                   
	                   
	           //     k= searchLowestAvaiIndex(finalResult, requireWaveNum);
	  //}

	 // }
	   //    }
	             //    }
			return searchLowestAvaiIndex(avaiIntersectionList, requireWaveNum);
	  
	  }
  
  protected int FindPathNoCrosstalkResourcesFirstAvailable2(List<Link2> path, int requiredSlotNum) {
//		public  int FindPathNoCrosstalkResourcesFirstAvailable(List<Link2> path, int requireWaveNum) {
	  ArrayList<Integer> avaiIntersectionList;
      if (path.isEmpty()) {
          return UNAVAILABLE;
      } else if (path.size() == 1){
          avaiIntersectionList = path.get(0).availableSlotsIndexList();
          if (avaiIntersectionList.size() < requiredSlotNum) {
              return UNAVAILABLE;
          }
      } else {
          TreeSet<Integer> avaiIntersectionSet = path.get(0).availableSlotsIndexSet();
          for (int i=1; i<path.size(); i++) {
              TreeSet<Integer> specificEdgeAvailSet = path.get(i).availableSlotsIndexSet();
              // intersection
              intersection(avaiIntersectionSet, specificEdgeAvailSet);
              // if the size of intersection set is small than requiredSlotNum, return -1.
              if (avaiIntersectionSet.size() < requiredSlotNum) {
                  return UNAVAILABLE;
              }
          }
          // transform set to list.
          // In TreeSet, over the elements in this set in ascending order.
          avaiIntersectionList = treesetToArraylist(avaiIntersectionSet);
      }

      return searchLowestAvaiIndex(avaiIntersectionList, requiredSlotNum);
  }
  
  private static int searchLowestAvaiIndex(ArrayList<Integer> list, int requiredNum) {
      if (requiredNum == 1) {
          return list.get(0);
      }
      int startIndex = list.get(0);
      int continuousNum = 1;
      for (int i=1; i<list.size(); i++) {
          if (list.get(i) == startIndex+continuousNum) {
              continuousNum++;
          } else {
              startIndex = list.get(i);
              continuousNum = 1;
          }
          // if find the first spectrum block which is satisfied.
          if (continuousNum == requiredNum) {
              return startIndex;
          }
      }

      return UNAVAILABLE;
  }
  private static Pair<ArrayList<Integer>,  List<CoreSC>> treesetToArraylist1( Pair<TreeSet<Integer>,  List<CoreSC>>vailableList) {
	  TreeSet<Integer> treeSet=vailableList.getFirst(); 
	  List<CoreSC> coreSCList=vailableList.getSecond();

  Iterator<Integer> iterator = treeSet.iterator();
  ArrayList<Integer> list = Lists.newArrayList();
  while (iterator.hasNext()) {
      list.add(iterator.next());
  }
 // return list;
    return new Pair<>(list, coreSCList);

}

      private static ArrayList<Integer> treesetToArraylist(TreeSet<Integer> treeSet) {
          Iterator<Integer> iterator = treeSet.iterator();
          ArrayList<Integer> list = Lists.newArrayList();
          while (iterator.hasNext()) {
              list.add(iterator.next());
          }
          return list;
      }

      private static void intersection(TreeSet<Integer> original, TreeSet<Integer> compared) {
          ArrayList<Integer> duplicate = original.stream().filter(index -> !compared.contains(index)).collect(Collectors.toCollection(ArrayList::new));
          duplicate.forEach(original::remove);
      }
      private static void intersection1(ArrayList<Integer> original, ArrayList<Integer> compared) {
          ArrayList<Integer> duplicate = original.stream().filter(index -> !compared.contains(index)).collect(Collectors.toCollection(ArrayList::new));
          duplicate.forEach(original::remove);
      }

      
    /**
	@Override
    protected boolean handle(LinkCores worstCore , List<Integer> occupiedByConn, int connectionId ,
                             Graph originGraph, int eventIndex, long startTime, List<Timestamp> orderedList){

    	//First you need to define two constraints:
            // 1. The spectrum allocation for the service must be continuous, that is, if a service requires 2 spectrum resources, only consecutive numbers such as 1, 2, and 3 can be allocated.
            // 2. For the spectrum movement of a spectrum resource occupied by a service within a Core, the wavelength consistency of the entire path of the service must be guaranteed. ?
        int occupiedByConnNum = occupiedByConn.size();
        double oldWorstSc = calculateCoreSC(worstCore);

        try {
        	// Get all edges on the Path, and the specific SdmCore list on each side
         //   List<CoreSC> pathCoreSC= eventInfo.get(connectionId).getKey();
            List<CoreSC> pathCoreSC= eventInfo.get(connectionId).getFirst();
            List<Double> oldScValueList = new ArrayList<Double>();
            for (CoreSC coreSC : pathCoreSC){
                if (coreSC.getCoreIndex() != 6) {
                    LinkImplementation edge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
                    LinkCores sdmCore = edge.getCoreList().get(coreSC.getCoreIndex());
                    oldScValueList.add(calculateCoreSC(sdmCore));
                }
            }
            ////////////////////////////
           
            ////////////////////////////
            
            
            // Get a List of spectrum blocks on the worstCore that provide enough transfer resources, where the spectrum block is specified with List<SdmCore>
            // The available spectrum block adjacent to occupiedByConn gives occupiedByConn the possibility of smooth movement, which should be considered
            List<List<Integer>> avaiBlocksForSpecificConn = getWorstCoreAvaiBlock(worstCore,occupiedByConnNum);
                  // If there are available resources that can be moved

            if (avaiBlocksForSpecificConn.size() >= 1) {
            	// traverse available resources
            	for (int j=0; j<avaiBlocksForSpecificConn.size(); j++) {
                    List<Integer> specificBlock = avaiBlocksForSpecificConn.get(j);
                 
                 // First transfer the resource from the occupiedByConn to the specificBlock of the same Core, in addition to determining the specified spectrum segment on the current core.
                    // Also look at the entire Path of the spectrum segment is available, the consistency is available to move, and the following process
                    if (moveConnInCore(occupiedByConn, specificBlock, pathCoreSC, originGraph)) {
                       
                    	// If the move is successful, pathCoreSC will recalculate when comparing, but it will not be moved for the time being.
                        // If the core result on the entire Path after the transfer is greater than the threshold, then the transfer is valid.
                        if (allPathCoreScOverThres(pathCoreSC, oldScValueList, originGraph)) {
                        	// Will the test cause crosstalk, plus whether there is crosstalk in the core for the consistent spectrum segment on the entire Path?

                            if (!checkIfPathCrosstalk(specificBlock, pathCoreSC, originGraph)) {
                              
                            	// If there is no crosstalk, it means the adjustment is successful.
                                // There is a problem here. If the adjustment is successful, the break should jump out of the traversal of connections instead of just jumping out.
                                // Traversal of other available cores?
                                // Compliant with refactoring, the serviceId in the band of the sink core is also moved (previous wavelength occupation has been modified), and eventinfo is modified.

                                moveScConnectionId(occupiedByConn, specificBlock, connectionId, pathCoreSC, originGraph);
                                Calendar endTime = orderedList.get(0).getTime();
                                addServiceShiftTime(connectionId,endTime);
                             //   dataCollection.addSpectrumSuccessShiftNum();
                          //      dataCollection.addReconstructTime(eventIndex, startTime, endTime);
                                log.info("The CasdDsSc algorithm was successfully reconstructed! The moving business is{}。", connectionId);
                                return true;
                            } else {
                               
                            	// If crosstalk occurs, this adjustment fails
                                // perform a rollback operation

                                if (!moveConnInCore(specificBlock, occupiedByConn, pathCoreSC,originGraph)) {
                                	// If the rollback fails, the program can be terminated.
                                    throw new RollbackException("回滚失败！");
                                }
                            }
                        } else {
                        	// If the new SC after modification cannot meet the threshold limit, it means that the adjustment fails, and the spectrum transfer situation needs to be rolled back.
                            if (!moveConnInCore(specificBlock, occupiedByConn, pathCoreSC, originGraph)) {
                            	// If the rollback fails, the program can be terminated.
                                throw new RollbackException("回滚失败！");
                            }
                        }
                    } else {
                    	// do nothing, then find the next spectrum block
                    }
                }
            } else {
                return false;
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        return false;
    }
	*/
		  
    /**
     *
     *   Get a List of spectrum blocks on the worstCore that provide sufficient transfer resources, where the spectrum block is specified with List<SdmCore> - the test is successful
      * @param occupiedByConnNum The wavelength resource occupied by the connection
      * @return other available spectrum segments on the core
     */
	protected List<List<Integer>> getWorstCoreAvaiBlock(LinkCores worstCore, int occupiedByConnNum){

        List<List<Integer>> availCoreBlock = new ArrayList<List<Integer>>();
        List<FrequencySlots> worstCoreWaveList = worstCore.getWavelength();
     // traverse the wavelength of 1-49, while traversing the length of 0-Num, the number follows the wavelength number. If consecutive Num wavelength numbers are available, add Block.
        //If it is not continuous, it will traverse the wavelength from the next wavelength number. Every time it is traversed, it will re-empt the count and the new new list.
        for (int i = 0;i < worstCoreWaveList.size()-occupiedByConnNum+1; i++){
            int count = 0;
            List<Integer> availSpectrumSlots = new ArrayList<Integer>();
            for (int j = i; j < i+occupiedByConnNum; j++){
                if (!worstCoreWaveList.get(j).getIsOccupied()){
                    count = count +1;
                    availSpectrumSlots.add(worstCoreWaveList.get(j).getId());
                }
                else {
                    break;
                }
            }
            if (count == occupiedByConnNum){
                availCoreBlock.add(availSpectrumSlots);
            }
        }
        return availCoreBlock;
    }

    /**
     * 
     * To move the specified spectrum segment on the Core to other available spectrum segments in the same core, you first need to determine the specified spectrum segment on the current core.
      * Also depends on whether the spectrum segment of the entire Path is available. If the consistency is available, move it and return true.
      * @param occupiedByConn specified spectrum segment to be moved
      * @param specificBlock ith available spectrum segment
      * @param coreScListPath The list of cores occupied by each edge of the entire Path
      * @return If the entire Path specified spectrum segment is available, move, move successfully, return true; unavailable, return false directly, traverse the next block
     */
  /**  private boolean moveConnInCore(List<Integer> occupiedByConn, List<Integer> specificBlock
            ,List<CoreSC> coreScListPath, Graph originGraph){

        int countAvailCoreNum = 0;
        for (CoreSC coreSC : coreScListPath){
            int countOccuNum = 0;
            LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
            List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
            for (int i = 0; i< specificBlock.size(); i++){
                if(!coreWavelength.get(specificBlock.get(i)).getIsOccupied()){
                    countOccuNum = countOccuNum + 1;
                }
            }
            if (countOccuNum == specificBlock.size()){
                countAvailCoreNum = countAvailCoreNum + 1;
            }
            else {
                return false;
            }
        }

        if (countAvailCoreNum == coreScListPath.size()){
            for (CoreSC coreSC : coreScListPath) {
             LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
                LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
                List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
                for (int i = 0; i < occupiedByConn.size(); i++) {
                    coreWavelength.get(occupiedByConn.get(i)).setOccupiedServiceIndex(1);
                }
                for (int j = 0; j < specificBlock.size(); j++) {
                    coreWavelength.get(specificBlock.get(j)).setOccupiedServiceIndex(0);
                }
                coreSC.setSc(calculateCoreSC(sdmCore));
            }
            return true;
        }else {
            return false;
        }
    }*/

    /**
     * checking if the spectrum compactness of the cores in the path exceed threshold
      * @return exceeds the threshold, exceeds the return true, no more than the need to traverse the next block

     */
/*   public boolean allPathCoreScOverThres(List<CoreSC> pathCoreSC, List<Double> scValueList, Graph originGraph){
      //  public boolean allPathCoreScOverThres(List<CoreSC> pathCoreSC, double scValueList, Graph originGraph){

    	//The SC value of all cores on the entire Path is adjusted to be higher than the previous SC value, then it returns true.
        // Note that the pathCoreSC has been recalculated here, first move it, wait for it to move again.

        int conut = 0;
        for (int i = 0; i <  pathCoreSC.size(); i++){
        	LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(pathCoreSC.get(i).getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(pathCoreSC.get(i).getCoreIndex());
            double perSc = calculateCoreSC(sdmCore);
            if (perSc > scValueList.get(i)){
             //   if (perSc > scValueList){
                conut++;
            }
        }
        if (conut == pathCoreSC.size()){
            return true;
        }else {
            return false;
        }
    }*/

    /**
     * Checking whether there is  crosstalk in the new spectrum slot and on the consistent spectrum segment in the entire path
      * 
     */
    private boolean checkIfPathCrosstalk(List<Integer> specificBlock, List<CoreSC> coreScListPath,
                                         Graph originGraph){
    	// Record the number of edges that satisfy the crosstalk condition, and compare it with the total number of edges.

        int countNonCrosstalkCore = 0;

        for (CoreSC coreSC : coreScListPath){
        	// Side information, nuclear information, adjacent nuclear information

        	LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
            List<LinkCores> adjacentCoreList = sdmCore.getAdjacentCores();

         // Traversing the newly occupied spectrum segment of the sink core, whether its neighboring two cores are equally occupied, and no crosstalk
            int countSpecOccu = 0;
            for (int i = 0; i < specificBlock.size(); i++) {
                int index = specificBlock.get(i);
             // traverse all neighboring cores of the core
                int countAdjCoreOccu = 0;
                for (LinkCores adjacentCore : adjacentCoreList) {
                    if (adjacentCore.getWavelength().get(index).getIsOccupied()){
                        countAdjCoreOccu++;
                    }
                }
             // Remove itself, the total number of adjacent cores is only three, countAdjCoreOccu counts the number of adjacent cores
              //TODO modified the crosstalk condition
                if (countAdjCoreOccu >= adjacentCoreList.size()){
                	// greater than or equal to 3 indicates crosstalk
                    return true;
                }else {
                	// Explain that the indexSlot has no crosstalk, countSpecOccu plus one
                    countSpecOccu++;
                }
            }

            if (countSpecOccu == specificBlock.size()){
                countNonCrosstalkCore++;
            }
        }

            //The spectrum is the same no more than two hops. The core has no crosstalk. Then it is judged that the Path is next to the Core. All the Cores on the Path have no crosstalk.
        //All Cores on Path have no crosstalk, success, return false without crosstalk
        if (countNonCrosstalkCore == coreScListPath.size()){
            return false;
        }else {
            return true;
        }

    }
	}

    /**
     * 
     * Move the connectionId of the specified band on the entire Path to the path and modify the eventInfo.
      * @param occupiedByConn specified spectrum segment to be moved
      * @param specificBlock ith available spectrum segment
      * @param coreScListPath The list of cores occupied by each edge of the entire Path

     */
/*    private void moveScConnectionId(List<Integer> occupiedByConn, List<Integer> specificBlock, int connectionId,
                                    List<CoreSC> coreScListPath, Graph originGraph) {
        if (occupiedByConn.size() != specificBlock.size()) {
            throw new RuntimeException("when the same core moves, the source and sink spectrum segments are different in length!"); //  W
        }

        //搬移connectionId
        for (CoreSC coreSC : coreScListPath){
            LinkImplementation sdmEdge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = sdmEdge.getCoreList().get(coreSC.getCoreIndex());
            List<FrequencySlots> coreWavelength = sdmCore.getWavelength();
            for (int i = 0;i < occupiedByConn.size(); i++){
                coreWavelength.get(occupiedByConn.get(i)).setwaveServiceId(-1);
            }
            for (int j = 0; j < specificBlock.size(); j++){
                coreWavelength.get(specificBlock.get(j)).setwaveServiceId(connectionId);
            }
        }
     // Modify eventInfo, only modify List<Integer>, the spectrum segment corresponding to connectionId has changed.

       // List<Integer> spectrumSlotsList = eventInfo.get(connectionId).getValue();
        List<Integer> spectrumSlotsList = eventInfo.get(connectionId).getSecond();
        for (int k = 0; k < specificBlock.size(); k++){
            spectrumSlotsList.set(k, specificBlock.get(k));
        }
      //  List<CoreSC> coreSCList = eventInfo.get(connectionId).getKey();
        List<CoreSC> coreSCList = eventInfo.get(connectionId).getFirst();
        for (CoreSC coreSC : coreSCList){
        	LinkImplementation edge = (LinkImplementation) originGraph.getEdges().get(coreSC.getEdgeId());
            LinkCores sdmCore = edge.getCoreList().get(coreSC.getCoreIndex());
            coreSC.setSc(calculateCoreSC(sdmCore));
        }
    }

}
*/