package Network;
import static com.google.common.base.Preconditions.checkNotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;

import org.jgrapht.alg.util.Pair;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import Network.Link.LinkBuilder;
import Network.LinkImplementation.LinkStateBuilder;
import RSAAgorithm.BaseAlgorithm;
import Utility.Error;
import Utility.LinkType;
import Utility.WeightType;



public class Link2 extends DefaultWeightedEdge implements Serializable{
    private static final Logger log = LoggerFactory.getLogger(Link2.class);

	private List<LinkCores> coreList  = new ArrayList<LinkCores>(7);
    private ArrayList<FrequencySlots> slots;
	private Node2 src;
	private Node2 dst;
	private LinkStatus status;
	private int id;
	private Link2 Link2;
	private int n;

    Modulation modulation;
	public int metric = Integer.MAX_VALUE;  
//	 public int getEdgeId() {
	//        return id;
	  //  }
	 public Link2 getEdgeId() {
	        return Link2;
	    }

    public ArrayList<FrequencySlots> getSlots() {
        return slots;
    }

    public Node2 getSource() {
        return (Node2) super.getSource();
    }

    public Node2 getDestination() {
        return (Node2) super.getTarget();
    }
    public List<LinkCores> getCoreList() {
        checkNotNull(coreList, "core in graph should not be null.");
        return coreList;
    }
    public void setModulationIfBetter(Modulation modulation, int metric) {
    	  //      System.out.println(metric+"****"+this.metric+"****" +modulation.toString());

    			if (metric < this.metric) {
    				this.metric = metric;
    				this.modulation = modulation;
    			}
    		}
    		
    		public void setModulation(Modulation modulation, int metric) {

    			this.metric = metric;
    			this.modulation = modulation;
    		}
    		
    		public Modulation getModulation() {
    			return modulation;
    		}
    public TreeSet<Integer> availableSlotsIndexSet() {
        TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();

        for (FrequencySlots slot : slots) {
            if (!slot.getIsOccupied()) {
                availableSlotsIndex.add(slot.getSlotIndex());
            }
        }
        return availableSlotsIndex;
    }

    /**
     * get the array list of available slots index by ascend.
     * @return set
     */
    public ArrayList<Integer> availableSlotsIndexList() {
        ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();
        for (FrequencySlots slot : slots) {
            if (!slot.getIsOccupied()) {
                availableSlotsIndex.add(slot.getSlotIndex());
            }
        }
        return availableSlotsIndex;
    }
    public ArrayList<Integer> availableSlotsIndexList(List<CoreSC> maxCoreScPerEdge,ArrayList<Integer>noCrosstalkslots) {
        ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();
	 for (int j=0; j<maxCoreScPerEdge.size(); j++) {

       LinkCores sdmcores= coreList.get(maxCoreScPerEdge.get(j).getCoreIndex());
       //  for (LinkCores sdmcores : coreList) {

			 for (int i=0; i<noCrosstalkslots.size(); i++) {

        	List<FrequencySlots> wavelength=sdmcores.getWavelength();
        	
           // if (!slot.getIsOccupied()) {
        if (!wavelength.get(i).getIsOccupied()) {

                availableSlotsIndex.add(i);
            }
        }
        }
        return availableSlotsIndex;
    }
   // public TreeSet<Integer> availableSlotsIndexSet(ArrayList<Integer>noCrosstalkslots) {
       public TreeSet<Integer> availableSlotsIndexSet(List<CoreSC> maxCoreScPerEdge,ArrayList<Integer>noCrosstalkslots) {

    
        TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();
       for (int j=0; j<maxCoreScPerEdge.size(); j++) {

            LinkCores sdmcores= coreList.get(maxCoreScPerEdge.get(j).getCoreIndex());


     //   for (LinkCores sdmcores : coreList) {
        	 for (int i=0; i<noCrosstalkslots.size(); i++) {

             	List<FrequencySlots> wavelength=sdmcores.getWavelength();
             	
                // if (!slot.getIsOccupied()) {
             if (!wavelength.get(i).getIsOccupied()) {

                     availableSlotsIndex.add(i);
                 }
        }
        }
        return availableSlotsIndex;
    }

       public int occupiedSlotsNum(List<CoreSC> maxCoreScPerEdge,ArrayList<Integer>noCrosstalkslots) {
           int count = 0;
           for (int j=0; j<maxCoreScPerEdge.size(); j++) {

               LinkCores sdmcores= coreList.get(maxCoreScPerEdge.get(j).getCoreIndex());


        //   for (LinkCores sdmcores : coreList) {
           	 for (int i=0; i<noCrosstalkslots.size(); i++) {

                	List<FrequencySlots> wavelength=sdmcores.getWavelength();
                	
                   // if (!slot.getIsOccupied()) {
                if (wavelength.get(i).getIsOccupied()) {
                   count++;
               }
           	 }
           }
           return count;
       }
       public int occupiedSlotsNum() {
           int count = 0;
           for(FrequencySlots slot : slots) {
               if (slot.getIsOccupied()) {
                   count++;
               }
           }
           return count;
       }
       public int occupiedSlotsNum1() {
           int count = 0;
       	 for (int j=0; j<coreList.size(); j++) {
        //   for (LinkCores sdmcores : coreList) {
       		LinkCores Sdmcore=coreList.get(j);
               List<FrequencySlots> wavelengths = Sdmcore.getWavelength();

               if (wavelengths.get(0).getIsOccupied()) {
                   count++;
               }
           }
           return count;
       }
       public int occupiedSlotsNum2() {
           int count = 0;
       	 for (int j=0; j<coreList.size(); j++) {
        //   for (LinkCores sdmcores : coreList) {
       		LinkCores Sdmcore=coreList.get(j);
              // List<EonSlot> wavelengths = Sdmcore.getWavelength();
       		count=Sdmcore.occupiedSlotsNum();
            //   if (wavelengths.get(0).isOccupied()) {
            //       count++;
             //  }
           }
           return count;
       }

       public ArrayList<Integer> availableSlotsIndexList1() {
           ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

         	 for (int j=0; j<coreList.size()-1; j++) {
          //   for (LinkCores sdmcores : coreList) {
         		LinkCores sdmcores=coreList.get(j);

           	List<FrequencySlots> wavelength=sdmcores.getWavelength();
   			 for (int i=0; i<wavelength.size(); i++) {

           	
              // if (!slot.getIsOccupied()) {
           if (!wavelength.get(i).getIsOccupied()) {

                   availableSlotsIndex.add(i);
               }
           }
           }
           return availableSlotsIndex;
       }
      // public TreeSet<Integer> availableSlotsIndexSet(ArrayList<Integer>noCrosstalkslots) {
          public TreeSet<Integer> availableSlotsIndexSet1() {

       
           TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();
                  //   LinkCores sdmcores= coreList.get);

      	 for (int j=0; j<coreList.size()-1; j++) {
       //   for (LinkCores sdmcores : coreList) {
      		LinkCores sdmcores=coreList.get(j);
                	List<FrequencySlots> wavelength=sdmcores.getWavelength();
      			 for (int i=0; i<wavelength.size(); i++) {

                	
                   // if (!slot.getIsOccupied()) {
                if (!wavelength.get(i).getIsOccupied()) {

                        availableSlotsIndex.add(i);
                    }
           }
      			 
           }
           return availableSlotsIndex;
       }

     //     public ArrayList<Integer> checkAvaiSpectrumBlockInOrderSameIndex1(  int requiredWaveNum) {
              public  Pair<ArrayList<Integer>,  List<CoreSC>> checkAvaiSpectrumBlockInOrderSameIndex1(  int requiredWaveNum) {

                 ArrayList<Integer> noCrosstalkSpectrumBlock=Lists.newArrayList(); ;
       	      List<CoreSC> coreSCList = new ArrayList<CoreSC>();

         //    ArrayList<Integer> avaiSpectrumBlock=Lists.newArrayList(); ;
        for (int j=0; j<coreList.size()-1; j++) {
     //       for (int j=0; j<coreList.size(); j++) {

            //	for (LinkCores sdmcores: coreList) {
        	
int totalSumCore, c,nextCore, totolCoreNum;
totolCoreNum=7;
totalSumCore=28;
n=totolCoreNum+1;
   nextCore=(2*totalSumCore/n)+j;
   
 
   
        	    //      for (LinkCores sdmcores : coreList) {
        	    	LinkCores sdmcores=coreList.get(j);
        	    //  		LinkCores sdmcores=coreList.get(nextCore-1);

        	    	
        	    	   
            //     for (CoreSC coreSC:coreSCList) {
             //    LinkCores sdmCore = edge.getCoreList().get(coreSC.getCoreIndex());


                         if (sdmcores != null){
              //    first = findAvaiSpectrumBlocksInOrder1(sdmCore.getWavelength() , requiredWaveNum);
                        	  ArrayList<Integer> avaiSpectrumBlock=sdmcores.availableSlotsIndexList1();
        //return first;
                      if (avaiSpectrumBlock != null) {
                    	  CoreSC coreSC = calculateCoreSc( sdmcores, avaiSpectrumBlock, requiredWaveNum);
              	    	coreSCList.add(coreSC);
              	    	
                    	   noCrosstalkSpectrumBlock =
                   	                     noCrossTalkFilterSameIndex1(sdmcores, avaiSpectrumBlock, requiredWaveNum);
                      //  return null;
                      }

                   }
                   }
   return new Pair<>(noCrosstalkSpectrumBlock, coreSCList);
        	}
          private  ArrayList<Integer> noCrossTalkFilterSameIndex1(LinkCores comparedCore,
                  ArrayList<Integer> avaiSpectrumBlock, int requiredWaveNum) {

        	// Find the spectrum block that will not cause crosstalk first.
        	//List<List<Integer>> tmp = avaiSpectrumBlock;
          	ArrayList<Integer> tmp = Lists.newArrayList();
       //   for (CoreSC coreSC : maxCoreScPerEdge) {
          	// Find a spectrum block on the Core that does not cause crosstalk
          	tmp = noCrossTalkFilterFurtherSameIndex2( comparedCore, avaiSpectrumBlock, requiredWaveNum);
            //  if (tmp == null || tmp.isEmpty()) {
            //      return null;
            //  }
        //  }

        // Determine the spectrum combination of the filtered spectrum blocks
          return tmp;
        }
        	private ArrayList<Integer> noCrossTalkFilterFurtherSameIndex2( LinkCores comparedCore, ArrayList<Integer> avaiSpectrumBlock, int requiredWaveNum) {

        		//LinkImplementation sdmEdge = (LinkImplementation) graph.getEdges().get(coreSC.getEdgeId());
                //Link2 sdmEdge =  graph.getEdge(src, dst);

                //LinkCores comparedCore = mapToCore(coreSC);
                        ArrayList<Integer> availableSpectrumBlocks = Lists.newArrayList();

                	//	 for (int j=0; j<coreList.size()-1; j++) {
                  	       //   for (LinkCores sdmcores : coreList) {
                  	    //  		LinkCores sdmcores=coreList.get(j);
             //   LinkCores comparedCore = edge.getCoreList().get(coreSC.getCoreIndex());
              //  LinkCores comparedCore = coreList.get(j);
             //   LinkCores comparedCore = coreList.get(0);

                

                List<FrequencySlots> wavelengths = comparedCore.getWavelength();

                List<ArrayList<Integer>> rtn = new ArrayList<ArrayList<Integer>>();
                ArrayList<Integer> rtn1 = Lists.newArrayList();


                //The parameter type List<List<Integer>> is not set properly, but it has been difficult to change.
                //int waveInCoreNum = edge.getCoreList().get(0).getWavelength().size();
                //This variable occupiedTime is the dimensionality reduction of the avaiSpectrumBlock.
             //   for (List<Integer> m : avaiSpectrumBlock) {
            //	for (int j=1; j<avaiSpectrumBlock.size(); j++) {

                      for (int n : avaiSpectrumBlock) {
                    	  availableSpectrumBlocks.add(n);
                //     occupiedTime.add(j);

                          }
                //}

                            if (comparedCore != null){
                //traversing from big to small
                    for (int i=availableSpectrumBlocks.size()-2; i>=0; i--) {
                     int index = availableSpectrumBlocks.get(i);
                          int count = 0;
                //Traverse the adjacent Core
                    for (LinkCores adjCore : comparedCore.getAdjacentCores()) {
             if (adjCore.getWavelength().get(index).getIsOccupied()) {
                //If the previous count value is 1, this time, the spectrum resources of the adjacent Core are occupied. Therefore, crosstalk is generated and the spectrum is deleted.
                //TODO modified the crosstalk condition
              //   availableSpectrumBlocks.remove(i);

                /**    if (count == 6) {
                        availableSpectrumBlocks.remove(i);
                //After deleting, there is no need to traverse here, just jump out of the innermost for loop and start looking for the next for loop.
                        break;
                      } else {
                        count++;
                   }*/
                      }
                }
               }
                //The result obtained in the previous step indicates that the available spectrum does not generate crosstalk.
                //This step sorts the results of the previous step into the form of available spectrum segments, ie List<List<Integer>>, and removes the spectrum segments that do not meet the length requirements.
                if (!availableSpectrumBlocks.isEmpty()) {
               // return null;
              //  } else {
                	for (int i=0;i<availableSpectrumBlocks.size(); i--) {
                //    	for (int i: availableSpectrumBlocks) {


                	if (availableSpectrumBlocks.size() >= requiredWaveNum) {
                	rtn1.add(availableSpectrumBlocks.get(i));
                	//	rtn1.add(i);

                		}
                	//}

              return availableSpectrumBlocks;
              //  return rtn1;
                
                


               // }
                }
                }/**else {
                throw new RuntimeException("The mapToCore method does not find the corresponding core in the graph！");
                }*/
              //  return availableSpectrumBlocks;
               }
               return availableSpectrumBlocks;

        	//		return rtn1;
                
        	} 	
    //      public TreeSet<Integer> checkAvaiSpectrumBlockInOrderSameIndex1tree( int requiredWaveNum) {
        	  public  Pair<TreeSet<Integer>,  List<CoreSC>> checkAvaiSpectrumBlockInOrderSameIndex1tree(  int requiredWaveNum) {

        	      List<CoreSC> coreSCList = new ArrayList<CoreSC>();
              TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();
              ArrayList<Integer> noCrosstalkSpectrumBlock=Lists.newArrayList(); ;

              //    ArrayList<Integer> avaiSpectrumBlock=Lists.newArrayList(); ;
              for (int j=0; j<coreList.size()-1; j++) {
             //     for (int j=0; j<coreList.size(); j++) {

            	  
              	
            	  int totalSumCore, c,nextCore, totolCoreNum;
            	  totolCoreNum=7;
            	  totalSumCore=28;
            	  c=totolCoreNum+1;
            	     nextCore=2*totalSumCore/c+j;
            	          	
          //   	         for (LinkCores sdmcores : coreList) {
             	      		LinkCores sdmcores=coreList.get(j);
        
             	      		///////////////////////////////

                              if (sdmcores != null){
                   //    first = findAvaiSpectrumBlocksInOrder1(sdmCore.getWavelength() , requiredWaveNum);
                             	  ArrayList<Integer> avaiSpectrumBlock=sdmcores.availableSlotsIndexList1();
                             	  
             //return first;
                           if (avaiSpectrumBlock != null) {
                         	  CoreSC coreSC = calculateCoreSc( sdmcores, avaiSpectrumBlock, requiredWaveNum);
                    	    	coreSCList.add(coreSC);

                         	   noCrosstalkSpectrumBlock =
                        	                     noCrossTalkFilterSameIndex1(sdmcores, avaiSpectrumBlock, requiredWaveNum);
                               if (noCrosstalkSpectrumBlock != null) {
                           //  return null;
                    //          		availableSlotsIndex.add(noCrosstalkSpectrumBlock.get(0));

                           // for (int i=0; i<noCrosstalkSpectrumBlock.size(); i++) {
                            //   		availableSlotsIndex.add(i);
                              // 		availableSlotsIndex.add(i);
                            for (int n : noCrosstalkSpectrumBlock) {
                             		availableSlotsIndex.add(n);
                               		

                      }              //  
                               }    	
                           }
                              }
             	 }
     return new Pair<>(availableSlotsIndex, coreSCList);
        	}
          

          private static CoreSC calculateCoreSc( LinkCores core,  ArrayList<Integer> avaiSpectrumBlock, int requiredWaveNum) {

  	    	// Construct an instance of CoreSC
  	    	CoreSC rtn = new CoreSC();
  	       // rtn.setEdgeId2(edgeId);
  	        rtn.setCoreIndex(core.getId());

  	        // Calculate the SC value
  	        double maxOccupiedSlotNum = -1;
  	        double minOccupiedSlotNum = -1;
  	        double occupiedSlotTotalNum = 0;
  	        double availSpectrumBlockTotalNum;
  	        boolean isFirstOccupied = true;
  	        double sc;

  	        for (int i=0; i<core.getWavelength().size(); i++) {
  	            FrequencySlots wavelength = core.getWavelength().get(i);
  	         // If the spectrum is occupied
  	            if (wavelength.getIsOccupied()) {
  	            	// If it is the first time to find the occupied spectrum
  	                if (isFirstOccupied) {
  	                    minOccupiedSlotNum = i;
  	                    occupiedSlotTotalNum++;
  	                    isFirstOccupied = false;
  	                } else {
  	                    maxOccupiedSlotNum = i;
  	                    occupiedSlotTotalNum++;
  	                }
  	            }
  	        }

  	     // If all spectrum resources are not occupied, the SC value is infinite
  	        if (maxOccupiedSlotNum == -1) {
  	            sc = Double.POSITIVE_INFINITY;
  	            rtn.setSc(sc);
  	            return rtn;
  	        }
  	        // If all spectrum resources are occupied, the SC value is 0.
  	        if (occupiedSlotTotalNum == core.getWavelength().size()) {
  	            sc = 0d;
  	            rtn.setSc(sc);
  	            return rtn;
  	        }

  	     // If it is not the above two extreme cases, the search for the occupied spectrum segment does not necessarily have to satisfy the length. The following method needs to be modified.
  	     // This method is not suitable for findAvaiSpectrumBlocksInOrder
  	     //   List<ArrayList<Integer>> avaiSpectrumBlocks = findAvaiSpectrumBlocksInOrder(core.getWavelength(),requiredWaveNum);
  	        if (avaiSpectrumBlock == null) {
  	        	// Not necessarily, there may not be two extreme cases, the middle is occupied but the length of the request is not satisfied, so the latter is correct.
  	            log.info("No spectrum segment available");
  	        } else {
  	            availSpectrumBlockTotalNum = avaiSpectrumBlock.size();
  	            sc = (maxOccupiedSlotNum - minOccupiedSlotNum + 1) / occupiedSlotTotalNum *
  	                    (core.getWavelength().size() - occupiedSlotTotalNum) / availSpectrumBlockTotalNum;
  	            rtn.setSc(sc);
  	        }
  	        return rtn;
  	    }
  
    public Link2() {
    	
    	  //    	TopologyquantifiedDetails net = params.networks.get(i);
    	      //  TopologyParameters params = TopologySetup.getInstance().TopologyParams;


    	      //  slots = Lists.newArrayListWithCapacity(TopologyParameters.getInstance().slotNum);
    /**	        slots = Lists.newArrayListWithCapacity(10);

         for (int i=0;i<10;i++) {
    	            // slot index starts from 1.
    	            slots.add(new FrequencySlots(i+1));
    	        }*/
    	        coreList = new ArrayList<LinkCores>(7);
    	        for (int i = 0; i < 7; i++) {
    	            coreList.add(new LinkCores(i));
    	        }
    	        initAdjCores(); 	        
    	        
    	    }



public void setCoreList(List<LinkCores> coreList) {
this.coreList = coreList;
}

public void initAdjCores() {

coreList.get(0).addAdjCores(coreList.get(1));
coreList.get(0).addAdjCores(coreList.get(5));
coreList.get(0).addAdjCores(coreList.get(6));

coreList.get(1).addAdjCores(coreList.get(0));
coreList.get(1).addAdjCores(coreList.get(2));
coreList.get(1).addAdjCores(coreList.get(6));

coreList.get(2).addAdjCores(coreList.get(1));
coreList.get(2).addAdjCores(coreList.get(3));
coreList.get(2).addAdjCores(coreList.get(6));

coreList.get(3).addAdjCores(coreList.get(2));
coreList.get(3).addAdjCores(coreList.get(4));
coreList.get(3).addAdjCores(coreList.get(6));

coreList.get(4).addAdjCores(coreList.get(3));
coreList.get(4).addAdjCores(coreList.get(5));
coreList.get(4).addAdjCores(coreList.get(6));

coreList.get(5).addAdjCores(coreList.get(0));
coreList.get(5).addAdjCores(coreList.get(4));
coreList.get(5).addAdjCores(coreList.get(6));

coreList.get(6).addAdjCores(coreList.get(0));
coreList.get(6).addAdjCores(coreList.get(1));
coreList.get(6).addAdjCores(coreList.get(2));
coreList.get(6).addAdjCores(coreList.get(3));
coreList.get(6).addAdjCores(coreList.get(4));
coreList.get(6).addAdjCores(coreList.get(5));

/**
coreList.get(0).addAdjCores(coreList.get(1));
coreList.get(0).addAdjCores(coreList.get(5));
coreList.get(0).addAdjCores(coreList.get(6));

coreList.get(1).addAdjCores(coreList.get(0));
coreList.get(1).addAdjCores(coreList.get(2));
coreList.get(1).addAdjCores(coreList.get(6));

coreList.get(2).addAdjCores(coreList.get(1));
coreList.get(2).addAdjCores(coreList.get(3));
coreList.get(2).addAdjCores(coreList.get(6));

coreList.get(3).addAdjCores(coreList.get(2));
coreList.get(3).addAdjCores(coreList.get(4));
coreList.get(3).addAdjCores(coreList.get(6));

coreList.get(4).addAdjCores(coreList.get(3));
coreList.get(4).addAdjCores(coreList.get(5));
coreList.get(4).addAdjCores(coreList.get(6));

coreList.get(5).addAdjCores(coreList.get(0));
coreList.get(5).addAdjCores(coreList.get(4));
coreList.get(5).addAdjCores(coreList.get(6));

coreList.get(6).addAdjCores(coreList.get(0));
coreList.get(6).addAdjCores(coreList.get(1));
coreList.get(6).addAdjCores(coreList.get(2));
coreList.get(6).addAdjCores(coreList.get(3));
coreList.get(6).addAdjCores(coreList.get(4));
coreList.get(6).addAdjCores(coreList.get(5));
////////////////////////////////////////////////
/*
coreList.get(0).addNonAdjCores(coreList.get(2));
coreList.get(0).addNonAdjCores(coreList.get(4));
coreList.get(0).addNonAdjCores(coreList.get(3));

coreList.get(1).addNonAdjCores(coreList.get(5));
coreList.get(1).addNonAdjCores(coreList.get(3));
coreList.get(1).addNonAdjCores(coreList.get(4));

coreList.get(2).addNonAdjCores(coreList.get(0));
coreList.get(2).addNonAdjCores(coreList.get(4));
coreList.get(2).addNonAdjCores(coreList.get(5));

coreList.get(3).addNonAdjCores(coreList.get(0));
coreList.get(3).addNonAdjCores(coreList.get(1));
coreList.get(3).addNonAdjCores(coreList.get(5));

coreList.get(4).addNonAdjCores(coreList.get(0));
coreList.get(4).addNonAdjCores(coreList.get(1));
coreList.get(4).addNonAdjCores(coreList.get(2));

coreList.get(5).addNonAdjCores(coreList.get(1));
coreList.get(5).addNonAdjCores(coreList.get(2));
coreList.get(5).addNonAdjCores(coreList.get(3));
coreList.get(6).addAdjCores(coreList.get(0));
coreList.get(6).addAdjCores(coreList.get(1));
coreList.get(6).addAdjCores(coreList.get(2));
coreList.get(6).addAdjCores(coreList.get(3));
coreList.get(6).addAdjCores(coreList.get(4));
coreList.get(6).addAdjCores(coreList.get(5));*/

}



@Override
public String toString() {
    //return Objects.toStringHelper(this)
    return MoreObjects.toStringHelper(this)

            .add("source", getSource())
            .add("destination", getTarget())
            .toString();
}

//public Link2 get(int edgeId1) {
	// TODO Auto-generated method stub
//	return null;
//}
}
