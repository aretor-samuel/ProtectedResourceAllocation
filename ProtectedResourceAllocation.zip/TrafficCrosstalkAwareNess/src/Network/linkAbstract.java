package Network;

package Network;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import org.jgrapht.graph.DefaultWeightedEdge;

//import com.google.common.base.Objects;
import com.google.common.base.MoreObjects;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import Network.TopologyParameters;

/**
* Edge class in EON including
* Created by yby on 2017/3/31.
*/
public class LinkImplementation extends DefaultWeightedEdge implements Serializable{
  private ArrayList<FrequencySlots> slots;
  private ArrayList<Cores> cores;

  CoreSet coreset = new CoreSet ();
  public ArrayList<FrequencySlots> getSlots() {
      return slots;
  }

  public Node getSource() {
      return (Node) super.getSource();
  }

  public Node getDestination() {
      return (Node) super.getTarget();
  }
  
  /**
   * selecting adjacentcores
   */
  public int AdjacentCoresNum() {
      int count = 0;
      for(Cores core : cores) {
          if (core.isAdjanent()) {
              count++;
          }
      }
      return count;
  }
/**
 * get adjacentcores
 */
  public ArrayList<Integer> getCoreList() {
      ArrayList<Integer> AdjacentCores = Lists.newArrayList();
      for (Cores core : cores) {
          if (core.isAdjanent()) {
        	   for(int i = 0; i <= 6; i++){
                   for(int j=0; j<coreset.getCore(i).getAdjacentCores().size(); j++){
        
       if ( core.getAdjacentCoreIndex()==coreset.getCore(i).getId() && coreset.getCore(i).getAdjacentCores().get(j).getId()==core.getAdjacentCoreIndex()) {
        	  AdjacentCores.add(core.getAdjacentCoreIndex());
          }
                   
        	   }
        	   }
          }
      }
      return AdjacentCores;
  }
  ////////////////////////////////////////
  /**
   * get the array list of available slots index by ascend.
   * @return set
   */
  public ArrayList<Integer> NonAdjacentCores() {
      ArrayList<Integer> NonAdjacentCores = Lists.newArrayList();
      for (Cores core : cores) {
          if (!core.isAdjanent()) {
        	   for(int i = 0; i <= 6; i++){
                   for(int j=0; j<coreset.getCore(i).getAdjacentCores().size(); j++){
        
       if ( core.getAdjacentCoreIndex()!=coreset.getCore(i).getId() && coreset.getCore(i).getAdjacentCores().get(j).getId()==core.getAdjacentCoreIndex() || 
    		   core.getAdjacentCoreIndex()==coreset.getCore(i).getId() && coreset.getCore(i).getAdjacentCores().get(j).getId()!=core.getAdjacentCoreIndex()) {
    	   NonAdjacentCores.add(core.getAdjacentCoreIndex());
          }
                   
        	   }
        	   }
          }          
      }
      return NonAdjacentCores;
  }

/////////////////////////////////////////////////////////////////////  
  
  /**
   * calculate the number of occupied slots.
   * @return
   */
  public int occupiedSlotsNum() {
      int count = 0;
      for(FrequencySlots slot : slots) {
          if (slot.isOccupied()) {
              count++;
          }
      }
      return count;
  }

  /**
   * loading the available slots index.
   * The iterator of class Treeset is ordered by ascend.
   * @return set
   */
  public TreeSet<Integer> availableSlotsIndexSet() {
      TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();

      for (FrequencySlots slot : slots) {
          if (!slot.isOccupied()) {
              availableSlotsIndex.add(slot.getSlotIndex());
          }
      }
      return availableSlotsIndex;
  }

  /**
   * get the array list of available slots index by ascend.
   * @return set
   */
  public ArrayList<Integer> availableSlotsIndexList() {
      ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();
      for (FrequencySlots slot : slots) {
          if (!slot.isOccupied()) {
              availableSlotsIndex.add(slot.getSlotIndex());
          }
      }
      return availableSlotsIndex;
  }

  /**
   * get the occupied condition per slot.
   * @return list of occupied slots index
   */
  public ArrayList<Integer> occupiedSlotsIndex() {
      ArrayList<Integer> list = Lists.newArrayList();
      for(FrequencySlots slot : slots) {
          if (slot.isOccupied()) {
              list.add(slot.getOccupiedServiceIndex());
          }
      }
      return list;
  }

  /**
   * 
   * creating fucntion which will be used to populate data on the graph
   */
  public Link() {
      slots = Lists.newArrayListWithCapacity(TopologyParameters.getInstance().slotNum);
      for (int i=0;i<TopologyParameters.getInstance().slotNum;i++) {
          // slot index starts from 1.
          slots.add(new FrequencySlots(i+1));
      }
  }

  @Override
  public String toString() {
      //return Objects.toStringHelper(this)
      return MoreObjects.toStringHelper(this)

              .add("source", getSource())
              .add("destination", getTarget())
              .toString();
  }
 


}
