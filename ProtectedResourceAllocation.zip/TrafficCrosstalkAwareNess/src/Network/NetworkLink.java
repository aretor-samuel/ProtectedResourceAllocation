package Network;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;



/**
 * Network link
 * Currently, has 320 slices
 *
 */
//public class NetworkLink  extends FixedLengthLink<NetworkLink> implements Comparable<NetworkLink>{
public class NetworkLink  {
	

	//public class NetworkLink<T extends NetworkLink<T>> implements Comparable<T> {
/**	
	public static final int NUMBER_OF_SLICES = 640;
	public static final int NUMBER_OF_LINKCORES = 7;

	
	final Spectrum slicesUp = new Spectrum(NUMBER_OF_SLICES);
	final Spectrum slicesDown = new Spectrum(NUMBER_OF_SLICES);*/
//	final LinkCores busy = new LinkCores(NUMBER_OF_LINKCORES);
//	final LinkCores iddle = new LinkCores(NUMBER_OF_LINKCORES);
	int length;

//	final	List<LinkCores> coreList  = new ArrayList<LinkCores>(7);

	
	public NetworkLink(int length) {
//		super(length);
	//	this.length=length;	
	       
	   	       // coreList = new ArrayList<LinkCores>(7);
	   	   /*     for (int i = 0; i < 7; i++) {
	   	            coreList.add(new LinkCores(i));
	   	        }
	   	        initAdjCores(); 	*/        
	   	        
		      //    System.out.println(coreList.toString());


	}
	
	public int getLength() {
		return length;
	}
	
	public void setLength(int length) {
		this.length = length;
	}

/*	@Override
	public int compareTo(T other) {
		if (length < other.length) return -1;
		else if (length == other.length) return 0;
		else return 1;
	}*/
/**	
	@SuppressWarnings("rawtypes")
	public NetworkLink(Map map) {
		super(map);
	}*/
	
/**	@Override
	public Map<String, Object> serialize() {
		return super.serialize();
	}*/
/*	public void initAdjCores() {

		coreList.get(0).addAdjCores(coreList.get(1));
		coreList.get(0).addAdjCores(coreList.get(5));
		coreList.get(0).addAdjCores(coreList.get(6));

		coreList.get(1).addAdjCores(coreList.get(0));
		coreList.get(1).addAdjCores(coreList.get(2));
		coreList.get(1).addAdjCores(coreList.get(6));

		coreList.get(2).addAdjCores(coreList.get(1));
		coreList.get(2).addAdjCores(coreList.get(3));
		coreList.get(2).addAdjCores(coreList.get(6));

		coreList.get(3).addAdjCores(coreList.get(2));
		coreList.get(3).addAdjCores(coreList.get(4));
		coreList.get(3).addAdjCores(coreList.get(6));

		coreList.get(4).addAdjCores(coreList.get(3));
		coreList.get(4).addAdjCores(coreList.get(5));
		coreList.get(4).addAdjCores(coreList.get(6));

		coreList.get(5).addAdjCores(coreList.get(0));
		coreList.get(5).addAdjCores(coreList.get(4));
		coreList.get(5).addAdjCores(coreList.get(6));

		coreList.get(6).addAdjCores(coreList.get(0));
		coreList.get(6).addAdjCores(coreList.get(1));
		coreList.get(6).addAdjCores(coreList.get(2));
		coreList.get(6).addAdjCores(coreList.get(3));
		coreList.get(6).addAdjCores(coreList.get(4));
		coreList.get(6).addAdjCores(coreList.get(5));

		}*/
}