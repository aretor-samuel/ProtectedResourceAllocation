package Network;


import Utility.Weight;

/**
 * Created by Boyuan on 16-11-12.
 * Only have getter methods, for written protection. Because if someone want to change a node instance, he must be sure
 * that he knows what type is it. So setter method will be included in its implementation classes.
 */
public interface Node extends Weight {

    double hopWeight = 0;

    /**
     * 
     */
    Node deepClone();

    /**
     * get node id.
     * @return node id
     */
    NodeId getNodeId();

    /**
     * get node type.
     * @return node type
     */
    NodeType getNodeType();

    /**
     * get node status.
     * @return node status
     */
    NodeStatus getNodeStatus();

    /**
     * only this setter method allowed in Node.
     * @param status
     */
    void setNodeStatus(NodeStatus status);

    /**
     * node builder. The setter function will be included in builder class.
     */
    interface NodeBuilder {

        /**
         * build Node instance
         * @return node
         */
        Node build();

        /**
         *
         * @param nodeId
         * @param status
         * @return
         */
        Node build(NodeId nodeId, NodeStatus status);

        /**
         * set node status
         * @param status node status
         */
        void setNodeStatus(NodeStatus status);

        /**
         * set node type
         * @param type
         */
       void setNodeType(NodeType type);
    }
}
