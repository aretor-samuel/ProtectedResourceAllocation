package Network;

import com.google.common.collect.Lists;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * The Bootstrap class before simulation for initialization.
 * Created by yby on 2017/3/31.
 */
public class TopologySetup {
    private static TopologySetup ourInstance = new TopologySetup();

    public static TopologySetup getInstance() {
        return ourInstance;
    }
    // root configure file name.
    String confFile = "/home/babel/eclipse-workspace/TrafficCrosstalkAwareNess/src/resources/init.properties";
		 
		static List<String> edgesStr;
	static	 int edgeNum;

    /** Parameters about network **/
    public TopologyParameters TopologyParams = TopologyParameters.getInstance();
//    public EonNetParams netParams = EonNetParams();


    /** Parameters about Traffic generation **/


    /**
     * Simulation related parameters parsing from Properties files.
     */
   // private Bootstrap() {
  public       TopologySetup() {

        try {
            Properties init = new Properties();
            init.load(new FileInputStream(confFile));
            TopologyParams.cores = Integer.parseInt(init.getProperty("cores"));
            TopologyParams.startingCore= Integer.parseInt(init.getProperty("starting_core"));
            TopologyParams.EndingCore = Integer.parseInt(init.getProperty("ending_core"));
            TopologyParams.slotNum = Integer.parseInt(init.getProperty("slot_num_per_edge"));
            TopologyParams.timeInterval = Integer.parseInt(init.getProperty("time_interval"));
            TopologyParams.rouBias = Double.parseDouble(init.getProperty("rou_bias"));
            TopologyParams.rouBusinessPeak = Double.parseDouble(init.getProperty("rou_business_peak"));
            TopologyParams.rouResidentialPeak = Double.parseDouble(init.getProperty("rou_residential_peak"));
            TopologyParams.minRequiredSlotNum = Integer.parseInt(init.getProperty("min_required_slot_num"));
            TopologyParams.maxRequiredSlotNum = Integer.parseInt(init.getProperty("max_required_slot_num"));
            TopologyParams.miu = Double.parseDouble(init.getProperty("miu"));
            int netNum = Integer.parseInt(init.getProperty("net_num"));
            TopologyParams.networks = Lists.newArrayListWithCapacity(netNum);
            for (int i=1; i<=netNum; i++) {
                // load specific properties file of network parameters.
               String netFileName = init.getProperty("net_"+i+".file_name");
                Properties netProperties = new Properties();
                netProperties.load(new FileInputStream(netFileName));
                String name = netProperties.getProperty("name");

                int vertexNum = Integer.parseInt(netProperties.getProperty("vertex_num"));
               // int edgeNum = Integer.parseInt(netProperties.getProperty("edge_num"));
                edgeNum = Integer.parseInt(netProperties.getProperty("edge_num"));

               // List<String> edgesStr = Lists.newArrayListWithCapacity(edgeNum);
                 edgesStr = Lists.newArrayListWithCapacity(edgeNum);

                for (int edgeIndex=1; edgeIndex<=edgeNum; edgeIndex++) {
                    edgesStr.add(netProperties.getProperty("edge_"+edgeIndex));
                }
              //  System.out.println( edgesStr);

                ArrayList<Integer> businessArea = Lists.newArrayList();
                int businessSize = Integer.parseInt(netProperties.getProperty("business_vertex_num"));
                String[] businessVx = netProperties.getProperty("business_vertexes").split(",");
                if (businessVx.length == businessSize) {
                    for (int j=0; j<businessSize; j++) {
                        businessArea.add(Integer.parseInt(businessVx[j]));
                    }
            //        System.out.println( businessArea);

                } else {
                    throw new RuntimeException("business vertexes configuration error!");
                }

                ArrayList<Integer> residentialArea = Lists.newArrayList();
                int residentSize = Integer.parseInt(netProperties.getProperty("residential_vertex_num"));
                String[] residentVx = netProperties.getProperty("residential_vertexes").split(",");
                if (residentVx.length == residentSize) {
                    for (int j=0; j<residentSize; j++) {
                        residentialArea.add(Integer.parseInt(residentVx[j]));
                    }
              //      System.out.println(  residentialArea);

                } else {
                    throw new RuntimeException("residential vertexes configuration error!");
                }

                TopologyquantifiedDetails singleEonNet = new TopologyquantifiedDetails(businessArea, residentialArea, name, vertexNum, edgeNum, edgesStr);
                TopologyParams.networks.add(singleEonNet);
               // netParams.addSingleEonNet(singleEonNet);

              //  System.out.println(  singleEonNet.getResidentialArea());

               

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void main(String ... argv) {
    //	ourInstance.Bootstrap();
    	TopologyParameters params = TopologySetup.getInstance().TopologyParams;

      //   for (int i = 0; i < params.networks.size(); i++) {
        //     SingleEonNet net = params.networks.get(i);
     //  System.out.println(  params.networks.getNetwork());
      //   System.out.println(  params.getInstance().getNetwork().get(0).getResidentialArea());
         System.out.println(  params.getInstance().getNetwork().get(0).vertexNum);
       //  LoadTopology LoadTopolo = new LoadTopology();
        // System.out.println(LoadTopolo.equals(netFileName));
        // System.out.println(name);

       //  }

    }
}
