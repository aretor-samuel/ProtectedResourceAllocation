package Network;


/**
 * Created by Boyuan on 16-11-12.
 * Device Type Enums. Actually it's not so useful, for Node in Topology always contains few information while simulation.
 */
public enum NodeType {

    ROUTER,
    CWDM,
    OTN,
    DWDM,
    OXC
}

