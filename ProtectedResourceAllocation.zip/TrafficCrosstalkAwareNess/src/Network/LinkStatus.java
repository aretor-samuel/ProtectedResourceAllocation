package Network;




/**
 * Created by Sambabel on 2019-05-16.
 */
public enum LinkStatus {
    UP,
    DOWN
}
