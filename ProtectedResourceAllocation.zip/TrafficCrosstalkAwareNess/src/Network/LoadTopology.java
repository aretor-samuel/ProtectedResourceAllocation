package Network;

import Network.Node;
import Network.NodeId;
import Network.NodeStatus;
import Network.Link;
import Network.LinkID;
import Network.LinkStatus;
import Network.LinkImplementation;
import Network.NodeIdImplement;
import Network.Nodeimplement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



/**
 * Created by asia on 2016/11/14.
 * require : 读入并构建网络拓扑NSFNET
 */
public class LoadTopology {

    private static SdmNetwork sdmNetwork;
  

    public static void setSdmNetwork(SdmNetwork sdm) {
        sdmNetwork = sdm;
    }

   // @SuppressWarnings("static-access")
	public static SdmNetwork resdTopo2SdmNet(){

        SdmNetwork sdmNetwork = new SdmNetwork();
        sdmNetwork.nodes = new HashMap<NodeId, Node>();
        sdmNetwork.edges = new HashMap<LinkID, Link>();

     //   SdmNodeImpl.SdmNodeBuilder sdmNodeBuilder = SdmNodeImpl.builder();
        Nodeimplement.SdmNodeBuilder sdmNodeBuilder =Nodeimplement.builder();
     //   SdmEdgeImpl.SdmEdgeBuilder sdmEdgeBuilder = SdmEdgeImpl.builder();
    //    LinkImplementation.LinkStateBuilder LinkStateBuilder= LinkImplementation.builder();
      //  LinkImplementation.LinkStateBuilder LinkStateBuilder= LinkImplementation.builder();
    //    LinkImplementation.LinkStateBuilder LinkStateBuilder= LinkImplementation.builder();
        LinkImplementation.LinkStateBuilder LinkStateBuilder= LinkImplementation.builder();

        Group  group = new  Group();
        JsonObject json2Object1 = new JsonObject();
        //List<Links> jsonLinks = json2Object1.getGroup().getLinks();
     //   List<Links> jsonLinks = group.getLinks();

      


      // List<Nodes> jsonNodes =json2Object1.getGroup().getNodes();
     //  List<Nodes> jsonNodes =group.getNodes();

       json2Object1.Json2Object();

   	//	Json2Object();
   	 /*   if (json2Object1.group != null) {
   	             for (Links t : json2Object1.group.getLinks()) {
   	               System.out.println(t.getSrcSeq() + " - " + t.getDstSeq() + " - " + t.getWeight());
   	             }
   	           }*/

   //     for (Nodes jsonnodes: jsonNodes){
         for (Nodes jsonnodes: json2Object1.group.getNodes()){

          //  Node node = sdmNodeBuilder.build(new SdmNodeIdImpl(jsonnodes.getNodeId()), NodeStatus.UP);
            Node node = sdmNodeBuilder.build(new NodeIdImplement(jsonnodes.getNodeId()), NodeStatus.UP);

            sdmNetwork.nodes.put(node.getNodeId(), node);
    	// 	System.out.println(sdmNetwork.nodes);

        }

   //  for (Links jsonlinks : jsonLinks){
         for (Links jsonlinks : json2Object1.group.getLinks()){
            //	for (Links jsonlinks: links){


            NodeId srcId = new NodeIdImplement(jsonlinks.getSrcSeq());
            NodeId dstId = new NodeIdImplement(jsonlinks.getDstSeq());
            Link edge = LinkStateBuilder.build(sdmNetwork.nodes.get(srcId),
                                            sdmNetwork.nodes.get(dstId),
                                            LinkStatus.UP,
                                            false,
                                            jsonlinks.getWeight());
            sdmNetwork.edges.put(edge.getEdgeId(), edge);
    	 //	System.out.println(sdmNetwork.edges);

        }

        return sdmNetwork;

    }

    /**
     * @return Map<NodeId, Node>
     */
    public static Map<NodeId, Node> obtainNode() {
        return sdmNetwork.nodes;
    }

    /**
     * 
     * @return Map<EdgeId, Edge>
     */
    public static Map<LinkID, Link> obtainLink() {
        return sdmNetwork.edges;
    }

    /**
     */

    static class SdmNetwork {
        public Map<LinkID, Link> edges;
        public Map<NodeId, Node> nodes;
    }
    public static void main(String[] args)  {
    	// 	System.out.println(resdTopo2SdmNet());
   // 	 	System.out.println(sdmNetwork.edges);
    	 	Group  group = new  Group();
         //   Json2Object json2Object1 = new Json2Object();
            //List<Links> jsonLinks = json2Object1.getGroup().getLinks();
           // List<Links> jsonLinks = json2Object1.group.getLinks();
    	 	//System.out.println(jsonLinks);

    	// 	System.out.println(resdTopo2SdmNet());
            JsonObject json2Object1 = new JsonObject();

            json2Object1.Json2Object();

    	//	Json2Object();
    	    if (json2Object1.group != null) {
    	             for (Links t : json2Object1.group.getLinks()) {
    	               System.out.println(t.getSrcSeq() + " - " + t.getDstSeq() + " - " + t.getWeight());
    	             }
    	           }
     
    }
}
