package Network;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import com.google.common.collect.Lists;

import Graph.Graph1;
import Graph.Relation;
import TrafficGeneration.Service;
import Utility.MetricType;
import Utility.NetworkException;


/**
 * Class Network has main data about the network 
 *
 */
//public class Network extends Graph<NetworkNode, NetworkLink, NetworkPath, Network> implements YamlSerializable {
	public class Network extends Graph1<Node2, NetworkLink, NetworkPath, Network>  {
//		public class Network extends Graph1<NetworkNode, TestEdge, NetworkPath, Network>  {



	
	//Map<String, NetworkNode> nodes = new HashMap<String, NetworkNode>();
	Map<Integer, Node2> nodes = new HashMap<Integer, Node2>();

	Map<String, List<Node2>> nodesGroups = new HashMap<String, List<Node2>>();
	Map<List<String>, NetworkLink> links = new HashMap<List<String>, NetworkLink>();

	//Set<Relation<NetworkNode, NetworkLink, NetworkPath>> inactiveLinks = new HashSet<>();
	Set<Relation<Node2, NetworkLink>> inactiveLinks = new HashSet<>();

	Set<NetworkPath> inactivePaths = new HashSet<>();
	
	List<Modulation> modulations = new ArrayList<Modulation>();
	  MetricType modulationMetricType=MetricType.DYNAMIC;
//	  MetricType modulationMetricType=MetricType.STATIC;

	int[][] modulationMetrics = new int[6][6];
	
	 MetricType regeneratorMetricType=MetricType.DYNAMIC;
	// MetricType regeneratorMetricType=MetricType.STATIC;

	  int regeneratorMetricValue=6; // set always
		double metric = -1.0;

	 int bestPathsCount;
	boolean canSwitchModulation=true;
//	boolean canSwitchModulation=false;

	 int maxPathsCount;
		public static ArrayList<int[]>modulationDistances = new ArrayList<int[]>(); //new int[40]
		public static  ArrayList<int[]>slicesConsumption = new ArrayList<int[]>(); //new int[40]

	private final	int[] modulationDistance = new int[40];
	public Network() {
		super();

//		super(new NetworkPathBuilder());
	//	intModulation();
		NetworkTopology();
	}
	
	// DEMANDS
	
	
	public void setBestPathsCount(int bestPathsCount) {
		this.bestPathsCount = bestPathsCount;
	}
	
	public int getBestPathsCount() {
		return bestPathsCount;
	}
	
	public void setCanSwitchModulation(boolean canSwitchModulation) {
		this.canSwitchModulation = canSwitchModulation;
	}
	
	public boolean canSwitchModulation() {
		return canSwitchModulation;
	}
	
	
	// NODES GROUPS
	
	public boolean addNodeToGroup(String groupName, Node2 node) {
		if (!contains(node)) return false;
		List<Node2> group = nodesGroups.get(groupName);
		if (group == null) {
			group = new ArrayList<Node2>();
			nodesGroups.put(groupName, group);
		}
		if (group.contains(node)) return false;
		group.add(node);
		return true;
	}
	
	public boolean removeNodeFromGroup(String groupName, Node2 node) {
		if (!contains(node)) return false;
		List<Node2> group = nodesGroups.get(groupName);
		if (group == null) return false;
		if (!group.contains(node)) return false;
		group.remove(node);
		if (group.isEmpty()) nodesGroups.remove(groupName);
		return true;
	}
	
	public List<Node2> getGroup(String name) {
		return nodesGroups.get(name);
	}
	
	// NODES
	
	public Node2 getNode(String name) {
		return nodes.get(name);
	}
	
	@Override
	protected boolean addNode(Node2 nodeA, Node2 nodeB) {
		boolean result = super.addNode(nodeA, nodeB);
		if (!nodes.containsValue(nodeA))
		nodes.put(nodeA.getIndex(), nodeA);
		if (!nodes.containsValue(nodeB))
			nodes.put(nodeB.getIndex(), nodeB);
		

		return result;
	}
///////////////////////////////
/*	
//	@Override
	protected boolean addNode(NetworkNode node) {
		boolean result = super.addNode(node);
		if (result) nodes.put(node.getNode(), node);
		return result;
	}*/
//////////////////////
	
	
/*	public void calculateMetricFromParts(List<TestEdge> parts) {
		metric = 0.0;
		for (TestEdge part : parts) metric += part.metric;
		metric /= parts.size();
		
	}
	
	public void setMetric(double metric) {
		this.metric = metric;
	}
	
	public double getMetric() {
		return metric;
	}
	
	public void mergeRegeneratorlessParts(List<TestEdge> parts) {
		for (int i = 1; i < parts.size(); i++)
			if (!parts.get(i).getSource().hasFreeRegenerators()) {
				parts.get(i - 1).merge(parts.get(i));
				parts.remove(i);
				i--;
			}
	}
	*/
/*	public void mergeIdenticalModulation(List<TestEdge> parts, int volume) {
		for (int i = 1; i < parts.size(); i++)
				if (parts.get(i - 1).getModulation() == parts.get(i).getModulation() && parts.get(i - 1).getWeight() +
						parts.get(i).getWeight() <= parts.get(i).getModulation().modulationDistances1()[volume]) {		
				
				parts.get(i - 1).merge(parts.get(i));
				parts.remove(i);
				i--;
			}
	}*/
	
/*	public Modulation getModulationFromLongestPart(List<TestEdge> parts) {
		TestEdge longestPart = parts.get(0), part;
		double distance=0.0;
		for (int i = 1; i < parts.size(); i++) {
			part = parts.get(i);

			distance+=part.getWeight();
		//	part = parts.get(i);
		//	if (longestPart.getWeight() < part.getWeight()) longestPart = part;
			if (longestPart.getWeight() < part.getWeight()) longestPart = part;

		}
		return longestPart.getModulation();
	}*/
	

//	public double getOccupiedRegeneratorsPercentage(List<TestEdge> parts) {
		public double getOccupiedRegeneratorsPercentage(List<Link2> parts) {

		double occupiedRegeneratorsPercentage=0.0, allRegenerators=0.0;
		//for (TestEdge edges: parts) {
			for (Link2 edges: parts) {

			
				Node2 source = edges.getSource();

					//NetworkNode destination = edges.getDestination();
					allRegenerators += source.regeneratorsCount;

						occupiedRegeneratorsPercentage += source.occupiedRegenerators;
						}
			//  System.out.println(occupiedRegeneratorsPercentage);
			  if (allRegenerators != 0){
				  return	occupiedRegeneratorsPercentage /= allRegenerators;
					
				} else{
					return	occupiedRegeneratorsPercentage = 1; // TODO TO JEST REGENERATOROWA KUPA...
					
				}

		//return occupiedRegeneratorsPercentage;
	}
	
	public int getNeededRegeneratorsCount(List<Link2> parts) {
		return parts.size() - 1;
	}
	
/*	//////////////////////////
	@Override
	public boolean removeNode(Node2 node) {
		boolean result = super.removeNode(node);
		if (result) nodes.remove(node.getNode());
		return result;
	}
	//generators
	public  List<TrafficGenerator> getTrafficGenerators(){
		return generators;
}
	public void  addGenerators(TrafficGenerator generator) {
		generators.add(generator);
	}*/
	// LINKS
	
	Random linkDestroyer;
	
	public void setSeed(long seed) {
		linkDestroyer = new Random(seed);
	}
	
	//public Set<Service> cutLink(BaseAlgorithm RSA) {
		public Set<Service> cutLink() {

	//	System.out.println("Link fail!");
	//	List<Relation<NetworkNode, NetworkLink, NetworkPath>> links = new ArrayList<>();
		List<Relation<Node2, NetworkLink>> links = new ArrayList<>();

	//	for (Relation<NetworkNode, NetworkLink, NetworkPath> relation : relations)
		//	for (Relation<NetworkNode, NetworkLink, NetworkPath> relation : relations1)
				for (Relation<Node2, NetworkLink> relation : relations1)


			if (relation.hasLink() && !inactiveLinks.contains(relation))

				links.add(relation);
	
      //     System.out.println(  linkDestroyer.nextInt(links.size()));


	//	Relation<NetworkNode, NetworkLink, NetworkPath> link = links.get(linkDestroyer.nextInt(links.size()));
		Relation<Node2, NetworkLink> link = links.get(linkDestroyer.nextInt(links.size()));

		//Relation<NetworkNode, NetworkLink, NetworkPath> link = links.get(linkDestroyer.nextInt(4));

//        System.out.println(link.toString());
   //   System.out.println(link.nodeA+"-----"+ link.nodeB );


	//	graph
		inactiveLinks.add(link);

	//List<PathPart>parts=serviceAssignment.getPath();

	/*	for (Relation<NetworkNode, NetworkLink, NetworkPath> relation : relations1)
			for (NetworkPath path : relation.getPaths())
				if (Math.abs(path.indexOf(relation.nodeA) - path.indexOf(relation.nodeB)) == 1)


				inactivePaths.add(path);*/

		Set<Service> working = new HashSet<Service>();
		Set<Service> backup = new HashSet<Service>();
		Set<Service> result = new HashSet<Service>();
	         //System.out.println(link.getLink().getLength());
	        // System.out.println(link.getPaths().toString());
     //   for (PathPart part: parts){
  	 //     System.out.println(part.getSource()+"-----"+ part.getDestination() );
int serviceIndex;
   //   if (link.nodeA==part.getSource() && link.nodeB==part.getDestination() )   {             
//List<LinkCores> coreList =link.getLink().coreList;
//		List<LinkCores> coreList =part.getCoreList();
for (Link2 edge : graph.edgeSet()) {
	
//	if(edge.getWeight()==link.getLink().getLength()) {
		if(edge.getSource()==link.nodeA && edge.getDestination()==link.nodeB || edge.getSource()==link.nodeB && edge.getDestination()==link.nodeA ) {

      List<LinkCores> sdmCorelist = edge.getCoreList();
       for (LinkCores sdmCore : sdmCorelist) {
	 		
       	
          List<FrequencySlots> wavelengths = sdmCore.getWavelength();


	//	for(LinkCores SdmCore: coreList) {

	     //   System.out.println(SdmCore.getSlices().getSegments());
	 	//	double slicesOccupationPercentage1 = SdmCore.getOccupiedSlicesPercentage() * 100;
	    //     System.out.println(slicesOccupationPercentage1);
	 		
	 		
         //    List<FrequencySlots> wavelengths = SdmCore.getWavelength();
  			 for (int index=0; index<wavelengths.size(); index++) {
  			 if (wavelengths.get(index).getIsOccupied()) {
                 //	occupiedSlotNumWithXT=comparedCore.occupiedSlotsNum();
  				ArrayList<Service>AllocatedServices=sdmCore.getService();
  				serviceIndex=wavelengths.get(index).getOccupiedServiceIndex();
  				for(Service seviceAllocated: AllocatedServices) {
  					if (seviceAllocated.getEventId()==serviceIndex) {
                  working.add(seviceAllocated);
                 }
  				}
  			 }
  			 }
       }
     //  graph.removeEdge(edge);
	}
	    //   graph.removeEdge(edge);
  
}
//System.out.println(working.toString());

	//	 for(int i=0; i < coreList.size(); i++) {
		//		 LinkCores SdmCore= coreList.get(i);
			/**	 ArrayList<Service>AllocatedServices=SdmCore.getService();
					for(Service seviceAllocated: AllocatedServices) {
						if (seviceAllocated!=null) {
		           working.add(seviceAllocated);
		          }
						}
			        System.out.println(working.toString());*/

/*	///	for (SpectrumSegment segment : SdmCore.getSlices().getSegments())
			for (SpectrumSegment segment : sdmCore.getSlices().getSegments()) {

	        System.out.println(segment.toString());

	//	for (SpectrumSegment segment : link.getLink().slicesDown.getSegments())
			if (segment instanceof WorkingSpectrumSegment) working.add(((WorkingSpectrumSegment) segment).getOwner());
			else if (segment instanceof BackupSpectrumSegment) backup.addAll(((BackupSpectrumSegment) segment).getDemands());
	/**	for (SpectrumSegment segment : link.getLink().slicesUp.getSegments())
			if (segment instanceof WorkingSpectrumSegment) working.add(((WorkingSpectrumSegment) segment).getOwner());
			else if (segment instanceof BackupSpectrumSegment) backup.addAll(((BackupSpectrumSegment) segment).getDemands());*/
			
	//	}
			
      
		for (Service demand : working) {
         //   for(int i = 0; i < result.size(); i++) {
            //	int serviceIndex=demand.getEventId();
			//Iterator<Service>=working.iterator();
           // if (!RSA.getPassedServices().containsKey(demand.getEventId())) {

		//	if (!demand.onWorkingFailure()) {
				result.add(demand);
			//	allocatedDemands.remove(demand);
	//		}
		}
		for (Service demand : backup) {
     //  if (!RSA.getPassedServices().containsKey(demand.getEventId())) {

//			demand.onBackupFailure();
	//		RSA.handleServiceLeave(demand.getEventId());
			result.add(demand);
       }
//	       System.out.println(result.toString());

		links.remove(link);
		if (links.size() == 1)
			throw new NetworkException("All links in the network failed...");
		
		return result;
	}
	
	public boolean isInactive(NetworkPath path) {
		return inactivePaths.contains(path);
	}
	
/*	public Spectrum getLinkSlices(NetworkNode source, NetworkNode destination) {
	 int NUMBER_OF_SLICES = 640;
	 int NUMBER_OF_LINKCORES = 7;

		
		 Spectrum slicesUp = new Spectrum(NUMBER_OF_SLICES);
		Spectrum slicesDown = new Spectrum(NUMBER_OF_SLICES);
	//	NetworkLink link = getLink(source, destination);
		//return source.getID() < destination.getID() ? link.slicesUp : link.slicesDown;
		return slicesDown;

	}
	public List<LinkCores> getLinkCores(NetworkNode source, NetworkNode destination) {
		NetworkLink link = getLink(source, destination);
	//	return source.getID() < destination.getID() ? link.busy : link.iddle;
//	if	 (source.getID() < destination.getID()) 
List<LinkCores> coreList  = new ArrayList<LinkCores>(7);

		// return		link.coreList ;
		 return		coreList ;


		
	}*/
	
	// MODULATION
	
	public MetricType getModualtionMetricType() {
		return modulationMetricType;
	}
	
	public int getDynamicModulationMetric(Modulation modulation, int slicesOccupationMetric) {
		if (modulationMetricType != MetricType.DYNAMIC) throw new NetworkException("Trying to obtain dynamic modulation metric when the network is in static modulation metric mode.");
		if (slicesOccupationMetric < 0 || slicesOccupationMetric > 5) throw new NetworkException("Slices occupation metric must be >= 0 and <= 5!");
	//	if (slicesOccupationMetric < 0 || slicesOccupationMetric > 4) throw new NetworkException("Slices occupation metric must be >= 0 and <4!");
		return modulationMetrics[slicesOccupationMetric][modulation.ordinal()];
	}
	
	public int getStaticModulationMetric(Modulation modulation) {
		if (modulationMetricType != MetricType.STATIC) throw new NetworkException("Trying to obtain static modulation metric when the network is in dynamic modulation metric mode.");
		return modulationMetrics[0][modulation.ordinal()];
	}
	
	public void setModualtionMetricType(MetricType modulationMetricType) {
		this.modulationMetricType = modulationMetricType;
		if (modulationMetricType == MetricType.DYNAMIC)
			for (int i = 0; i < 6; i++) // TODO RETHINK THAT
				for (int j = 0; j < 6; j++)
					modulationMetrics[i][j] = j <= i ? i - j : j;
	}
	
	public void setStaticModulationMetric(Modulation modulation, int metric) {
		modulationMetrics[0][modulation.ordinal()] = metric;
	}
	
	public void allowModulation(Modulation modulation) {
		if (!modulations.contains(modulation))
			modulations.add(modulation);
	}
	
	public void disallowModulation(Modulation modulation) {
		if (modulations.contains(modulation))
			modulations.remove(modulation);
	}
	 private int generateOrdinalNo() {
	        ArrayList<Integer> vol = Lists.newArrayList();

		     int   ordinalno = (int) Math.floor(Math.random() * 5);


			return ordinalno;

	    }
	// needs to be attended
	public List<Modulation> getAllowedModulations() {
	//	return new ArrayList<Modulation>(modulations);
	//	return new ArrayList<Modulation>(Modulation.values()
		List<Modulation> modulations = new ArrayList<Modulation>();
	   //  int   ordinalno = (int) Math.floor(Math.random() * 5);
	     int   ordinalno = generateOrdinalNo();


			for (Modulation modulation : Modulation.values()) {// if (this.modulations[modulation.ordinal()].isSelected())
				
				if (modulation.ordinal()==ordinalno) {
				modulations.add(modulation);
				}
			}
			return modulations;

	}
	 public void intModulation() {
		 for (Modulation modulation : Modulation.values()) {
				allowModulation(modulation);
			    }

}

	
	// REGENERATORS
	
	public MetricType getRegeneratorMetricType() {
		return regeneratorMetricType;
	}
	
	public void setRegeneratorMetricType(MetricType regeneratorMetricType) {
		this.regeneratorMetricType = regeneratorMetricType;
	}
	
	public int getRegeneratorMetricValue() {
		return regeneratorMetricValue;
	}
	
	public void setRegeneratorMetricValue(int regeneratorMetricValue) {
		this.regeneratorMetricValue = regeneratorMetricValue;
	}
	
	
/**	public static int generateModSlice(Modulation modulation, int volume) {
int vol=0;
	 for(int j=0; j < modulation.modulationDistances1().length; j++){
		 if (modulation.modulationDistances1()[j]==volume) {

	// modulation.modulationDistances=modulationDistances.get(i);
			 vol= modulation.slicesConsumption1()[j];
	 }
	 }
return vol;
}*/
	

	
/*public static int[] generateModSlice(Modulation modulation1) {
			 for (Modulation modulation : Modulation.values()) {
		// for(int i=0; i < modulationDistances.size(); i++){
				 if (modulation==modulation1) {
			 for(int j=0; j < slicesConsumption.size(); j++){

			// modulation.modulationDistances=modulationDistances.get(i);
			 modulation.slicesConsumption=slicesConsumption.get(j);
			 modulation1.slicesConsumption=modulation.slicesConsumption;
			// System.out.println(Arrays.toString(modulation.slicesConsumption));
			 }
			 }
			 }
		return modulation1.slicesConsumption;
	}*/
	
	public  int[] generateModDistance( ) {
		 
	return modulationDistance;
}
	
/**	public static int[] generateModDistance(Modulation modulation1) {
		 for (Modulation modulation : Modulation.values()) {
	// for(int i=0; i < modulationDistances.size(); i++){
			 if (modulation==modulation1) {
		 for(int j=0; j < modulationDistances.size(); j++){

		// modulation.modulationDistances=modulationDistances.get(i);
		 modulation.modulationDistances=modulationDistances.get(j);
		 modulation1.modulationDistances=modulation.modulationDistances;
		// System.out.println(Arrays.toString(modulation.slicesConsumption));
		 }
		 }
		 }
	return modulation1.modulationDistances;
}*/

	@SuppressWarnings({ "rawtypes", "unchecked" })

//	public void NetworkTopology() {
	private  void NetworkTopology() {
		
		Node2 node1= new Node2 (1, true);
		Node2 node2= new Node2 (2, true);
		Node2 node3= new Node2 (3, true);
		Node2 node4= new Node2 (4, true);
		Node2 node5= new Node2 (5, true);
		Node2 node6= new Node2 (6, true);
		Node2 node7= new Node2 (7, true);
		Node2 node8= new Node2 (8, true);
		Node2 node9= new Node2 (9, true);
		Node2 node10= new Node2 (10, true);
		Node2 node11= new Node2 (11, true);
		Node2 node12= new Node2 (12, true);
		Node2 node13= new Node2 (13, true);
		Node2 node14= new Node2 (14, true);
		Node2 node15= new Node2 (15, true);
		Node2 node16= new Node2 (16, true);
		Node2 node17= new Node2 (17, true);
		Node2 node18= new Node2 (18, true);
		Node2 node19= new Node2 (19, true);
		Node2 node20= new Node2 (20, true);
		Node2 node21= new Node2 (21, true);
		Node2 node22= new Node2 (22, true);
		Node2 node23= new Node2 (23, true);
		Node2 node24= new Node2 (24, true);
		Node2 node25= new Node2 (25, true);
		Node2 node26= new Node2 (26, true);
		Node2 node27= new Node2 (27, true);
		Node2 node28= new Node2 (28, true);


		

// group nodes
	/*	addNodeToGroup("Node_0", node28);
		addNodeToGroup("Node_1", node1);
		addNodeToGroup("Node_3", node3);
		addNodeToGroup("Node_5", node5);
		addNodeToGroup("Node_8", node8);
		addNodeToGroup("Node_16", node16);
		addNodeToGroup("Node_24", node24);
		addNodeToGroup("Node_17", node17);
		addNodeToGroup("Node_19", node19);
		addNodeToGroup("Node_21", node21);
		addNodeToGroup("Node_11", node11);
		addNodeToGroup("Node_12", node12);
		addNodeToGroup("Node_13", node13);
		addNodeToGroup("Node_14", node14);
		addNodeToGroup("Node_15", node15);
		addNodeToGroup("Node_16", node16);
		addNodeToGroup("Node_17", node17);
		addNodeToGroup("Node_18", node18);
		addNodeToGroup("Node_19", node19);
		addNodeToGroup("Node_21", node21);
		addNodeToGroup("Node_22", node22);
		addNodeToGroup("Node_23", node23);
		addNodeToGroup("Node_24", node24);
		addNodeToGroup("Node_25", node25);
		addNodeToGroup("Node_26", node26);*/


		
		
//		addNode( node1);
		//	addNode( node2);
			addNode( node1, node2);

			NetworkLink Link1=new NetworkLink(540);
		//	NetworkLink Link1A=new NetworkLink((int) Math.floor(Math.random() *3000));

			putLink(node1, node2, Link1);
		//	putLink( node2,node1, Link1);

		/*ode1.addChild(node2);
			put(node1,  node2,  540);
			put(node2, node1, 540);*/

		//	addNode( node1);
			//addNode( node6);
			addNode( node1, node6);

			NetworkLink Link2=new NetworkLink(522);

			putLink(node1, node6, Link2);
	//putLink(node6, node1, Link2);

		/*ode1.addChild(node6);
			put(node1, node6, 522);
			put(node6, node1, 522);*/


			
		//	addNode( node2);
			//addNode( node3);
			addNode( node2, node3);
			NetworkLink Link3=new NetworkLink(474);

			putLink(node2, node3, Link3);
			putLink(node3, node2,  Link3);
		/**de2.addChild(node3);
			put(node2, node3, 474);
			put(node3, node2, 474);*/


			//addNode( node2);
			//addNode( node6);
			addNode( node2, node6);

			NetworkLink Link4=new NetworkLink(720);

			putLink(node2, node6, Link4);
	/*putLink(node6, node2, Link4);
			node2.addChild(node6);
			put(node2, node6, 720);
			put(node6, node2, 720);
	*/

		//	addNode( node3);
			//addNode( node4);
			addNode( node3, node4);

			NetworkLink Link5=new NetworkLink(381);

			putLink(node3, node4, Link5);
	/*		putLink(node4, node3, Link5);
	/*		node3.addChild(node4);
			put(node3, node4, 381);
			put(node4, node3, 381);
	*/

//			addNode( node3);
		//	addNode( node5);
			addNode( node3, node5);

			NetworkLink Link6=new NetworkLink(218);
			putLink(node3, node5, Link6);
		/*	putLink(node5, node3, Link6);
			node3.addChild(node5);
			put(node3, node5, 218);
			put(node5, node3, 218);*/


		//	addNode( node3);
		//	addNode( node7);
			addNode( node3, node7);

			NetworkLink Link7=new NetworkLink(592);

			putLink(node3, node7, Link7);
	/*		putLink(node7, node3,  Link7);
			node3.addChild(node7);
			put(node3, node7, 592);
			put(node7, node3, 592);*/


		//ddNode( node4);
	//addNode( node5);
		addNode( node4, node5);

			NetworkLink Link8=new NetworkLink(271);

			putLink(node4, node5, Link8);
	/*		putLink(node5, node4,  Link8);
		/	node4.addChild(node5);
			put(node4, node5, 271);
			put(node5, node4, 271);*/


	//addNode( node4);
		//ddNode( node7);
			addNode( node4, node7);

			NetworkLink Link9=new NetworkLink(514);

			putLink(node4, node7, Link9);
	/*		putLink(node7, node4, Link9);
			node4.addChild(node7);
			put(node4, node7, 514);
			put(node7, node4, 514);
	*/

	//addNode( node5);
	//addNode( node8);
			addNode( node5, node8);
			NetworkLink Link10=new NetworkLink(507);

			putLink(node5, node8, Link10);
	/*		putLink(node8, node5, Link10);
			node5.addChild(node8);
			put(node5, node8, 507);
			put(node8, node5, 507);
	*/

//			addNode( node6);
//			addNode( node7);
			addNode( node6, node7 );

			NetworkLink Link11=new NetworkLink(534);

			putLink(node6, node7, Link11);
	/*		putLink(node7, node6, Link11);

			node6.addChild(node7);
			put(node6, node7, 534);
			put( node7, node6, 534);
	*/

//			addNode( node6);
//			addNode( node9);
			addNode( node6, node9);

			NetworkLink Link12=new NetworkLink(540);

			putLink(node6, node9, Link12);
	/*		putLink(node9, node6, Link12);
			node6.addChild(node9);
		//	node11.addChild(node25);
			put(node6, node9, 540);
			put(node9, node6, 540);
	*/

//			addNode( node6);
//			addNode( node11);
			addNode( node6, node11);

			NetworkLink Link13=new NetworkLink(775);

			putLink(node6, node11, Link13);
	/*		putLink(node11, node6, Link13);
			node6.addChild(node11);
			put(node6, node11, 775);
	*/
//			addNode( node7);
//			addNode( node8);
			addNode( node7, node8);

			NetworkLink Link14=new NetworkLink(722);

			putLink(node7, node8, Link14);
	/*		putLink(node8, node7,  Link14);
			node7.addChild(node8);
			put(node7, node8, 772);
			put(node8, node7, 772);
	*/
			
//			addNode( node7);
//			addNode( node9);
			addNode( node7, node9);
			NetworkLink Link15=new NetworkLink(783);

			putLink(node7, node9, Link15);
	/*		putLink(node9, node7, Link15);
			node7.addChild(node9);
			put(node7, node9, 783);
			put(node9, node7, 783);
	*/
			
//			addNode( node8);
//			addNode( node10);
			addNode( node8, node10);

			NetworkLink Link16=new NetworkLink(376);

			putLink(node8, node10, Link16);
	/*		putLink(node10, node8, Link16);
			node8.addChild(node10);
			put(node8, node10, 376);
			put(node10, node8, 376);


			addNode( node9);
			addNode( node10);
	*/		addNode( node9, node10);
			NetworkLink Link17=new NetworkLink(1209);

			putLink(node9, node10, Link17);
	/*		putLink(node10, node9, Link17);
			node9.addChild(node10);
			put(node9, node10, 1209);
			put(node10, node9, 1209);


			addNode( node9);
			addNode( node11);
	*/		addNode( node9, node11);
			NetworkLink Link18=new NetworkLink(400);

			putLink(node9, node11, Link18);
	/*		putLink(node11, node9, Link18);

			node9.addChild(node11);
			put(node9, node11, 400);
			put(node11, node9, 400);

	          
			addNode( node9);
			addNode( node12);
//		*/	addNode( node9, node12);

			NetworkLink Link19=new NetworkLink(747);

			putLink(node9, node12, Link19);
	/*		putLink(node12, node9, Link19);

			node9.addChild(node12);
			put(node9, node12, 747);
			put(node12, node9, 747);

	             
			addNode( node10);
			addNode( node13);
	*/		addNode( node10, node13);
			NetworkLink Link20=new NetworkLink(1500);

			
			putLink(node10, node13, Link20);
	/*		putLink(node10, node13, Link20);
			node10.addChild(node13);
			put(node10, node13, 1500);
			put(node13, node10, 1500);


			addNode( node10);
			addNode( node14);
		*/	addNode( node10, node14);

			NetworkLink Link21=new NetworkLink(552);
			putLink(node10, node14, Link21);
	/*		putLink(node14, node10, Link21);
			node10.addChild(node14);
			put(node10, node14, 552);
			put(node14, node10, 552);


			addNode( node11);
			addNode( node12);
	*/	addNode( node11, node12);

			NetworkLink Link22=new NetworkLink(327);
			putLink(node11, node12, Link22);
		/*	putLink(node12, node11, Link22);
			node11.addChild(node12);
			put(node11, node12, 327);
			put(node12, node11, 327);*/


	/*		addNode( node11);
			addNode( node15);
	//*/		addNode( node11, node15);
			NetworkLink Link23=new NetworkLink(594);
			putLink(node11, node15, Link23);
	/*		putLink(node15, node11, Link23);
			node11.addChild(node15);
			put(node11, node15, 594);
			put(node15, node11,594);



			addNode( node11);
			addNode( node19);
	//*/		addNode( node11, node19);
			NetworkLink Link24=new NetworkLink(600);
			putLink(node11, node19, Link24);
	/**		putLink(node19, node11, Link24);
			node11.addChild(node19);
			put(node11, node19, 600);
			put(node19, node11, 600);

			addNode( node12);
			addNode( node13);
//		*/	addNode( node12, node13);
			NetworkLink Link25=new NetworkLink(259);
			putLink(node12, node13, Link25);
	/*		putLink(node13, node12, Link25);

			node12.addChild(node13);
			put(node12, node13, 259);
			put(node13, node12, 259);

			addNode( node12);
			addNode( node16);
	//*/		addNode( node12, node16);
			NetworkLink Link26=new NetworkLink(393);
			putLink(node12, node16, Link26);
	/*		putLink(node16, node12, Link26);
			node12.addChild(node16);
			put(node12, node16, 393);
			put( node16, node12, 393);

			
			addNode( node13);
			addNode( node14);
//		*/	addNode( node13, node14);

			NetworkLink Link27=new NetworkLink(420);
			putLink(node13, node14, Link27);
	/*		putLink(node14, node13, Link27);

			node13.addChild(node14);
			put(node13, node14, 420);
			put(node14, node13, 420);


			addNode( node13);
			addNode( node17);
	//*/		addNode( node13, node17);

			NetworkLink Link28=new NetworkLink(1213);
			putLink(node13, node17, Link28);
	/*		putLink(node17, node13,  Link28);
			node13.addChild(node17);
			put(node13, node17, 1213);
			put(node17, node13, 1213);

			addNode( node14);
			addNode( node18);
	//*/		addNode( node14, node18);

			NetworkLink Link29=new NetworkLink(474);
			putLink(node14, node18, Link29);
	/*		putLink(node18, node14, Link29);
			node14.addChild(node18);
			put(node14, node18, 474);
			put( node18, node14, 474);


			addNode( node15);
			addNode( node16);
	//*/		addNode( node15, node16);

			NetworkLink Link30=new NetworkLink(623);
			putLink(node15, node16, Link30);
	/*		putLink(node16, node15, Link30);
		   node15.addChild(node16);
			put(node15, node16, 623);
			put(node16, node15, 623);


			addNode( node15);
			addNode( node20);
	//*/		addNode( node15, node20);

			NetworkLink Link31=new NetworkLink(796);
			putLink(node15, node20, Link31);
	/*	   putLink(node20, node15, Link31);
			node15.addChild(node20);
			put(node15, node20, 796);
			put(node20, node15, 796);


			addNode( node16);
			addNode( node17);
	//*/		addNode( node16, node17);

			NetworkLink Link32=new NetworkLink(834);
			putLink(node16, node17, Link32);
		/*	putLink(node17, node16, Link32);
			node16.addChild(node17);
			put(node16, node17, 834);
			put(node17, node16, 834);

			addNode( node16);
			addNode( node21);
//		*/	addNode( node16, node21);

			NetworkLink Link33=new NetworkLink(757);
			putLink(node16, node21, Link33);
	/*		putLink(node21, node16, Link33);
			node16.addChild(node21);
			put(node16, node21, 757);
			put(node21, node16, 757);

			addNode( node16);
			addNode( node22);
	//*/		addNode( node16, node22);

			NetworkLink Link34=new NetworkLink(819);
			putLink(node16, node22, Link34);
	/*		putLink(node22, node16, Link34);
			node16.addChild(node22);
			put(node16, node22, 819);
			put(node22, node16, 819);


			addNode( node17);
			addNode( node18);
	//*/		addNode( node17, node18);

			NetworkLink Link35=new NetworkLink(760);
			putLink(node17, node18, Link35);
	/*		putLink(node18, node17, Link35);
			node17.addChild(node18);
			put(node17, node18, 760);
			put(node18,node17, 760);


			addNode( node17);
			addNode( node22);
	//*/		addNode( node17, node22);

			NetworkLink Link36=new NetworkLink(551);
			putLink(node17, node22, Link36);
		/*	putLink(node22, node17,Link36);

			node17.addChild(node22);
			put(node17, node22, 551);
			put(node22, node17, 551);


			addNode( node17);
			addNode( node23);
//		*/	addNode( node17, node23);

			NetworkLink Link37=new NetworkLink(668);
			putLink(node17, node23, Link37);
		/*	putLink(node23, node17, Link37);
			node17.addChild(node23);
			put(node17, node23, 668);
			put(node23, node17, 668);

	            
			addNode( node18);
			addNode( node24);
//		*/	addNode( node18, node24);

			NetworkLink Link38=new NetworkLink(690);
			putLink(node18, node24, Link38);
	/*		putLink(node24, node18, Link28);
			node18.addChild(node24);
			put(node18, node24, 690);
			put(node24, node18, 690);


			addNode( node19);
			addNode( node20);
//		*/	addNode( node19, node20);

			NetworkLink Link39=new NetworkLink(462);
			putLink(node19, node20, Link39);
	/*		putLink(node20, node19, Link39);
			node19.addChild(node20);
			put(node19, node20, 462);
			put(node20, node19, 462);

			
			addNode( node20);
			addNode( node21);
	//*/		addNode( node20, node21);

			NetworkLink Link40=new NetworkLink(351);
			putLink(node20, node21, Link40);
	/*		putLink(node21, node20, Link40);
			node20.addChild(node21);
			put(node20, node21, 351);
			put(node21, node20, 351);
			

			addNode( node21);
			addNode( node22);
	//*/		addNode( node21, node22 );

			NetworkLink Link41=new NetworkLink(658);
			putLink(node21, node22, Link41);
		/*	putLink(node22, node21, Link41);
			node21.addChild(node22);
			put(node21, node22, 658);
			put(node22, node21, 658);
			

			
			addNode( node22);
			addNode( node23);
//		*/	addNode( node22, node23);

			NetworkLink Link42=new NetworkLink(710);
			putLink(node22, node23, Link42);
	/*		putLink(node23, node22, Link42);
			node22.addChild(node23);
			put(node22, node23, 710);
			put(node23, node22, 710);
			

			addNode( node23);
			addNode( node24);
	//*/		addNode( node23, node24);

			NetworkLink Link43=new NetworkLink(630);
			putLink(node23, node24, Link43);
		/*	putLink(node24, node23, Link43);
			node23.addChild(node24);
			put(node23, node24, 630);
			put(node24, node23, 630);

			

			addNode( node6);
			addNode( node25);
//		*/	addNode( node6, node25);

			NetworkLink Link44=new NetworkLink(270);
			putLink(node6, node25, Link44);
		/*	putLink(node25, node6, Link44);
			node6.addChild(node25);
			put(node6, node25, 270);
			put(node25, node6, 270);
			

			addNode( node19);
			addNode( node25);
//		*/	addNode( node19, node25);

			NetworkLink Link45=new NetworkLink(820);
			putLink(node19, node25, Link45);
//			putLink(node25, node19, Link45);
	/*		node19.addChild(node25);
			put(node19, node25, 820);
			put(node25, node19, 820);
			
//			1067)(456
			addNode( node20);
			addNode( node26);
	//*/		addNode( node20, node26);

			NetworkLink Link46=new NetworkLink(381);
			putLink(node20, node26, Link46);
	/*		putLink(node26, node20, Link46);
			node20.addChild(node26);
			put(node20, node26, 381);
			put(node26, node20, 381);
			

			addNode( node24);
			addNode( node26);
	//*/		addNode( node24, node26);

			NetworkLink Link47=new NetworkLink(556);
			putLink(node24, node26, Link47);
//			putLink(node26, node24, Link47);
	/*		node24.addChild(node26);
			put(node24, node26, 556);
			put(node26, node24, 556);
			
			
			addNode( node22);
			addNode( node26);
	//*/		addNode( node22, node26);

			NetworkLink Link48=new NetworkLink(901);
			putLink(node22, node26, Link48);
	/*		putLink(node26, node22, Link48);
			node22.addChild(node26);
			put(node22, node26, 901);
			put(node26, node22, 901);
			
			
			addNode( node18);
			addNode( node28);
	//*/		addNode( node18, node28);

			NetworkLink Link49=new NetworkLink(732);
			putLink(node18, node28, Link49);
	/*		putLink(node28, node18, Link49);
			node18.addChild(node28);
			put(node18, node28, 732);
			put(node28, node18, 732);
			

			addNode( node27);
			addNode( node28);
	//*/		addNode( node27, node28);

			NetworkLink Link50=new NetworkLink(980);
			putLink(node27, node28, Link50);
	/*		putLink(node28, node27, Link50);
			node27.addChild(node28);
			put(node27, node28, 980);
			put(node28, node27, 980);
			
			
			addNode( node8);
			addNode( node27);
	//*/		addNode( node8, node27);

			NetworkLink Link51=new NetworkLink(780);
			putLink(node8, node27, Link51);
	/*		putLink(node27, node8, Link51);
			node8.addChild(node27);
			put(node8, node27, 780);
			put(node27, node8, 780);
			
			
			addNode( node14);
			addNode( node27);
		//*/	addNode( node14, node27);

			NetworkLink Link52=new NetworkLink(700);
			putLink(node14, node27, Link52);
	/*		putLink(node27, node14, Link52);
			node14.addChild(node27);
			put(node14, node27, 700);
			put(node27, node14, 700);*/

		
	}
    public static void main(String[] args) {
	 	Network net =new Network();

    	 for (Modulation modulation : Modulation.values()) {
			// for(int i=0; i < net.modulationDistances.size(); i++){
			//	 for(int j=0; j < slicesConsumption.size(); j++){

				// modulation.modulationDistances=net.modulationDistances.get(i);
			//	 modulation.slicesConsumption=slicesConsumption.get(j);
				 System.out.println(Arrays.toString(modulation.modulationDistances1()));
				 System.out.println(Arrays.toString(modulation.slicesConsumption1()));


			 }
    	// }*/
  //  }
    }
	// SERIALIZATION
/**	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Network(Map map) {
		super(new NetworkPathBuilder());
		List<NetworkNode> nodes = (List<NetworkNode>) map.get("nodes");
		if (nodes != null) for (NetworkNode node : nodes) addNode(node);
		Map<List<String>, NetworkLink> links = (Map<List<String>, NetworkLink>) map.get("links");
		if (links != null) for (Entry<List<String>, NetworkLink> link : links.entrySet()) putLink(getNode(link.getKey().get(0)), getNode(link.getKey().get(1)), link.getValue());
		Map<String, List<String>> groups = (Map<String, List<String>>) map.get("groups");
		if (groups != null) for (Entry<String, List<String>> group : groups.entrySet()) for (String node : group.getValue()) addNodeToGroup(group.getKey(), getNode(node));
	}
	
/**	@Override
	public Map<String, Object> serialize() {
		Map<String, Object> map = new HashMap<String, Object>();
		List<NetworkNode> nodes = getNodes();
		map.put("nodes", nodes);
		Map<List<String>, NetworkLink> links = new HashMap<List<String>, NetworkLink>();
		for (int i = 0; i < nodes.size(); i++)
			for (int j = i + 1; j < nodes.size(); j++)
				if (containsLink(nodes.get(i), nodes.get(j)))
					links.put(Arrays.asList(nodes.get(i).getName(), nodes.get(j).getName()),
							getLink(nodes.get(i), nodes.get(j)));
		map.put("links", links);
		Map<String, List<String>> groups = new HashMap<String, List<String>>();
		for (Entry<String, List<NetworkNode>> group : nodesGroups.entrySet()) {
			groups.put(group.getKey(), new ArrayList<String>());
			for (NetworkNode node : group.getValue())
				groups.get(group.getKey()).add(node.getName());
		}
		map.put("groups", groups);
		return map;
	}*/
}
