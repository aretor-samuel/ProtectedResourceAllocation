package Network;


/**
 * Created by sambabel on 2019-05-16.
 * Node identifier interface.
 */
public interface NodeId {
}
