package Network;


import com.google.common.base.MoreObjects;

import Utility.CPUException;
import Utility.MemoryException;
import Utility.NetworkException;
import Utility.StorageException;

import java.io.Serializable;

/**
 * Vertex class in EON including index and boolean value judging whether it runs normally.
 * Created by yby on 2017/3/31.
 */
public class Node2 implements Serializable {
	public	int regeneratorsCount, occupiedRegenerators;
	public	int cpu = 40, occupiedCPU;
	public	int memory = 160, occupiedMemory;
	public	int storage = 4000, occupiedStorage;
    private int index;
    private boolean isRunning;

    public Node2(int index, boolean isRunning) {
        this.index = index;
        this.isRunning = isRunning;
    }

    public Node2(int index) {
        this.index = index;
        this.isRunning = true;
    }

    public int getIndex() {
        return index;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public void setIsRunning(boolean isRunning) {
        this.isRunning = isRunning;
    }
    public void clearOccupied(){
		this.occupiedCPU = 0;
		this.occupiedMemory = 0;
		this.occupiedRegenerators = 0;
		this.occupiedStorage = 0;
	}

	public void setRegeneratorsCount(int regeneratorsCount) {
		this.regeneratorsCount = regeneratorsCount;
	}

	public int getFreeRegenerators() {
		return regeneratorsCount - occupiedRegenerators;
	}

	public boolean hasFreeRegenerators() {
		return regeneratorsCount - occupiedRegenerators > 0;
	}

	public void setMemory(int memory) {
		this.memory = memory;
	}

	public int getFreeMemory() {
		return memory - occupiedMemory;
	}

	public boolean hasFreeMemory() {
		return memory - occupiedMemory > 0;
	}

	public void occupyRegenerators(int count, boolean deallocate) {
		if (deallocate) {
			occupiedRegenerators += count;
		} else if ((count > regeneratorsCount - occupiedRegenerators || occupiedRegenerators < 0) && !deallocate) {
			throw new NetworkException(
					"Regenerators occupation exception! (" + occupiedRegenerators + "/" + regeneratorsCount + ")");
		} else {
			occupiedRegenerators += count;
		}
	}

	public void occupyMemory(int count, boolean deallocate) {
		if (deallocate) {
			occupiedMemory += count;
		} else if ((count > memory - occupiedMemory || occupiedMemory < 0) && !deallocate) {
			throw new MemoryException("Memory occupation exception! (" + occupiedMemory + "/" + memory + ")");
		} else {
			occupiedMemory += count;
		}
	}

	public void setCpu(int cpu) {
		this.cpu = cpu;
	}

	public int getFreeCpu() {
		return cpu - occupiedCPU;
	}

	public boolean hasFreeCpu() {
		return cpu - occupiedCPU > 0;
	}

	public void occupyCpu(int count, boolean deallocate) {
		if (deallocate) {
			occupiedCPU += count;
		} else if ((count > cpu - occupiedCPU || occupiedCPU < 0) && !deallocate) {
			throw new CPUException("CPU occupation exception! (" + occupiedCPU + "/" + cpu + ")");
		} else {
			occupiedCPU += count;
		}
	}

	public void setStorage(int storage) {
		this.storage = storage;
	}

	public int getFreeStorage() {
		return storage - occupiedStorage;
	}

	public boolean hasFreeStorage() {
		return storage - occupiedStorage > 0;
	}

	public void occupyStorage(int count, boolean deallocate) {
		if (deallocate) {
			occupiedStorage += count;
		} else if ((count > storage - occupiedStorage || occupiedStorage < 0) && !deallocate) {
			throw new StorageException("Storage occupation exception! (" + occupiedStorage + "/" + storage + ")");
		} else {
			occupiedStorage += count;
		}
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Node2 eonVertex = (Node2) o;

        return index == eonVertex.index;

    }

    @Override
    public int hashCode() {
        return index;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("index", index)
                .toString();
    }
}
