package Network;


import java.io.Serializable;

import com.google.common.base.Objects;

/**
 * The Spectrum frequency slot  in MCF.
 * Created by babel on 2019/05/12.
 */
public class FrequencySlots implements Serializable {
    private int wavelengthId ;

    public static final int AVAILABLE = 0;
    private int occupiedNum; // the number of slots occupied by different services
    private int occupiedServiceIndex; // the index of service if occupied now, otherwise, equals 0
    private int slotIndex;

    
    private boolean isOccupied = false;
    private double bandwidth = 1;

    private int SlotServiceId = -1;

	private int waveServiceId;

    public int getId(){
        return wavelengthId ;
    }
    public int getSlotIndex() {
        return slotIndex;
    }

    public void setId(int wavelengthId){
    //    this.wavelengthId = wavelengthId;
       this.slotIndex = wavelengthId;

    }


    public boolean getIsOccupied() {
       // return occupiedServiceIndex != AVAILABLE;
        return occupiedServiceIndex != AVAILABLE;
    }

    public void setOccupiedServiceIndex(int occupiedServiceIndex) {
        this.occupiedServiceIndex = occupiedServiceIndex;
    }
    public void accumulate() {
        occupiedNum++;
    }

    public int getOccupiedNum() {
        return occupiedNum;
    }

    public double getBandwidth(){
        return bandwidth ;
    }

    public void setBandwidth(double bandwidth){
        this.bandwidth = bandwidth;
    }

    public int getWaveServiceId(){
        return waveServiceId ;
    }

    public void setwaveServiceId(int waveServiceId){
        this.waveServiceId = waveServiceId;
    }
/**
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FrequencySlots)) return false;
        FrequencySlots that = (FrequencySlots) o;
     //   return wavelengthId == that.wavelengthId &&
        return wavelengthId == that.slotIndex &&
                isOccupied == that.isOccupied &&
                Double.compare(that.bandwidth, bandwidth) == 0 &&
                		waveServiceId == that.waveServiceId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(wavelengthId, occupiedServiceIndex, bandwidth, waveServiceId);
    }*/
    public int getOccupiedServiceIndex() {
        return occupiedServiceIndex;
    }

 

    public FrequencySlots(final int slot) {
        occupiedNum = 0;
        occupiedServiceIndex = AVAILABLE;
     //  this.wavelengthId = slot;
        this.slotIndex = slot;

    }

	
}
