package Network;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import TrafficGeneration.Service;






public class LinkCores implements Serializable {
    public static final int AdjacentCores = 1;
    public static final int AVAILABLE = 0;

    private int adjacentNum;
    private int AdjacentCoresServiceIndex; // the index of service if ocupied now, otherwise, equals 0
    private int adjacentCoresIndex;
    private int id;
   // private List<FrequencySlots> coreWavelength = new ArrayList<FrequencySlots>(320);
  //  private List<FrequencySlots> coreWavelength = new ArrayList<FrequencySlots>();
    private ArrayList<FrequencySlots> coreWavelength;

    private ArrayList<Service> AssignedServicelist= new ArrayList<Service>();



    private ArrayList<LinkCores> adjacentCores = new ArrayList<LinkCores>();
	private ArrayList<LinkCores> NonadjacentCores= new ArrayList<LinkCores>();

    public LinkCores(int id) {
     //   public LinkCores() {

       this.id = id;
        initWavelength();
    }

    //get
    public int getId() {
        return id;
    }

    public void setId(int id){
    	this.id = id;} 
    public int getAdjacentCoreIndex() {
        return adjacentCoresIndex;
      //  return getId();

    }

    public ArrayList<Service> getService() {
        // return occupiedServiceIndex != AVAILABLE;
         return AssignedServicelist ;
     }

     public void setService(Service service) {
      //   this.service = service;
         this.AssignedServicelist.add(service);
     }


    public ArrayList<LinkCores> getAdjacentCores() {
        return adjacentCores;
    }
    public ArrayList<LinkCores> getNonAdjacentCores() {
        return NonadjacentCores;
    }
    
    public void setNonAdjacentCores(ArrayList<LinkCores> NonadjacentCores) {
        this.NonadjacentCores = NonadjacentCores;
    }
    
    public void setAdjacentCores(ArrayList<LinkCores> adjacentCores) {
        this.adjacentCores = adjacentCores;
    }
    
    public void addAdjCores(LinkCores c) {
        adjacentCores.add(c);
    }

    public void addNonAdjCores(LinkCores c) {
    	NonadjacentCores.add(c);
    }
    /////////////
    ///////////////////////////

    public ArrayList<FrequencySlots> getWavelength() {
        return coreWavelength;
    }

    public void setWavelength(ArrayList<FrequencySlots> coreWavelength) {
        this.coreWavelength = coreWavelength;
    }

    public void initWavelength(){
    	coreWavelength=Lists.newArrayListWithCapacity(100);

        for (int i = 0;i< 100; i++){
            coreWavelength.add(new FrequencySlots(i+1));
    // coreWavelength.get(i).setId(i);
        }
    }
    public int occupiedSlotsNum() {
        int count = 0;
        for (FrequencySlots slot : coreWavelength) {
            if (slot.getIsOccupied()) {
                count++;
            }
        }
        return count;
    }

    public ArrayList<Integer> availableSlotsIndexList1() {
        ArrayList<Integer> availableSlotsIndex = Lists.newArrayList();

//       for (int i = 0;i< coreWavelength.size()-1; i++){

        for (FrequencySlots slot : coreWavelength) {
//        	FrequencySlots slot=coreWavelength.get(i+1);

            if (!slot.getIsOccupied()) {

                availableSlotsIndex.add(slot.getSlotIndex());
             //  availableSlotsIndex.add(slot.getId());

            }
        }
        
        return availableSlotsIndex;
    }
   
   // public TreeSet<Integer> availableSlotsIndexSet(ArrayList<Integer>noCrosstalkslots) {
       public TreeSet<Integer> availableSlotsIndexSet1() {

    
        TreeSet<Integer> availableSlotsIndex = Sets.newTreeSet();
      //  for (int i = 0;i< coreWavelength.size()-1; i++){

              for (FrequencySlots slot : coreWavelength) {
            //   	FrequencySlots slot=coreWavelength.get(i+1);

            if (!slot.getIsOccupied()) {

               availableSlotsIndex.add(slot.getSlotIndex());
               // availableSlotsIndex.add(slot.getId());

            }
        }
   			 
        
        return availableSlotsIndex;
    }
    
  

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LinkCores)) return false;
        LinkCores linkCores = (LinkCores) o;
        return id == linkCores.id &&
                Objects.equal(coreWavelength, linkCores.coreWavelength);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, coreWavelength);
    }

	
}

