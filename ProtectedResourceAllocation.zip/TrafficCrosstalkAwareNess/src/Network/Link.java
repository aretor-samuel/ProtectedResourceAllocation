package Network;

import Utility.LinkType;
import Utility.Weight;
import Network.Node;
import Network.NodeId;

/**
 * Created by Boyuan on 16-11-12.
 * Link representation.
 * Only have getter methods, for written protection. Because if someone want to change a link instance, he must be sure
 * that he knows what type is it. So setter method will be included in its internal builder and implementation classes.
 */
public interface Link extends Weight {

    /**
     * 深拷贝。没有使用Cloneable接口，因为设计缺陷。
     * @return
     */
    Link deepClone();

    String genEdgeId();

    double hopWeight = 1;

    /**
     * get the other node apart from input oneNode
     * @param oneNode one node in this edge
     * @return if oneNode is not contained by this edge, return null.
     */
    Node getTheOtherNode(Node oneNode);

    /**
     * check if this edge is directed.
     * @return true - directed, false - undirected
     */
    boolean isDirected();

    /**
     * edge id.
     * @return edge id
     */
    LinkID getEdgeId();

    /**
     * return the source node of this link.
     * @return source node
     */
    Node getSrc();

    /**
     * return the destination node of this link.
     * @return destination node
     */
    Node getDst();

    /**
     * return the source node id of this link.
     * @return source node id
     */
    NodeId getSrcId();

    /**
     * return the destination node id of this link.
     * @return destination node id
     */
    NodeId getDstId();

    /**
     * get edge status,default DOWN.
     * @return edge status
     */
    LinkStatus getEdgeStatus();

    /**
     * get edge type
     * @return edge type
     */
    LinkType getEdgeType();

    /**
     * only this one seeter method allowed in Edge.
     * @param status
     */
    void setEdgeStatus(LinkStatus status);

    interface LinkBuilder {
        /**
         * build link instance
         * @return link
         */
        Link build();

        /**
         * set link status
         * @param status link status
         */
        void setEdgeStatus(LinkStatus status);

        /**
         * set edge type
         * @param type
         */
        void setEdgeType(LinkType type);

        /**
         * set source node.
         * @param src source node
         */
        void setSrc(Node src);

        /**
         * set destination node.
         * @param dst destination node
         */
        void setDst(Node dst);

        /**
         * set isDirected, whose default value is false.
         * @param isDirected false - bydirection, true - directed.
         */
        void setIsDirected(boolean isDirected);
    }

}
