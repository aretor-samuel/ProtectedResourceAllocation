package Network;



import Network.NodeId;
import Utility.Error;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by Boyuan on 16-11-13.
 * require ： NodeId接口的Sdm网络NodeId实现类
 */
public class NodeIdImplement implements NodeId {

    private int routerId;

    public int getRouterId() {
        return routerId;
    }

    public void setRouterId(int routerId) {
        this.routerId = routerId;
    }

    public NodeIdImplement(int routerId){
        checkNotNull(routerId, Error.NODE_ID_NULL);
        this.routerId = routerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        NodeIdImplement that = (NodeIdImplement) o;

        return routerId == that.routerId;

    }

    @Override
    public int hashCode() {
        return routerId;
    }

    @Override
    public String toString() {
        return "SdmNodeIdImpl{" +
                "routerId=" + routerId +
                '}';
    }
}
