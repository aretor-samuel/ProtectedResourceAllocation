package Network;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;



 
// public abstract class Path<N extends NetworkNode> implements Comparable<Path<N>> {
	 public abstract class Path<N > implements Comparable<Path<N>> {


	final N[] path;
	//final  LinkedList<N> path;
  public Path(N[] path) {

//	public Path(LinkedList<N> path) {
		this.path = path;
	}
	
	public int indexOf(N node) {
	for (int i = 0; i < path.length; i++)
			if (path[i].equals(node))
		//for (int i = 0; i < path.size(); i++)
			//if (path.get(i).equals(node))
		
				return i;
		return -1;
	}
	
	public N get(int i) {
	return path[i];
	//	return path.get(i);

	}
	
	public int size() {
		return path.length;
	//return path.size();

	}

/**	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(path);
	//	result = prime * result + List..hashCode(path);

		return result;
	}*/
	/**	 @Override
    public int hashCode() {
        int result = nodeA.;
        result = 31 * result + node2;
        return result;
    }     
*/
	
	public int hashCode() {
	    int hashCode = 1;
	    for (N e : path)
	        hashCode = 31*hashCode + (e==null ? 0 : e.hashCode());
	    return hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Path<?> other = (Path<?>) obj;
		//if (!Arrays.equals(path, other.path))
			if (!path.equals(other.path))

			return false;
		return true;
	}
	
	
}

