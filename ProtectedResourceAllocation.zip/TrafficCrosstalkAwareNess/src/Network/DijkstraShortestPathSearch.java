package Network;




import Network.Node;
import Network.NodeId;
import Network.Link;
import Network.LinkID;
import Graph.Graph;
import Utility.WeightType;
///import java.util.logging.Logger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 *  Algorithm copied from Wikipedia.org: http://en.wikipedia.org/wiki/Dijkstra%27s_algorithm#Algorithm
 */
public class DijkstraShortestPathSearch {

    private static final Logger log = LoggerFactory.getLogger(DijkstraShortestPathSearch.class);
  //  private static Logger LOGGER = Logger.getLogger(MyClass.class.getName());

    private Graph graph;
    private boolean isDirected;


    private Map<NodeId, Link> edgeTo;
    private Map<NodeId, Double> distTo;
 // The subscript mapping relationship of the node in the index priority queue
    private Map<NodeId, Integer> indexMapping;
 // index priority queue
    private IndexMinPQ<Double> pq;

    private Node src;
    private Node dst;
    private WeightType weightType;


    /**
      * Calculate the D algorithm from src to dst.
     * @param graph graph
     * @param isDirected indicates if graph is directed
     * @param src source node
     * @param dst destination node
     * @param weightType weight type
     */
    public DijkstraShortestPathSearch(Graph graph, boolean isDirected, Node src, Node dst, WeightType weightType) {
        this.graph = graph;
        this.isDirected = isDirected;
        this.src = src;
        this.dst = dst;
        this.weightType = weightType;
    }

    /**
     * Calculate the src to any point D algorithm.
      * Then you can call directly
      * @param graph
      * @param isDirected
      * @param weightType
      * @param src
     */
    public DijkstraShortestPathSearch(Graph graph, boolean isDirected, WeightType weightType, Node src) {
        this.graph = graph;
        this.isDirected = isDirected;
        this.weightType = weightType;
        this.src = src;
    }

    /**
     * Get the path from the source point to all the sink points.
      * @return return value is the path from the source point to all the sink points in the graph
     */
    public Map<NodeId, List<Link>> getAllDsts() {
  checkNotNull(edgeTo, "The method must be executed, that is, after the calculateShortestDistances() method is called, the method can be called to obtain the path.\n" + 
        		"");
        Map<NodeId, List<Link>> rtn = new HashMap<NodeId, List<Link>>(edgeTo.size());
        for (Node dest : graph.getNodes().values()) {
            if (!dest.equals(src)) {
                this.dst = dest;
                rtn.put(dest.getNodeId(), getPath());
            } else {
                
            }
        }

        return rtn;
    }

    /**
     * Get the path list from src to dst
      * @return path consisting of List<Edge>
     */
    public List<Link> getPath() {
        if (edgeTo != null) {
            List<Link> path = new ArrayList<Link>(edgeTo.size());
            Node tmp = dst;
            while (!tmp.equals(src)) {
                Link edge = edgeTo.get(tmp.getNodeId());
                tmp = edge.getTheOtherNode(tmp);
                path.add(edge);
            }
            return path;
        } else {
            log.error("You must be doing the calculation, that is, you can call the method to get the path after calling the calculateShortestDistances() method.\n" + 
            		"。");
            return null;
        }
    }

    /**
     * Uses Dijkstra's algorithm to calculate the shortest distance from the source to all nodes
     *
     */
    public  DijkstraShortestPathSearch calculateShortestDistances() {

        int nodeNum = graph.getEdgesNum();
        edgeTo = new HashMap<NodeId, Link>(nodeNum);
        distTo = new HashMap<NodeId, Double>(nodeNum);
        pq = new IndexMinPQ<Double>(nodeNum);
        indexMapping = new HashMap<NodeId, Integer>(nodeNum);

     // Initialize distTo, the source point to its own distance is 0, the distance to other points is Double's positive infinity
        int i = 0;
        for (Node node : graph.getNodes().values()) {
            distTo.put(node.getNodeId(), Double.POSITIVE_INFINITY);
            indexMapping.put(node.getNodeId(), i);
            i++;
        }
        distTo.put(src.getNodeId(), 0.0d);

        pq.insert(indexMapping.get(src.getNodeId()), 0.0);
        while (!pq.isEmpty()) {
            relax(pq.delMin());
        }
        return this;

    }

    /**
     * Find the corresponding nodeId from indexMapping
      * @param v
      * @return

     */
    private NodeId nodeIdFromIndex(int v) {
        for (Map.Entry<NodeId, Integer> entry : indexMapping.entrySet()) {
            if (entry.getValue() == v) {
                return entry.getKey();
            }
        }
        return null;
    }

    /**
     * Relax node v
      * @param v
     */
    private void relax(int v) {
        NodeId vId = nodeIdFromIndex(v);

        for (Link edge : adj(vId)) {
            NodeId w = edge.getTheOtherNode(graph.getNodes().get(vId)).getNodeId();
            //
            double weight = edge.getWeight(weightType);
            if (distTo.get(w) > distTo.get(vId) + weight) {
                distTo.put(w, distTo.get(vId) + weight);
                edgeTo.put(w, edge);

                int wIndex = indexMapping.get(w);
                if (pq.contains(wIndex)) {
                    pq.change(wIndex, distTo.get(w));
                } else {
                    pq.insert(wIndex, distTo.get(w));
                }
            }
        }
    }

    /**
     *Get all the edges that contain the node
      * @param node node
      * @return contains a list of edges of the node
     *
     */
    private List<Link> adj(NodeId node) {
        List<Link> edges = new ArrayList<Link>();
        for (Link edge : graph.getEdges().values()) {
            if (edge.getSrc().getNodeId().equals(node) || edge.getDst().getNodeId().equals(node)) {
                edges.add(edge);
            }
        }
        return edges;
    }


    public Map<NodeId, Double> getDistTo() {
        return distTo;
    }

    public Map<NodeId, Link> getEdgeTo() {
        return edgeTo;
    }
}
