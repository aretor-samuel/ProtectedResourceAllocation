package Network;


import com.alibaba.fastjson.JSON;
import com.google.gson.*;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Created by asia on 2016/11/18.
 *
 */
public class JsonObject {
    private static final Logger log = LoggerFactory.getLogger(JsonObject.class);

    private static final String fileName = "topo.json";

    static Group group ;

    public static Group getGroup() {
       

        return group;

    }

    public static Group Json2Object() {
     
        try {
            Gson gson = new Gson();
        	String       jsonString = readToString( "/home/dl/eclipse-workspace/TrafficCrosstalkAwareNess/src/resources/topo.json");
        	
            group = gson.fromJson(jsonString, Group.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
		return group;
    }
    public static String readToString(String fileName)  {
    	  String encoding = "UTF-8";
          File file = new File(fileName);
      //    File file = new File("/home/babel/eclipse-workspace/ARSimulation/src/resources/topo.json");

          Long filelength = file.length();
          byte[] filecontent = new byte[filelength.intValue()];
          try {
              FileInputStream in = new FileInputStream(file);
              in.read(filecontent);
              in.close();
          } catch (FileNotFoundException e) {
              e.printStackTrace();
          } catch (IOException e) {
              e.printStackTrace();
          }
          try {
              return new String(filecontent, encoding);
          } catch (UnsupportedEncodingException e) {
              System.err.println("The OS does not support " + encoding);
              e.printStackTrace();
              return null;
            }
    }
    public static void main(String[] args)  {
  
    	Json2Object();
    if (group != null) {
             for (Links t : group.getLinks()) {
               System.out.println(t.getSrcSeq() + " - " + t.getDstSeq() + " - " + t.getWeight());
             }
           }
   	
    }
}

class Group {

    private List<Links> links = new ArrayList<Links>();
    private List<Nodes> nodes = new ArrayList<Nodes>();

    public List<Links> getLinks() {
        return links;
    }

    public void setLinks(List<Links> links) {
        this.links = links;
    }

    public List<Nodes> getNodes() {
        return nodes;
    }

    public void setNodes(List<Nodes> nodes) {
        this.nodes = nodes;
    }

}

class Links {

    private int srcSeq;
    private int dstSeq;
    private double weight;
    public Links(int srcSeq, int dstSeq, int weight){
        
        this.srcSeq = srcSeq;
		this.dstSeq = dstSeq;
       this.weight = weight;
        
        
    }

    public int getSrcSeq() {
        return srcSeq;
    }

    public void setSrcSeq(int srcSeq) {
        this.srcSeq = srcSeq;
    }

    public int getDstSeq() {
        return dstSeq;
    }

    public void setDstSeq(int dstSeq) {
        this.dstSeq = dstSeq;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}

class Nodes {

    private int nodeId;
    public Nodes(int nodeId) {
        this.nodeId = nodeId;
    }

    public int getNodeId() {
        return nodeId;
    }

    public void setNodeId(int nodeId) {
        this.nodeId = nodeId;
    }
}