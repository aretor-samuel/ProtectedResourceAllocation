package Collections;

import java.util.ArrayList;
import java.util.List;

import Network.Node2;


public class IdentifiableSet<N extends Node2>  {

	
	int freeID;
public	List<N> path;

	public IdentifiableSet() {
	//	super(8);
		//freeID = 0;
		freeID = 1;
		path = new ArrayList<N>();


	}
	
	public IdentifiableSet(int initialCapacity) {
	//	super(initialCapacity);
	//	freeID = 0;
		freeID = 1;

	}
	

//	@Override
	public void add(N element) {
		
		path.add(element);
	
	}
	public boolean contains(N node) {
		return path.contains(node);
	}

	public boolean remove(N node) {
		return path.remove(node);
	}
	
}

/**
public class IdentifiableSet<E extends Identifiable> extends HashArray<E> {
	
	int freeID;
	
	public IdentifiableSet() {
		super(8);
		freeID = 0;
		//freeID = 1;


	}
	
	public IdentifiableSet(int initialCapacity) {
		super(initialCapacity);
		freeID = 0;
	//	freeID = 1;

	}

	@Override
	public boolean add(E element) {
		if (element.id != -1) return false;
		if (freeID == capacity()) resize(capacity() + 8);
		element.id = freeID;
		freeID++;
		return super.add(element);
	}

	@Override
	public boolean remove(int id) {
		E old = get(id);
		boolean result = super.remove(id);
		for (int i = id + 1; i < size(); i++) get(i).id--;
		rehash();
		if (capacity() - size() > 8) resize(size() + 8);
		if (old != null) old.id = -1;
		return result;
	}
}

*/