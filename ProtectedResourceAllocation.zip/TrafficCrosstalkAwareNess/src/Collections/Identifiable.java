package Collections;

import graph.Relation;
import net.NetworkNode;

public abstract class Identifiable {
	NetworkNode nodeid;
//	int id=nodeid.node;
	int id= -1;
	//NetworkNode nodeid;
	
	public final int getID() {
		return id;
	//	return nodeid.getNode();


	}
	
	@Override
	public  int hashCode() {
		//return NetworkNode.getNode();
		return id;
		//return nodeid.getNode();

	}
/**	
		 @Override
    public int hashCode() {
     //   int result = nodeid.node;
       int result = 0 ;
		for (int i = 1; i < 29; i++) 
		result=i;
       // result = 31 * result + nodeid.hashCode();
        //return nodeid.hashCode();
       /// return nodeid.hashCode();
        return result;


    }     */

	
	@Override
	public boolean equals(Object o) { // TODO temp final removal
		if (o == null) return false;
		if (o.getClass() != this.getClass()) return false;
		return getID() == ((Identifiable) o).getID();
	}
/**	@Override
    public boolean equals(Object o) {
     /**   if (this == o) return true;
        if (!(o instanceof Relation)) return false;

        NetworkNode pathKey = (NetworkNode) o;

        if (nodeid. != pathKey.nodeA) return false;
        return nodeB == pathKey.nodeB; */
 
	//	return o instanceof Identifiable && ((Identifiable) o).getID()==nodeid.node;

        

 //   }*/
	
}
